# imports
import requests, time, os, sys, asyncio, json, traceback, datetime, ast, urllib, pytz, io, gzip
from bs4 import BeautifulSoup as BS
from threading import Thread
from random import random, randint, choice, shuffle
from functools import reduce
#from mx.DateTime.ISO import ParseDateTimeUTC
#from fp.fp import FreeProxy

# ====================================== Window Vars ==========================
user_agents = []
header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}
proxies = {"http"  : '', "https" : ''}
random_sites = ['https://yandex.ru', 'https://google.com', 'https://mail.ru/', 'https://youtube.com/', 'https://useragents.ru/', 'https://youtube.com/', 'https://kmb.cybber.ru', 'https://stackoverflow.com/', 'https://python-scripts.com/', 'http://turfjs.org/', 'https://glyphicons.com/', 'https://html-color-codes.info']

# --------- DADATA TOKENS
dadata_keys = [['3e7b696f4e3566146bbaca04c9cf645ae8947631', '076ec439d2b4679510d06675d39d29714a9fe8bb']]

# ------------------------------ GLOBAL CACHE
class Cache_Class:
    def __init__(self, *keys):
        self.dict = {key: {} for key in keys}
        self.threads = {key: {} for key in keys}

    # класс потока, удаляющего ключ: значение из словаря (кэша)
    class Cache_Thread:
        def __init__(self, cache, key_main, key_el, value, timeout):
            self.cache = cache
            self.timeout = timeout
            self.time_start = time.time()
            self.stopped = False
            # запускаем поток
            self.thread = Thread(target = self.__delete_key_timeout, args=(key_main, key_el, timeout))

        def start(self):
            self.thread.start()

        def __delete_key_timeout(self, key_main, key_el, timeout):
            while (time.time() - self.time_start) < self.timeout and not self.stopped:
                time.sleep(1)
            # проверяем, не удалили ли уже, а только тогда удаляем
            if key_el in self.cache.threads[key_main]:
                del self.cache.threads[key_main][key_el]
            if key_el in self.cache.dict[key_main] and not self.stopped:
                del self.cache.dict[key_main][key_el]

        def set_timeout(self, timeout, change_time_passed=True):
            self.timeout = timeout
            if change_time_passed:
                self.time_start = time.time()

        def stop(self):
            self.stopped = True

    def add(self, key_main, key_el, value, timeout=None):
        self.dict[key_main][key_el] = value
        if timeout is not None:
            if key_el in self.threads[key_main]:
                self.threads[key_main][key_el].set_timeout(timeout)
            else:
                thr = self.Cache_Thread(self, key_main, key_el, value, timeout)
                self.threads[key_main][key_el] = thr
                thr.start()

Cache = Cache_Class('Users_password_recovery_send_email_timeout', 'Users_password_recovery_timeout_save_new_timeout',
                    'Housing_stock_data_summary', 'New_buildings_data_summary')
# ======================================= My subsidiary functions =============
# ---------------------------------- SITES ------------------------------------
# получить ip адрес из request
def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

# рандомный агент
def choice_useragent(change_header = False):
    global user_agents
    if user_agents == []:
        user_agents = open('user_agents/list.txt', 'r').readlines()
    ug = choice(user_agents).rstrip('\n')
    if change_header:
        global header
        header['User-Agent'] = ug
    return ug

# нормальный url
def normal_url(url):
    if url == url.lstrip('http'):
        url = 'http:' + url
    return url

# запрос на рандомный сайт
def random_site_request():
    try:
        htmlfff = requests.get(choice(random_sites), headers = header)
        return {'status': 'ok'}
    except:
        return {'status': 'error'}

# ---------------------------------- LIST -----------------------------------
# последний элемент списка
def last_el_list(g_list):
    return g_list[len(g_list) - 1]

# сделать словарь ребёнком другого словаря
def child_dict_request(g_dict):
    return {'key': g_dict}

# --------------------------------- STRING ----------------------------------
def check_right_email(text):
    if text.strip() == '':
        return False, 'Поле email не должно быть пустым'
    if len(text.strip().split()) > 1:
        return False, 'В поле email не может быть пробелов'
    if '@' not in text:
        return False, 'В поле email нет символа @'
    listic = text.split('@')
    if len(listic) != 2:
        return False, 'В поле email знаков @ больше одного'
    name, server = listic[0], listic[1]
    if name.strip() == '':
        return False, 'В поле email нет логина почты'
    if server.strip() == '':
        return False, 'В поле email нет домена почты'
    if '.' not in server:
        return False, 'В поле email нет доменного разделения'
    name_server, com_server = server.split('.')
    if name_server.strip() == '':
        return False, 'Нет названия сервера почты'
    if com_server.strip() == '':
        return False, 'Нет букв после точки'
    return True, 'Right'

def check_right_password(text):
    if text.strip() == '':
        return False, 'Поле password не должно быть пустым'
    if len(text.strip().split()) > 1:
        return False, 'В поле password не может быть пробелов'
    if len(text.strip()) < 8:
        return False, 'Длина password должна быть больше 8 символов'
    return True, 'Right'

def random_recovery_code():
    ord_letters = [(65, 122), (48, 57)]
    length = randint(15, 20)
    random_code = ''.join(list(map(lambda i: chr(randint(*choice(ord_letters))), list(range(length)))))
    return random_code

# -------------- сжатие gzip
# сжать строку
def gzip_str(string_: str) -> bytes:
    out = io.BytesIO()

    with gzip.GzipFile(fileobj=out, mode='w') as fo:
        fo.write(string_.encode())

    bytes_obj = out.getvalue()
    return bytes_obj

# разжать строку
def gunzip_bytes_obj(bytes_obj: bytes) -> str:
    return gzip.decompress(bytes_obj).decode()

# ---------------------------------- ADRESS -----------------------------------
# определить координаты по адресу
def adress_to_xy_with_token(adr, token, secret):
    url = "https://cleaner.dadata.ru/api/v1/clean/address"
    header = {
        "Content-Type": "application/json",
        "Authorization": "Token " + token,
        "X-Secret": secret
    }
    result = requests.post(url, headers = header, json = [adr]).json()
    return result

# обёртка к предыдущей функции
def adress_to_xy(adr):
    token, secret = choice(dadata_keys)
    result = adress_to_xy_with_token(adr, token, secret)
    return result

# ---------------------------------- PROXY -----------------------------------
# находим рабочий прокси
def get_proxy(proxies_change = False, timeout = 0.4):
    # country_id=['US', 'BR', 'RU', 'SP'],
    proxy = FreeProxy(timeout = timeout, rand = True).get()
    if proxies_change:
        global proxies
        proxies = {'http': proxy, 'https': proxy}
    return proxy

def new_work_proxy():
    while True:
        # получаем якобы рабочий прокси
        get_proxy(proxies_change = True)
        choice_useragent(change_header = True)
        # получаем страничку яндекса
        url = 'https://yandex.ru/'
        html = str(requests.get(url, headers = header, proxies = proxies).text)
        # если норм, тогда заканчиваем
        if len(html) >= 10 ** 5:
            break
    return 'ok'

# ----------------------------- DATE AND FIELD -------------------------------
def get_all_infotmation_from_field(field):
    name_field = str(field.name).capitalize()
    # главный список информации по полю
    result, inf = {}, {}
    inf['name'] = name_field
    inf['type'] = str(field.__class__.__name__)
    inf['value'] = ''
    try:
        inf['help_text'] = field.help_text if field.help_text != '' else name_field
    except:
        inf['help_text'] = name_field
    # отправляем
    return inf

def value_to_chocolate(value, ftype):
    if ftype == 'JSONField':
        return json.dumps(value, ensure_ascii=False, indent=2)
    elif ftype == 'BooleanField':
        if value:
            return 'checked'
        else:
            return 'not_checked'
    elif ftype == 'FileField':
        if str(value).strip() == '':
            return ['Файл не выбран', '']
        else:
            return [str(value).strip(), '/media/' + str(value).strip()]
    else:
        return str(value)

def normal_date(date):
    if date.strip() == '':
        return datetime.datetime.now()
    if '.' in date:
        if '+' in date:
            date = date.split('+')[0] + '+' + ''.join(date.split('+')[1].split(':'))
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S.%f%z")
        elif '-' in date and len(date.split('-')) == 4:
            date = '-'.join(date.split('-')[:3]) + '-' + ''.join(date.split('-')[3].split(':'))
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S.%f%z")
        else:
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S.%f")
    else:
        if '+' in date:
            date = date.split('+')[0] + '+' + ''.join(date.split('+')[1].split(':'))
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S%z")
        elif '-' in date and len(date.split('-')) == 4:
            date = '-'.join(date.split('-')[:3]) + '-' + ''.join(date.split('-')[3].split(':'))
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S%z")
        else:
            date = datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
    return date

def read_second(sec):
    remainder = sec % 10
    if remainder in [5, 6, 7, 8, 9, 0]:
        return 'секунд'
    elif remainder in [2, 3, 4]:
        return 'секунды'
    else:
        return 'секунда'




# end.
