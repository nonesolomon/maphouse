from . import views
from django.urls import path, include

urlpatterns = [
    path('', views.main, name='main start function'),
    # ---------
    # Рассылка
    path('service/add_email_to_newsletter', views.add_email_to_newsletter, name='add to mailing list function'), # Добавить email в список получателей
    # API
    path('api/get_administrative_districts', views.API.get_administrative_districts, name='get districts'), # Получить списки координат районов
    path('api/get_micro_districts', views.API.get_micro_districts, name='get districts'), # Получить списки координат микрорайонов
    # Жилищный фонд
    path('housing_stock', views.Housing_stock_view.housing_stock, name='housing stock main page'), # Жилищный фонд (главная страница)
    path('housing_stock/api/get_data', views.Housing_stock_view.get_data_housing_stock, name='housing stock get data page'), # Получить данные жилищного фонда
    # Новостройки
    path('new_buildings', views.New_buildings_view.new_buildings, name='new buildings main page'), # Новостройки (главная страница)
    path('new_buildings/api/get_data', views.New_buildings_view.get_data_new_buildings, name='new buildings get data page'), # Получить данные новостроек
    # Информация
    path('information/about_us', views.Information.about_us, name='about us page'), # О нас
    path('information/help', views.Information.help, name='help page'), # Справка
    path('information/feedback', views.Information.feedback, name='feedback page'), # Обратная связь
    path('information/commercial_offers', views.Information.commercial_offers, name='commercial offers page'), # Коммерческий предложения
    path('information/terms_of_use', views.Information.terms_of_use, name='terms of use page'), # Правила использования
    path('information/confidentiality', views.Information.confidentiality, name='confidentiality page'), # Конфиденциальность
]
