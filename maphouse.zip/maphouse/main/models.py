from django.db import models
from django.contrib.auth.models import AbstractUser
# import additions
from main.additions import *



# ========================== User
class User(AbstractUser):
    img = models.FileField(upload_to = "files/foto/", help_text="Фотография пользователя")
    permissions = models.JSONField(help_text="Разрешения (доступ к админ панели и базе данных)")
    recovery_code = models.TextField(help_text="Код доступа при восстановлении пароля (генерируется сам)")
    recovery_time = models.DateTimeField(default=datetime.datetime.now, help_text="Время действия кода доступа")

    def __str__(self):
        return self.username

    def get_title(self):
        return self.username

class Newsletter(models.Model):
    email = models.CharField(max_length = 100, help_text="Почтовый адрес получателя", unique=True)

    def get_title(self):
        return self.email

# ========================== Жилищный фонд
class Housing_stock(models.Model):
    adress = models.CharField(max_length = 100, help_text="Адрес здания")
    year_build = models.IntegerField(help_text='Год постройки')
    district = models.CharField(max_length = 20, help_text="Административный район")
    microdistrict = models.CharField(max_length = 20, help_text="Риэлторский район (микрорайон)")
    house_is_emergency = models.BooleanField(help_text='Является ли дом признан аварийным')
    floors = models.JSONField(help_text="Наибольшее количество этажей / Наименьшее")
    quantity_apartaments = models.IntegerField(help_text='Количество квартир (жилых помещений)')
    type_of_building = models.CharField(max_length = 15, help_text="Серия, тип постройки (из чего сделан)")
    bearing_wall_material = models.CharField(max_length = 15, help_text="Материал несущих стен")
    сadastral_number = models.CharField(max_length = 20, help_text="Кадастровый номер")
    energy_efficiency_class = models.CharField(max_length = 10, help_text="Класс энергетической эффективности")
    quantity_elevators = models.IntegerField(help_text='Количество лифтов')
    space_m2 = models.JSONField(help_text="Площадь жилых помещений м2 / Нежилых / Общего имущества")
    additional_information = models.TextField(help_text='Дополнительная информация')
    coordinates = models.JSONField(help_text="Координаты здания")

    def get_title(self):
        return self.adress

# ========================== Новостройки
class New_buildings(models.Model):
    name = models.CharField(max_length = 100, help_text="Название литера", default='Не определено')
    global_name = models.CharField(max_length = 100, help_text="Название новостройки", default='Не определено')
    # местоположение
    adress = models.CharField(max_length = 100, help_text="Адрес здания", default='Не определено')
    locality = models.CharField(default='Уфа', max_length = 100, help_text="Населённый пункт")
    district = models.CharField(max_length = 20, help_text="Административный район", default='Не определено')
    microdistrict = models.CharField(max_length = 20, help_text="Риэлторский район (микрорайон)", default='Не определено')
    coordinates = models.JSONField(help_text="Координаты объекта")
    # даты
    start_date = models.CharField(default='Не определено', max_length = 20, help_text="Дата начала строительства")
    sales_start_date = models.CharField(default='Не определено', max_length = 20, help_text="Дата начала продаж")
    deadline = models.CharField(default='Не определено', max_length = 20, help_text="Срок сдачи")
    object_readiness = models.CharField(default='Не определено', max_length = 20, help_text="Готовность объекта")
    # распространение информации
    phone = models.CharField(max_length = 11, help_text="Отдел продаж (Телефон)", default='Нет данных')
    site = models.CharField(max_length = 100, help_text="Сайт проекта", default='Не определено')
    social_network = models.JSONField(help_text="Соц. сети")
    # создатели
    developer = models.CharField(max_length = 100, help_text="Девелопер", default='Не определено')
    builder = models.CharField(max_length = 100, help_text="Застройщик", default='Не определено')
    # квартиры
    number_apartments_project = models.IntegerField(help_text="Количество квартир по проекту", default=0)
    apartments_sale_developer = models.IntegerField(help_text="Квартир в продаже от застройщика", default=0)
    apartments_cost = models.JSONField(help_text="Стоимость квартир (Сводка)")
    # Показатели классности проекта
    plot_index = models.FloatField(help_text="Индекс участка", default=0.0)
    parking_index = models.FloatField(help_text="Парковочный индекс", default=0.0)
    mop_index = models.FloatField(help_text="Индекс МОП", default=0.0)
    elevators_index = models.FloatField(help_text="Лифтовой индекс", default=0.0)
    share_oneroom_apartments = models.FloatField(help_text="Доля однокомнатных квартир", default=0.0)
    cumulative_rating = models.FloatField(help_text="Сводный рейтинг", default=0.0)
    # остальное
    floors = models.JSONField(help_text="Наибольшее / наименьшее количество этажей")
    conditional_class = models.CharField(max_length = 20, help_text="Условный класс", default='Не определено')
    decoration_level = models.CharField(max_length = 20, help_text="Уровень отделки", default='Не определено')
    parking_places = models.IntegerField(help_text="Количество машиномест", default=0)
    cost_parking_space = models.FloatField(help_text="Стоимость машиноместа", default=0.0)
    number_residential_sections = models.IntegerField(help_text="Количество жилых секций", default=0)
    quantity_elevators = models.IntegerField(help_text="Количество лифтов", default=0)
    cadastral_number = models.CharField(max_length = 21, help_text="Кадастровый номер", default='Не определено')
    land_area = models.FloatField(help_text="Площадь участка", default=0.0)
    all_area = models.FloatField(help_text="Площадь всего ЖК", default=0.0)
    living_area = models.FloatField(help_text="Жилая площадь", default=0.0)
    energy_efficiency_class = models.CharField(max_length = 15, help_text="Класс энергетической эффективности", default='Не определено')
    seismic_resistance = models.CharField(max_length = 15, help_text="Сейсмоустойчивость", default='Не определено')
    bearing_wall_material = models.CharField(max_length = 15, help_text="Материал несущих стен", default='Не определено')
    image = models.FileField(upload_to='new_buildings/img/', help_text='Изображение литера')
    # база ерз
    erz_id = models.CharField(max_length = 20, help_text="Id объекта в базе Ерз", default='Не определено')
    erz_id_liter = models.CharField(max_length = 20, help_text="Id литера объекта в базе Ерз", default='Не определено')

    def save(self, *args, **kwargs):
        """
        self.plot_index = round(float(self.land_area) / int(self.number_apartments_project), 2)
        self.parking_index = round(float(self.parking_places) / int(self.number_apartments_project), 2)
        self.mop_index = round((float(self.all_area) - float(self.living_area)) / int(self.number_apartments_project), 2)
        self.elevators_index = round(int(self.quantity_elevators) / int(self.number_apartments_project), 2)
        self.share_oneroom_apartments = round(int(self.number_apartments_project) / self.apartments_cost['1']['q'], 2)
        self.cumulative_rating = round(sum([self.plot_index, self.parking_index, self.mop_index, self.elevators_index]) / 4, 2)
        """
        super().save(*args, **kwargs)

    def get_title(self):
        return self.name

# ========================== Административные районы
class Districts(models.Model):
    title = models.CharField(max_length = 20, help_text='Название района')
    coordinates = models.JSONField(help_text='Границы района (координаты)')

    def get_title(self):
        return self.title

# ========================== Риэлторские районы
class Microdistricts(models.Model):
    title = models.CharField(max_length = 20, help_text='Название района')
    coordinates = models.JSONField(help_text='Границы района (координаты)')

    def get_title(self):
        return self.title

# ========================== Webcams
class Webcams(models.Model):
    title = models.TextField(help_text="Название камеры")
    href = models.TextField(help_text="Ссылка на камеру")
    x, y = models.TextField(help_text="Координата x"), models.TextField(help_text="Координата y")
    href_m3u8 = models.TextField(help_text="Ссылка на поток видео")
    server = models.TextField(help_text="Название исходного сайта")
    number = models.TextField(help_text="Номер камеры на исходном сайте")

    def get_title(self):
        return self.title

    def camera_m3u8(self):
        if self.server == 'ufanet':
            html = str(requests.get(self.href, headers = header).text)
            try:
                el = str(html).split(self.number)
                ip_server = last_el_list(el[0].split("marker.server = '")).split("';")[0]
                token = el[1].split("marker.token = '")[1].split("';")[0]
                href_m3u8 = 'http://'+ ip_server + '/' + self.number + '/tracks-v1/mono.m3u8?token=' + token
                # save
                self.href_m3u8 = href_m3u8
                self.save()
            except:
                pass
        return {'m3u8': href_m3u8}

    def get_main_information(self):
        return [self.title, float(self.x), float(self.y), self.server]
