from django.contrib import admin
from .models import User, Webcams, Districts, New_buildings

g = [User, Webcams, Districts, New_buildings]
for El in g:
    admin.site.register(El)
