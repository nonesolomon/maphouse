# -*- coding: utf-8 -*-
# start:

# ======================================================= 1
import os, sys
# settings django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)

# ======================================================= 2
# import database classes
from main.models import Newsletter, Housing_stock, New_buildings, Districts, Microdistricts
# import additions (and libraries in)
from main.additions import *

# ------------ imports flask modules and initialize
import os, sys, time, json, random, threading, copy
from flask import Flask, url_for, render_template, request, jsonify as JsonResponse, redirect

# ----------- initialize
app = Flask(__name__)
app.config['SECRET_KEY'] = 'dve8g8y3fuviwfsjdvhwif2f9w98fwduhfvw4f'


# ---------------------------------------------
# Main page -> /
@app.route('/')
def main():
    return f'''Страница в разработке, можете пока посмотреть: <br>
            <a href="/housing_stock">Жилищный фонд города Уфы</a> <br>
            <a href="/new_buildings">Новостройки Уфы</a>'''


# Newsletter -> /service/add_email_to_newsletter
@app.route('/service/add_email_to_newsletter', methods=['GET', 'POST'])
def add_email_to_newsletter():
    try:
        try:
            email = request.POST['email']
            if type(email) != str:
                return JsonResponse(**{'status': 'Incorrect input-data', 'message': 'Неправильные входные данные'})
        except:
            return JsonResponse(**{'status': 'Incorrect input-data', 'message': 'Неправильные входные данные'})
        check_right, message = check_right_email(email)
        if check_right:
            try:
                Newsletter.objects.create(email=email)
                return JsonResponse(**{'status': 'ok', 'message': 'Подписка оформлена'})
            except:
                return JsonResponse(**{'status': 'ok', 'message': 'Подписка уже была оформлена'})
        else:
            return JsonResponse(**{'status': 'Incorrect string', 'message': message})
    except:
        return JsonResponse(**{'status': 'Anything error', 'message': 'Какая-то ошибка'})


# Data access
class Api:
    def __init__(self):
        pass

    # Get administrative districts -> /api/get_administrative_districts
    def get_administrative_districts(self):
        try:
            result = {'status': 'ok', 'data': list(map(lambda x: {'title': x.title, 'coordinates': x.coordinates}, Districts.objects.all()))}
            return JsonResponse(**result)
        except:
            return JsonResponse(**{'status': 'Anything error (500)'}, status=500)

    # Get micro districts -> /api/get_micro_districts
    def get_micro_districts(self):
        try:
            result = {'status': 'ok', 'data': list(map(lambda x: {'title': x.title, 'coordinates': x.coordinates}, Microdistricts.objects.all()))}
            return JsonResponse(**result)
        except:
            return JsonResponse(**{'status': 'Anything error (500)'}, status=500)


# Housing stock (жилищный фонд)
class Housing_stock_view_class:
    # Inicialization (инициализация)
    def __init__(self):
        self.preprocessing_data()

    # Cache preprocessing (предобработка кэша)
    def preprocessing_data(self):
        # Summary (сводка)
        values = Housing_stock.objects.values_list(
            'year_build', 'floors', 'quantity_apartaments', 'bearing_wall_material',
            'energy_efficiency_class', 'district', 'microdistrict')
        min_year_build, max_year_build = min(values, key = lambda x: x[0])[0], max(values, key = lambda x: x[0])[0]
        min_floors, max_floors = min(values, key = lambda x: x[1]['min_floors'])[1]['min_floors'], max(values, key = lambda x: x[1]['max_floors'])[1]['max_floors']
        min_quantity_apartaments, max_quantity_apartaments = min(values, key = lambda x: x[2])[2], max(values, key = lambda x: x[2])[2]
        all_values_bearing_wall_material = list(set(map(lambda x: x[3], values)))
        all_values_energy_efficiency_class = list(set(map(lambda x: x[4], values)))
        all_values_district = list(set(map(lambda x: x[5], values)))
        all_values_microdistrict = list(set(map(lambda x: x[6], values)))
        dict_query = {'year': [min_year_build, max_year_build], 'floors': [min_floors, max_floors],
                      'q_a': [min_quantity_apartaments, max_quantity_apartaments],
                      'b_w_m': all_values_bearing_wall_material, 'e_f_c': all_values_energy_efficiency_class,
                      'district': all_values_district, 'microdistrict': all_values_microdistrict}
        dict_query_str = json.dumps(dict_query, separators=(',', ':'), ensure_ascii=False)
        Cache.add('Housing_stock_data_summary', 'summary', dict_query_str)
        # Some data on all houses (некоторые данные по всем домам)
        all_values_queryset = Housing_stock.objects.values_list('adress', 'district', 'microdistrict', 'quantity_apartaments', 'space_m2', 'year_build', 'floors', 'bearing_wall_material', 'energy_efficiency_class', 'сadastral_number', 'quantity_elevators', 'house_is_emergency', 'coordinates')
        all_values = []
        for index in range(len(all_values_queryset)):
            object = list(all_values_queryset[index])
            # quantity floors
            object[6] = [object[6]['min_floors'], object[6]['max_floors']]
            # area
            object[4] = f"{object[4]['living_space_m2']} / {object[4]['no_living_space_m2']} / {object[4]['common_property_area_m2']}"
            all_values.append(object)
        data_query_str = json.dumps(all_values, separators=(',', ':'), ensure_ascii=False)
        # put in cache
        Cache.add('Housing_stock_data_summary', 'data', data_query_str)

    # Home page in this section -> /housing_stock
    def housing_stock(self):
        result = {'summary': Cache.dict['Housing_stock_data_summary']['summary'], 'auth': {'status': False}}
        result['auth']['email'] = False
        return render_template('housing_stock/main.min.html', **result)

    # Get data -> /housing_stock/api/get_data
    def get_data_housing_stock(self):
        result = {'status': 'ok', 'data': Cache.dict['Housing_stock_data_summary']['data']}
        return JsonResponse(**result)


# New buildings (новостройки)
class New_buildings_view_class:
    # Inicialization (инициализация)
    def __init__(self):
        self.preprocessing_data()

    # Cache preprocessing (предобработка кэша)
    def preprocessing_data(self):
        # Summary (сводка)
        values = New_buildings.objects.values_list(
            'deadline', 'floors', 'number_apartments_project', 'bearing_wall_material',
            'energy_efficiency_class', 'district', 'microdistrict', 'pk')
        min_year_build, max_year_build = int(min(values, key = lambda x: int(x[0].split('кв.')[1]))[0].split('кв.')[1]), int(max(values, key = lambda x: int(x[0].split('кв.')[1]))[0].split('кв.')[1])
        min_floors, max_floors = min(values, key = lambda x: x[1][0])[1][0], max(values, key = lambda x: x[1][1])[1][1]
        min_quantity_apartaments, max_quantity_apartaments = min(values, key = lambda x: x[2])[2], max(values, key = lambda x: x[2])[2]
        all_values_bearing_wall_material = list(set(map(lambda x: x[3], values)))
        all_values_energy_efficiency_class = list(set(map(lambda x: x[4], values)))
        all_values_district = list(set(map(lambda x: x[5], values)))
        all_values_microdistrict = list(set(map(lambda x: x[6], values)))
        dict_query = {
            'year': [min_year_build, max_year_build], 'floors': [min_floors, max_floors],
            'q_a': [min_quantity_apartaments, max_quantity_apartaments],
            'b_w_m': all_values_bearing_wall_material, 'e_f_c': all_values_energy_efficiency_class,
            'district': all_values_district, 'microdistrict': all_values_microdistrict,
            'min_pk': values[0][7]}
        dict_query_str = json.dumps(dict_query, separators=(',', ':'), ensure_ascii=False)
        Cache.add('New_buildings_data_summary', 'summary', dict_query_str)
        # Some data on all new buildings (некоторые данные по всем новостройкам)
        all_values_queryset = New_buildings.objects.values_list(
            'name', 'apartments_cost',
            'cumulative_rating', 'plot_index', 'parking_index', 'mop_index', 'elevators_index', 'share_oneroom_apartments',
            'global_name', 'adress', 'district', 'microdistrict', 'start_date', 'deadline', 'object_readiness',
            'phone', 'site', 'developer', 'builder', 'number_apartments_project', 'apartments_sale_developer',
            'floors', 'conditional_class', 'decoration_level', 'parking_places', 'quantity_elevators', 'cadastral_number',
            'land_area', 'all_area', 'living_area', 'energy_efficiency_class', 'bearing_wall_material', 'erz_id', 'coordinates')
        all_values = []
        # recycle apartments (немного перерабатываем квартиры)
        cost_to_list = lambda x: [x['q'], x['min_p'], x['ave_p'], x['max_p'], x['min_a'], x['ave_a'], x['max_a'], x['min_m2'], x['ave_m2'], x['max_m2']] if len(x) > 1 else [0]
        for index in range(len(all_values_queryset)):
            object = list(all_values_queryset[index])
            year_cost = {}
            for index, object_cost_one in enumerate(object[1][1][-12:]):
                month = (index + object[1][0]) % 12 + 1
                year_cost[month] = list(map(lambda x: cost_to_list(x), list(object_cost_one.values())))
            object[1] = [object[1][0], year_cost]
            all_values.append(object)
        data_query_str = json.dumps(all_values, separators=(',', ':'), ensure_ascii=False)
        # put in cache
        Cache.add('New_buildings_data_summary', 'data', data_query_str)

    # Home page in this section -> /new_buildings
    def new_buildings(self):
        date = datetime.datetime.now().strftime('%Y-%m-%d')
        result = {'summary': Cache.dict['New_buildings_data_summary']['summary'], 'auth': {'status': False}, 'date': date}
        result['auth']['email'] = False
        return render_template('new_buildings/main.html', **result)

    # Get data -> /new_buildings/api/get_data
    def get_data_new_buildings(self):
        result = {'status': 'ok', 'data': Cache.dict['New_buildings_data_summary']['data']}
        return JsonResponse(**result)


# --------------------------------------- Initialize view classes
API = Api()
Housing_stock_view = Housing_stock_view_class()
New_buildings_view = New_buildings_view_class()


# -------------- urls
app.add_url_rule('/api/get_administrative_districts', 'Административные районы', API.get_administrative_districts)
app.add_url_rule('/api/get_micro_districts', 'Риэлторские районы', API.get_micro_districts)
# ---
app.add_url_rule('/housing_stock', 'Жилищный фонд', Housing_stock_view.housing_stock)
app.add_url_rule('/housing_stock/api/get_data', 'Данные жилищного фонда', Housing_stock_view.get_data_housing_stock)
# ---
app.add_url_rule('/new_buildings', 'Новостройки', New_buildings_view.new_buildings)
app.add_url_rule('/new_buildings/api/get_data', 'Данные новостроек', New_buildings_view.get_data_new_buildings)


# ------------- launch
if __name__ == '__main__':
    app.run(port=8000, host='127.0.0.1')

# end.
