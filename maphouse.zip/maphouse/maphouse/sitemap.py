from django.contrib import sitemaps
from django.urls import reverse


class Permanent_sitemap(sitemaps.Sitemap):
    changefreq = 'daily' # частота проверки
    protocol = 'https' # протокол
    # все ссылки на статичные страницы
    links = [{'location': '/', 'priority': 10},
             {'location': '/housing_stock', 'priority': 9}]
    links_length = len(links)

    def items(self):
        return list(range(self.links_length))

    def location(self, link_index):
        return self.links[link_index]['location']

    def priority(self, link_index):
        return self.links[link_index]['priority']
