from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic import RedirectView
# для карты сайта
from django.contrib.sitemaps.views import sitemap
from django.views.decorators.cache import cache_page
from maphouse.sitemap import Permanent_sitemap


# Формируем карту сайта
sitemaps = {
    'permanent': Permanent_sitemap
}

# все главные разделы и ссылки
urlpatterns = [
    path('admin_old/', admin.site.urls), # старая панель администрации
    path('', include('main.urls')), # главные разделы
    path('sitemap.xml', cache_page(3600 * 24)(sitemap), {'sitemaps': sitemaps}) # карта сайта
]

urlpatterns += static(settings.STATIC_URL, document_root = settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
