// MapHouse map library, version 1.0.0

class __Polygon{
  split_coordinates_into_lines_by_2_points(array_coord){
      var array_lines = [];
      for (var i=0; i<array_coord.length-1; i++){
          array_lines.push([array_coord[i], array_coord[i + 1]]);
      }
      array_lines.push([array_coord[array_coord.length - 1], array_coord[0]]);
      return array_lines;
  }
  discard_unnecessary_lines_coinciding_x(array_lines){
      var array_lines_new = [];
      for (var i=0; i<array_lines.length; i++){
          var line = array_lines[i];
          if (line[0][1] != line[1][1]){
            array_lines_new.push(line);
          }
      }
      return array_lines_new;
  }
  discard_unnecessary_lines(coord, array_lines){
      var array_lines_new = [];
      for (var index=0; index<array_lines.length; index++){
          var line = array_lines[index];
          if ((line[0][1] < coord[1] && coord[1] < line[1][1]) || (line[1][1] < coord[1] && coord[1] < line[0][1])){
              array_lines_new.push(line);
          }
          else if (line[1][1] == coord[1]){
              var line_next = array_lines[(index + 1) % array_lines.length];
              if ((line[0][1] < coord[1] && coord[1] < line_next[1][1]) || (line_next[1][1] < coord[1] && coord[1] < line[0][1])){
                  array_lines_new.push(line);
              }
          }
      }
      return array_lines_new;
  }
  determine_line_position(coord, line){
      var y1 = line[0][0]; var x1 = line[0][1];
      var y2 = line[1][0]; var x2 = line[1][1];
      var y3 = coord[0]; var x3 = coord[1];
      if (y1 == y3 && y2 == y3){
          return 'on the line';
      }
      else if (y1 >= y3 && y2 >= y3){
          return 'bottom';
      }
      else if (y1 <= y3 && y2 <= y3){
          return 'top';
      }
      else{
          var tg1 = Math.abs((y2 - y1) / (x2 - x1));
          var tg2 = Math.abs((y3 - y1) / (x3 - x1));
          if (tg1 == tg2){
              var position = 'on the line';
          }
          if (y1 < y2){
              if (tg1 > tg2){ var position = 'bottom'; }else{ var position = 'top'; }
          }
          else if (y1 > y2){
              if (tg1 > tg2){ var position = 'top'; }else{ var position = 'bottom'; }
          }
          return position;
      }
  }
  determine_for_each_line_its_position(coord, array_lines){
      var positions = [];
      for (var i=0; i<array_lines.length; i++){
          var line = array_lines[i];
          var response = this.determine_line_position(coord, line);
          if (response == 'top'){
              positions.push(true);
          }
          else if (response == 'bottom'){
              positions.push(false);
          }
          else{ return [true]; }
        }
      return positions;
  }
  // It is main function in this class
  Is_point_in_polygon(coord, array_coord){
      var array_lines = this.split_coordinates_into_lines_by_2_points(array_coord);
      var array_lines_new = this.discard_unnecessary_lines_coinciding_x(array_lines);
      var array_lines_new = this.discard_unnecessary_lines(coord, array_lines_new);
      var positions = this.determine_for_each_line_its_position(coord, array_lines_new);
      var number_of_lines_on_top = positions.filter(x => x).length;
      if (number_of_lines_on_top % 2 == 1){
          return true;
      }
      else{
          return false;
      }
  }
}


class MapHouse_Map_Library{
  constructor(){
    this.polygon = new __Polygon();
  }
}
const MML = new MapHouse_Map_Library();
