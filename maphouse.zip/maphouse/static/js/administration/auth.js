// --- request functions
// request GET  json function
async function request_for_json(url){

  let response = await fetch(url);
  if (response.ok) {
    var json = await response.json();
    return json
  }
  else{
    return response
  }
}
// request POST json function
async function request_for_json_post(url, data, basik=false){
  // проверяем на базовость
  if (basik){ var data_main = data;                 headers = {'X-CSRFToken': csrf_token}; }
  else{       var data_main = JSON.stringify(data); headers = {'Content-Type': 'application/json;charset=utf-8', 'X-CSRFToken': csrf_token}; }
  // заполянем запрос
  header = {
    method: 'POST',
    headers: headers,
    body: data_main
  };
  let response = await fetch(url, header);
  if (response.ok) {
    var json = await response.json();
    return json
  }
  else{
    return response
  }
}
// --- comparison functions
function comparison_dicts(dict1, dict2){
  if (JSON.stringify(dict1) == JSON.stringify(dict2)){ return true; }
  return false;
}
// перевести слово секунды в нормальный вид
function read_second(sec){
  sec = sec % 10;
  if ([5, 6, 7, 8, 9, 0].includes(sec)){ return 'секунд'; }
  else if ([2, 3, 4].includes(sec)){ return 'секунды'; }
  else{ return 'секунда'; }
}
// прописываем сколько времени осталось
async function forget_password_time_left(type = 'code'){
  down_error = $(`#down_error`);
  if (!data.mode.forget_password.time_down || down_error.length == 0){ return; }
  data.mode.forget_password.time_left --;
  if (data.mode.forget_password.time_left <= 0){ down_error.remove(); data.mode.forget_password.time_down = false; }
  else{
    text_second = read_second(data.mode.forget_password.time_left);
    if (type == 'code'){
      down_error.html(`Нельзя менять код раньше, чем через минуту (осталось ${data.mode.forget_password.time_left} ${text_second})`);
    }
    else if (type == 'password'){
      down_error.html(`Нельзя менять пароль раньше, чем через минуту (осталось ${data.mode.forget_password.time_left} ${text_second})`);
    }
    setTimeout(async function(){ await forget_password_time_left(type = type); }, 1000);
  }
}
// показать, скрыть пароль
async function show_password(field_index){
  inputbox = $(`#inputbox_${field_index}`);
  input = inputbox.find(`#input_${field_index}`);
  button = inputbox.find('.main_container-eye');
  if (input.attr('type') == 'password'){
    input.attr('type', 'text');
    button.html('H');
    button.attr('title', 'Скрыть пароль');
  }
  else{
    input.attr('type', 'password');
    button.html('S');
    button.attr('title', 'Показать пароль');
  }
}

// -------------------------------- main code
// ---- global vars
var data = {
  'mode': {
    'authtorize': {
      'height_main_container': 605,
      'fields': {
        1: {'type': 'usual', 'type_input': 'text', 'label_text': 'Email', 'forget_password': false, 'eye': false},
        2: {'type': 'usual', 'type_input': 'password', 'label_text': 'Password', 'forget_password': true, 'eye': false},
      },
      'edit_values': {},
      'edit_values_errors': {},
      'quantity': 0
    },
    'register': {
      'punkt_register': 1,
      'height_main_container': 605,
      'fields': {
        1: {'type': 'register_punkt_1', 'type_input': 'radio', 'label_text': 'Частное лицо', 'forget_password': false, 'checked': true, 'eye': false},
        2: {'type': 'register_punkt_1', 'type_input': 'radio', 'label_text': 'Агент, риэлтор', 'forget_password': false, 'eye': false},
        3: {'type': 'register_punkt_1', 'type_input': 'radio', 'label_text': 'Застройщик', 'forget_password': false, 'eye': false}
      },
      'value': 'Частное лицо',
      'Частное лицо': {
        'height_main_container': 720,
        'fields': {
          1: {'type': 'usual', 'type_input': 'text', 'label_text': 'Имя', 'forget_password': false, 'eye': false},
          2: {'type': 'usual', 'type_input': 'text', 'label_text': 'Email', 'forget_password': false, 'eye': false},
          3: {'type': 'usual', 'type_input': 'password', 'label_text': 'Пароль', 'forget_password': false, 'eye': true},
          4: {'type': 'usual', 'type_input': 'password', 'label_text': 'Подтвердите пароль', 'forget_password': false, 'eye': true},
          5: {'type': 'usual', 'type_input': 'text', 'label_text': 'Телефон', 'forget_password': false, 'eye': false},
        },
        'edit_values': {},
        'edit_values_errors': {},
        'quantity': 0
      },
      'Агент, риэлтор': {
        'height_main_container': 720,
        'fields': {
          1: {'type': 'usual', 'type_input': 'text', 'label_text': 'ФИО', 'forget_password': false, 'eye': false}
        },
        'edit_values': {},
        'edit_values_errors': {},
        'quantity': 0
      },
      'Застройщик': {
        'height_main_container': 720,
        'fields': {
          1: {'type': 'usual', 'type_input': 'text', 'label_text': 'ФИО', 'forget_password': false, 'eye': false}
        },
        'edit_values': {},
        'edit_values_errors': {},
        'quantity': 0
      }
    },
    'forget_password': {
      'wait_time': false,
      'height_main_container': 605,
      'punkt': 1,
      'edit_values': {},
      'fields': {
        1: {'type': 'usual', 'type_input': 'text', 'label_text': 'Email', 'forget_password': false, 'eye': false},
      },
      'time_down': false,
      'time_passed': 60,
      'time_left': 60,
      'quantity': 0,
      'code': {
        'height_main_container': 605,
        'edit_values': {},
        'fields': {
          1: {'type': 'usual', 'type_input': 'text', 'label_text': 'Код', 'forget_password': false, 'eye': false},
        },
        'quantity': 0
      },
      'new_password': {
        'height_main_container': 605,
        'edit_values': {},
        'fields': {
          1: {'type': 'usual', 'type_input': 'password', 'label_text': 'Новый пароль', 'forget_password': false, 'eye': true},
          2: {'type': 'usual', 'type_input': 'password', 'label_text': 'Подтвердите пароль', 'forget_password': false, 'eye': true},
        },
        'quantity': 0
      }
    }
}};

// ---- events vars
// трансформированные прямоугольники (фон)
background1 = $('.background1');
background2 = $('.background2');
// главное окно заполнения формы
main_container = $('.main_container');
main_container_footer = $('.main_container-footer');
main_container_arrow = $('.main_container-back_button');
// восстановление пароля
forget_password_container = $('.forget_password_container');

start_window = true;


// ============================ functions
// ----- функции показа ошибок
async function open_error(field_index, text='Поле заполнено некорректно'){
  // находим поле
  inputbox = $(`#inputbox_${field_index}`);
  error_line = `<div id='error_${field_index}' class='main_container-error'>${text}</div>`;
  inputbox.after(error_line);
  // делаем поле красным
  input_label = inputbox.find('.main_container-input_label');
  input_underline = inputbox.find('.main_container-input_underline');
  if (inputbox.find(`#input_${field_index}`).val() != ''){ input_label.css({'color': 'red'}); }
  input_underline.css({'background': 'red', 'width': '90%'});
}

// ----- проверяющие функции
async function check_right_email(text, field_index = 1){
  if (text.trim() == ''){ await open_error(field_index, text='Поле не должно быть пустым'); return false; }
  if (text.trim().split(' ').length > 1){ await open_error(field_index, text='В этом поле не может быть пробелов'); return false; }
  if (!text.includes('@')){ await open_error(field_index, text='Нет символа @'); return false; }
  listic = text.split('@');
  if (listic.length != 2){ await open_error(field_index, text='Знаков @ больше одного'); return false; }
  name = listic[0]; server = listic[1];
  if (name.trim() == ''){ await open_error(field_index, text='Нет логина почты'); return false; }
  if (server.trim() == ''){ await open_error(field_index, text='Нет домена почты'); return false; }
  if (!server.includes('.')){ await open_error(field_index, text='Нет доменного разделения'); return false; }
  return true;
}

async function check_right_password(text, field_index = 1){
  if (text.trim() == ''){ await open_error(field_index, text='Поле не должно быть пустым'); return false; }
  if (text.trim().length < 8){ await open_error(field_index, text='Пароль должен быть длиннее 8 символов'); return false; }
  if (text.trim().split(' ').length > 1){ await open_error(field_index, text='В пароле не должно быть пробелов'); return false; }
  return true;
}

// ----- отправляющие функции
async function authtorize(){
  // получаем значения
  edit_values_old = data.mode.authtorize.edit_values;
  await get_values_from_main_container(mode);
  fields = data.mode.authtorize.fields;
  edit_values = data.mode.authtorize.edit_values;
  // проверяем, не нажал ли пользователь кнопку много раз
  down_error_el = $(`#down_error`);
  if (comparison_dicts(edit_values_old, edit_values) && down_error_el.length > 0){ return; }
  // удаляем ошибку сервера внизу (если есть)
  if (down_error_el.length > 0){ down_error_el.remove(); }
  // проходимся по полям
  for (field_index in fields){
    inf = fields[field_index];
    value = edit_values[field_index];
    // обнуляем (убираем) предыдущую ошибку
    error_el = $(`#error_${field_index}`);
    if (error_el.length > 0){ error_el.remove(); }
    inputbox = $(`#inputbox_${field_index}`);
    inputbox.find('.main_container-input_label').css({'color': ''});
    inputbox.find('.main_container-input_underline').css({'background': '#4caf50', 'width': ''});
    // проверка на правильность
    if (inf.label_text == 'Email'){ result = await check_right_email(value, field_index = field_index); if (!result){ return; }}
    else if (inf.label_text == 'Password'){ /* пароль не надо проверять тут */ }
  }
  // отправляем на сервер
  email = edit_values[1]; password = edit_values[2];
  data_request = {'email': email, 'password': password};
  url = '/admin/auth/authtorize';
  result = await request_for_json_post(url, data_request, basik=false);
  if (result.status == 'ok'){ window.location.replace(further_url); }
  else{
    // открываем ошибку после всех полей
    list_fields_el = $(`.main_container-fields_list`);
    error_line = `<div id='down_error' class='main_container-down_error'>${result.error}</div>`;
    list_fields_el.append(error_line);
  }
  return;
}

async function send_email_forget_password(){
  // получаем значения
  edit_values_old = data.mode.forget_password.edit_values;
  await get_values_from_main_container('forget_password');
  fields = data.mode.forget_password.fields;
  edit_values = data.mode.forget_password.edit_values;
  // проверяем, не нажал ли пользователь кнопку много раз
  down_error_el = $(`#down_error`);
  if (comparison_dicts(edit_values_old, edit_values) && down_error_el.length > 0 || data.mode.forget_password.time_down){ return false; }
  else{
    clearTimeout(data.mode.forget_password.time_passed);
  }
  // удаляем ошибку сервера внизу (если есть)
  if (down_error_el.length > 0){ down_error_el.remove(); } // проходимся по полям
  for (field_index in fields){
    inf = fields[field_index];
    value = edit_values[field_index];
    // обнуляем (убираем) предыдущую ошибку
    error_el = $(`#error_${field_index}`);
    if (error_el.length > 0){ error_el.remove(); }
    inputbox = $(`#inputbox_${field_index}`);
    inputbox.find('.main_container-input_label').css({'color': ''});
    inputbox.find('.main_container-input_underline').css({'background': '#4caf50', 'width': ''});
    // проверка на правильность
    if (inf.label_text == 'Email'){ result = await check_right_email(value, field_index = field_index); if (!result){ return false; }}
  }
  // отправляем на сервер
  email = edit_values[1];
  data_request = {'email': email};
  url = '/admin/auth/send_code_to_recovery_password';
  result = await request_for_json_post(url, data_request, basik=false);
  if (result.status == 'ok'){ return true; }
  else{
    if (result.status == 'Time has not passed'){
      data.mode.forget_password.time_left = result.time_left;
      data.mode.forget_password.time_down = true;
      data.mode.forget_password.time_passed = setTimeout(async function(){ forget_password_time_left(); }, 1000);
    }
    // открываем ошибку после всех полей
    down_error_el = $(`#down_error`);
    if (down_error_el.length > 0){ down_error_el.html(result.error); }
    else{
      list_fields_el = $(`.main_container-fields_list`);
      error_line = `<div id='down_error' class='main_container-down_error'>${result.error}</div>`;
      list_fields_el.append(error_line);
    }
  }
  return false;
}

async function check_code_forget_password(){
  // получаем значения
  edit_values_old = data.mode.forget_password.code.edit_values;
  await get_values_from_main_container('forget_password');
  fields = data.mode.forget_password.code.fields;
  edit_values = data.mode.forget_password.code.edit_values;
  // проверяем, не нажал ли пользователь кнопку много раз
  down_error_el = $(`#down_error`);
  if (comparison_dicts(edit_values_old, edit_values) && down_error_el.length > 0){ return false; }
  // удаляем ошибку сервера внизу (если есть)
  if (down_error_el.length > 0){ down_error_el.remove(); } // проходимся по полям
  // отправляем на сервер
  email = data.mode.forget_password.edit_values[1]; code = edit_values[1];
  data_request = {'email': email, 'code': code};
  url = '/admin/auth/check_code_to_recovery_password';
  result = await request_for_json_post(url, data_request, basik=false);
  if (result.status == 'ok'){ return true; }
  else{
    // открываем ошибку после всех полей
    down_error_el = $(`#down_error`);
    if (down_error_el.length > 0){ down_error_el.html(result.error); }
    else{
      list_fields_el = $(`.main_container-fields_list`);
      error_line = `<div id='down_error' class='main_container-down_error'>${result.error}</div>`;
      list_fields_el.append(error_line);
    }
  }
  return false;
}

async function save_new_password_forget_password(){
  // получаем значения
  var edit_values_old = data.mode.forget_password.new_password.edit_values;
  await get_values_from_main_container('forget_password');
  fields = data.mode.forget_password.new_password.fields;
  var edit_values = data.mode.forget_password.new_password.edit_values;
  // проверяем, не нажал ли пользователь кнопку много раз
  down_error_el = $(`#down_error`);
  if (comparison_dicts(edit_values_old, edit_values) && down_error_el.length > 0 || data.mode.forget_password.time_down){ return false; }
  else{
    clearTimeout(data.mode.forget_password.time_passed);
  }
  // удаляем ошибку сервера внизу (если есть)
  if (down_error_el.length > 0){ down_error_el.remove(); } // проходимся по полям
  for (field_index in fields){
    inf = fields[field_index];
    value = edit_values[field_index];
    // обнуляем (убираем) предыдущую ошибку
    error_el = $(`#error_${field_index}`);
    if (error_el.length > 0){ error_el.remove(); }
    inputbox = $(`#inputbox_${field_index}`);
    inputbox.find('.main_container-input_label').css({'color': ''});
    inputbox.find('.main_container-input_underline').css({'background': '#4caf50', 'width': ''});
    // проверка на правильность
    if (inf.label_text == 'Новый пароль'){ result = await check_right_password(value, field_index = field_index); if (!result){ return false; }}
    if (inf.label_text == 'Подтвердите пароль'){ if (edit_values[1] != edit_values[2]){ await open_error(field_index, text='Пароли не совпадают'); return false; }}
  }
  // отправляем на сервер
  email = data.mode.forget_password.edit_values[1]; code = data.mode.forget_password.code.edit_values[1];
  data_request = {'email': email, 'code': code, 'password': edit_values[1]};
  url = '/admin/auth/save_new_password_forget_password';
  result = await request_for_json_post(url, data_request, basik=false);
  if (result.status == 'ok'){ window.location.replace(further_url); }
  else{
    if (result.status == 'Time has not passed (new password)'){
      data.mode.forget_password.time_left = result.time_left;
      data.mode.forget_password.time_down = true;
      data.mode.forget_password.time_passed = setTimeout(async function(){ forget_password_time_left(type = 'password'); }, 1000);
    }
    // открываем ошибку после всех полей
    down_error_el = $(`#down_error`);
    if (down_error_el.length > 0){ down_error_el.html(result.error); }
    else{
      list_fields_el = $(`.main_container-fields_list`);
      error_line = `<div id='down_error' class='main_container-down_error'>${result.error}</div>`;
      list_fields_el.append(error_line);
    }
  }
  return false;
}


// ----- сохраняющие функции
async function get_value_from_field(field_index, field_type = 'usual'){
  var value = '';
  if (field_type == 'usual'){
    value = $(`#input_${field_index}`).val();
  }
  return value;
}

async function get_values_from_main_container(mode){
  var edit_values = {};
  if (mode == 'authtorize'){
    fields = data.mode.authtorize.fields;
    quantity = 0;
    for (field_index in fields){
      quantity ++;
      field_type = fields[field_index].type;
      value = await get_value_from_field(field_index, field_type = field_type);
      edit_values[field_index] = value;
    }
    data.mode.authtorize.edit_values = edit_values;
    data.mode.authtorize.quantity = quantity;
  }
  else if (mode == 'register'){
    punkt = data.mode.register.punkt_register;
    if (punkt == 1){ /* это обрабатывает функция next_step */ }
    else if (punkt == 2){
      fields = data.mode.register[data.mode.register.value].fields;
      quantity = 0;
      for (field_index in fields){
        quantity ++;
        field_type = fields[field_index].type;
        value = await get_value_from_field(field_index, field_type = field_type);
        edit_values[field_index] = value;
      }
      data.mode.register[data.mode.register.value].edit_values = edit_values;
      data.mode.register[data.mode.register.value].quantity = quantity;
    }
  }
  if (mode == 'forget_password'){
    var punkt = data.mode.forget_password.punkt;
    if (punkt == 1){ var fields = data.mode.forget_password.fields; }
    else if (punkt == 2){ var fields = data.mode.forget_password.code.fields; }
    else if (punkt == 3){ var fields = data.mode.forget_password.new_password.fields; }
    var quantity = 0;
    for (field_index in fields){
      quantity ++;
      var field_type = fields[field_index].type;
      value = await get_value_from_field(field_index, field_type = field_type);
      edit_values[field_index] = value;
    }
    if (punkt == 1){
      data.mode.forget_password.edit_values = edit_values;
      data.mode.forget_password.quantity = quantity;
    }
    else if (punkt == 2){
      data.mode.forget_password.code.edit_values = edit_values;
      data.mode.forget_password.code.quantity = quantity;
    }
    else if (punkt == 3){
      data.mode.forget_password.new_password.edit_values = edit_values;
      data.mode.forget_password.new_password.quantity = quantity;
    }
  }
}

async function push_value_to_field(value, field_index, field_type = 'usual'){
  if (type == 'usual'){
    input = $(`#input_${field_index}`);
    input.val(value);
  }
  return;
}

async function push_values_to_main_container(mode){
  if (mode == 'authtorize'){
    fields = data.mode.authtorize.fields;
    edit_values = data.mode.authtorize.edit_values;
    quantity = data.mode.authtorize.quantity;
    if (quantity == 0){ return; }
    for (field_index in fields){
      field_type = fields[field_index].type;
      value = edit_values[field_index];
      await push_value_to_field(value, field_index, field_type = field_type);
    }
  }
  else if (mode == 'register'){
    punkt = data.mode.register.punkt_register;
    if (punkt == 1){
      value = data.mode.register.value;
      $(`.main_container-radio_input[name="register_punkt_1"][value="${value}"]`).prop('checked', true);
    }
    else if (punkt == 2){
      fields = data.mode.register[data.mode.register.value].fields;
      edit_values = data.mode.register[data.mode.register.value].edit_values;
      quantity = data.mode.register[data.mode.register.value].quantity;
      if (quantity == 0){ return; }
      for (field_index in fields){
        field_type = fields[field_index].type;
        value = edit_values[field_index];
        await push_value_to_field(value, field_index, field_type = field_type);
      }
    }
  }
  else if (mode == 'forget_password'){
    punkt = data.mode.forget_password.punkt;
    if (punkt == 1){
      fields = data.mode.forget_password.fields;
      edit_values = data.mode.forget_password.edit_values;
      quantity = data.mode.forget_password.quantity;
      if (quantity == 0){ return; }
      for (field_index in fields){
        field_type = fields[field_index].type;
        value = edit_values[field_index];
        await push_value_to_field(value, field_index, field_type = field_type);
      }
    }
    else if (punkt == 2){
      fields = data.mode.forget_password.code.fields;
      edit_values = data.mode.forget_password.code.edit_values;
      quantity = data.mode.forget_password.code.quantity;
      if (quantity == 0){ return; }
      for (field_index in fields){
        field_type = fields[field_index].type;
        value = edit_values[field_index];
        await push_value_to_field(value, field_index, field_type = field_type);
      }
    }
    else if (punkt == 3){
      fields = data.mode.forget_password.new_password.fields;
      edit_values = data.mode.forget_password.new_password.edit_values;
      quantity = data.mode.forget_password.new_password.quantity;
      if (quantity == 0){ return; }
      for (field_index in fields){
        field_type = fields[field_index].type;
        value = edit_values[field_index];
        await push_value_to_field(value, field_index, field_type = field_type);
      }
    }
  }
  return;
}

// ----- создающие функции
async function create_inputbox(index_field, type = 'usual', type_input = 'text', label_text = 'Email', forget_password = false, checked = false, eye=false){
  if (forget_password){ forget_password_text = `<span class='main_container-forget_password' title='Забыли пароль?' onclick='scenario("forget_password");'>?</span>`; }
  else{ forget_password_text = ''; }
  if (eye){ eye_text = `<span class='main_container-eye' title='Показать пароль' onclick='show_password(${index_field});'>S</span>`; }
  else{ eye_text = ''; }
  // проверка по типам
  if (type == 'usual'){
    html_text = `
    <dl class="main_container-inputbox" id='inputbox_${index_field}'>
      <dd class="main_container-inputbox_content">
        <input class='main_container-input' id="input_${index_field}" type="${type_input}" required />
        <label class='main_container-input_label' for="input_${index_field}">${label_text}</label>
        <span class="main_container-input_underline"></span>
        ${forget_password_text} ${eye_text}
      </dd>
    </dl>
    `;
  }
  else if (type == 'register_punkt_1'){
    if (checked){ checked_text = 'checked'; }
    else{ checked_text = ''; }
    html_text = `
    <label class='main_container-radio_label'>
      <input class='main_container-radio_input' name='register_punkt_1' id="input_${index_field}" type="${type_input}" value="${label_text}" ${checked_text} required />
      <span class="main_container-radio_design"></span>
      <span class="main_container-radio_text">${label_text}</span>
    </label>
    `;
  }
  return html_text;
}

async function create_fields_for_mode(fields){
  // добавляем поля редактирования
  el_add_list = $('.main_container-fields_list');
  full_html_text = '';
  for (index_field in fields){
    inf = fields[index_field];
    if ('checked' in inf){ checked = inf.checked; }
    else{ checked = false; }
    html_text = await create_inputbox(index_field, type = inf.type, type_input = inf.type_input, label_text = inf.label_text, forget_password = inf.forget_password, checked = checked, eye = inf.eye);
    full_html_text += html_text;
  }
  el_add_list.html(full_html_text);
}

async function change_text_down_button(mode){
  // меняем нижние кнопки
  header = $('.main_container-header');
  submit_button = $('.main_container-login_button');
  signature = $('.main_container-no_accaunt');
  if (mode == 'authtorize'){
    if (header.html() != 'Авторизация'){ header.html('Авторизация'); }
    submit_button.html('Войти');
    submit_button.css({'font-size': 18});
    submit_button.attr('onclick', 'authtorize();');
    signature.html(`Нет аккаунта? <span class='main_container-register_button' onclick='scenario("register");'>Регистрация</span>`);
  }
  else if (mode == 'register_medium'){
    if (header.html() != 'Регистрация'){ header.html('Регистрация'); }
    submit_button.html('Дальше');
    submit_button.css({'font-size': 18});
    submit_button.attr('onclick', 'next_step();');
    signature.html(`Есть аккаунт? <span class='main_container-register_button' onclick='scenario("authtorize");'>Авторизация</span>`);
  }
  else if (mode == 'register'){
    if (header.html() != 'Регистрация'){ header.html('Регистрация'); }
    submit_button.html('Закончить');
    submit_button.css({'font-size': 17});
    submit_button.attr('onclick', 'registration();');
    signature.html(`Есть аккаунт? <span class='main_container-register_button' onclick='scenario("authtorize");'>Авторизация</span>`);
  }
  else if (mode == 'forget_password'){
    if (header.html() != 'Восстановление'){ header.html('Восстановление'); }
    if (data.mode.forget_password.punkt == 1){
      submit_button.html('Отправить');
      submit_button.css({'font-size': 17});
      submit_button.attr('onclick', 'next_step_forget_password();');
      signature.html(`Вспомнили? <span class='main_container-register_button' onclick='scenario("authtorize");'>Авторизация</span>`);
    }
    else if (data.mode.forget_password.punkt == 2){
      submit_button.html('Проверить');
      submit_button.css({'font-size': 17});
      submit_button.attr('onclick', 'next_step_forget_password();');
      signature.html(`Вспомнили? <span class='main_container-register_button' onclick='scenario("authtorize");'>Авторизация</span>`);
    }
    else if (data.mode.forget_password.punkt == 3){
      submit_button.html('Сохранить');
      submit_button.css({'font-size': 17});
      submit_button.attr('onclick', 'next_step_forget_password();');
      signature.html(`Вспомнили? <span class='main_container-register_button' onclick='scenario("authtorize");'>Авторизация</span>`);
    }
  }
}

async function set_height_main_container(mode, window_resize = false){
  if (mode == 'authtorize'){ height_main_container = data.mode.authtorize.height_main_container; }
  else if (mode == 'register'){
    punkt = data.mode.register.punkt_register;
    if (punkt == 1){ height_main_container = data.mode.register.height_main_container; }
    else if (punkt == 2){ height_main_container = data.mode.register[data.mode.register.value].height_main_container; }
  }
  else if (mode == 'forget_password'){
    punkt = data.mode.forget_password.punkt;
    if (punkt == 1){ height_main_container = data.mode.forget_password.height_main_container; }
    else if (punkt == 2){ height_main_container = data.mode.forget_password.code.height_main_container; }
    else if (punkt == 3){ height_main_container = data.mode.forget_password.new_password.height_main_container; }
  }
  if (window_resize){
    main_container.css({'transition': '0s', 'height': height_main_container});
    main_container_footer.css({'transition': '0s', 'margin-top': height_main_container - 69});
  }
  else{
    main_container.css({'height': height_main_container, 'transition': 'height 0.2s'});
    main_container_footer.css({'margin-top': height_main_container - 69, 'transition': 'margin-top 0.2s'});
  }
}

// ----- функции сценария
async function scenario(mode_new){
  // меняем адрес в строке браузера
  window.history.pushState(null, null, `?mode=${mode_new}&further_url=${further_url}`);
  // проходимся по вариантам модов
  if (mode_new == 'authtorize'){
    // если до этого был другой мод, то сохраняем значения
    if (mode == 'register'){
      punkt = data.mode.register.punkt_register;
      if (punkt == 1){
        value = $('.main_container-radio_input[name="register_punkt_1"]:checked').val();
        data.mode.register.value = value;
      }
      else if (punkt == 2){
        await get_values_from_main_container('register');
      }
    }
    if (mode == 'forget_password'){
      punkt = data.mode.forget_password.punkt;
      if (punkt == 1){
        await get_values_from_main_container('forget_password');
      }
      // выключаем отсчёт на всякий случай
      clearTimeout(data.mode.forget_password.time_passed);
      data.mode.forget_password.time_down = false;
    }
    window['mode'] = 'authtorize';
    await create_fields_for_mode(data.mode.authtorize.fields);
    await change_text_down_button(mode_new);
    fields_list = $('.main_container-fields_list');
    fields_list.css({'margin-top': 0, 'margin-bottom': 0});
    main_container_arrow.css({'transform': 'scale(0.0)'});
    main_container_arrow.attr('onclick', 'back_step();');
    // вставляем значения
    await push_values_to_main_container(mode_new);
    await window_events();
    // меняем на нужную высоту
    if (start_window){ window_resize = true; window['start_window'] = false; }
    else{ window_resize = false; }
    await set_height_main_container('authtorize', window_resize = window_resize);
  }
  else if (mode_new == 'register'){
    // если до этого был другой мод, то сохраняем значения
    if (mode == 'authtorize'){
      await get_values_from_main_container('authtorize');
    }
    window['mode'] = 'register';
    punkt = data.mode.register.punkt_register;
    if (punkt == 1){
      await create_fields_for_mode(data.mode.register.fields);
      await change_text_down_button('register_medium');
      fields_list = $('.main_container-fields_list');
      fields_list.css({'margin-top': -15, 'margin-bottom': 15});
      main_container_arrow.css({'transform': 'scale(0.0)'});
      main_container_arrow.attr('onclick', 'back_step();');
      // вставляем значения
      await push_values_to_main_container(mode_new);
      await window_events();
    }
    else if (punkt == 2){
      value_punkt_1 = data.mode.register.value;
      await create_fields_for_mode(data.mode.register[value_punkt_1].fields);
      await change_text_down_button('register');
      fields_list = $('.main_container-fields_list');
      fields_list.css({'margin-top': 0, 'margin-bottom': 0});
      main_container_arrow.css({'transform': 'scale(1.0)'});
      main_container_arrow.attr('onclick', 'back_step();');
      // вставляем значения
      await push_values_to_main_container(mode_new);
      await window_events();
    }
    // меняем на нужную высоту
    if (start_window){ window_resize = true; window['start_window'] = false; }
    else{ window_resize = false; }
    await set_height_main_container('register', window_resize = window_resize);
  }
  else if (mode_new == 'forget_password'){
    // если до этого был другой мод, то сохраняем значения
    if (mode == 'authtorize'){
      await get_values_from_main_container('authtorize');
    }
    window['mode'] = 'forget_password';
    punkt = data.mode.forget_password.punkt;
    if (punkt == 1){
      // выключаем отсчёт на всякий случай
      clearTimeout(data.mode.forget_password.time_passed);
      data.mode.forget_password.time_down = false;
      // дальше
      await create_fields_for_mode(data.mode.forget_password.fields);
      await change_text_down_button('forget_password');
      fields_list = $('.main_container-fields_list');
      fields_list.css({'margin-top': 0, 'margin-bottom': 0});
      main_container_arrow.css({'transform': 'scale(0.0)'});
      // вставляем значения
      await push_values_to_main_container('forget_password');
      await window_events();
      // меняем на нужную высоту
      if (start_window){ window_resize = true; window['start_window'] = false; }
      else{ window_resize = false; }
      await set_height_main_container('forget_password', window_resize = window_resize);
      // добавляем в конце текст
      notification_line = `<div class='main_container-forget_password-notification'>Введите почту от аккаунта и мы отправим на этот адрес письмо с кодом доступа</div>`;
      fields_list.prepend(notification_line);
    }
    if (punkt == 2){
      // выключаем отсчёт на всякий случай
      clearTimeout(data.mode.forget_password.time_passed);
      data.mode.forget_password.time_down = false;
      // дальше
      await create_fields_for_mode(data.mode.forget_password.code.fields);
      await change_text_down_button('forget_password');
      fields_list = $('.main_container-fields_list');
      fields_list.css({'margin-top': 0, 'margin-bottom': 0});
      main_container_arrow.css({'transform': 'scale(1.0)'});
      main_container_arrow.attr('onclick', 'back_step_forget_password();');
      // вставляем значения
      await push_values_to_main_container('forget_password');
      await window_events();
      // меняем на нужную высоту
      if (start_window){ window_resize = true; window['start_window'] = false; }
      else{ window_resize = false; }
      await set_height_main_container('forget_password', window_resize = window_resize);
      // добавляем в конце текст
      notification_line = `<div class='main_container-forget_password-notification'>Введите код доступа из письма<br>Действие кода - 7 минут</div>`;
      fields_list.prepend(notification_line);
    }
    if (punkt == 3){
      // выключаем отсчёт на всякий случай
      clearTimeout(data.mode.forget_password.time_passed);
      data.mode.forget_password.time_down = false;
      // дальше
      await create_fields_for_mode(data.mode.forget_password.new_password.fields);
      await change_text_down_button('forget_password');
      fields_list = $('.main_container-fields_list');
      fields_list.css({'margin-top': 0, 'margin-bottom': 0});
      main_container_arrow.css({'transform': 'scale(0.0)'});
      // вставляем значения
      await push_values_to_main_container('forget_password');
      await window_events();
      // меняем на нужную высоту
      if (start_window){ window_resize = true; window['start_window'] = false; }
      else{ window_resize = false; }
      await set_height_main_container('forget_password', window_resize = window_resize);
      // добавляем в конце текст
      notification_line = `<div class='main_container-forget_password-notification'>Придумайте и введите новый пароль<br>У вас есть 15 минут</div>`;
      fields_list.prepend(notification_line);
    }
  }
}

// шаги регистрации
async function next_step(){
  punkt = data.mode.register.punkt_register;
  if (punkt == 1){
    value = $('.main_container-radio_input[name="register_punkt_1"]:checked').val();
    data.mode.register.value = value;
  }
  else if (punkt == 2){
    await get_values_from_main_container('register');
  }
  data.mode.register.punkt_register ++;
  await scenario(mode);
}

async function back_step(){
  punkt = data.mode.register.punkt_register;
  if (punkt == 1){ /* такого не может быть */ }
  else if (punkt == 2){
    await get_values_from_main_container('register');
  }
  data.mode.register.punkt_register --;
  await scenario(mode);
}

// шаги восстановления пароля
async function next_step_forget_password(){
  if (data.mode.forget_password.wait_time){ return; }
  data.mode.forget_password.wait_time = true;
  punkt = data.mode.forget_password.punkt;
  if (punkt == 1){
    result = await send_email_forget_password();
    if (!result){ data.mode.forget_password.wait_time = false; return; }
  }
  else if (punkt == 2){
    result = await check_code_forget_password();
    if (!result){ data.mode.forget_password.wait_time = false; return; }
  }
  else if (punkt == 3){
    result = await save_new_password_forget_password();
    if (!result){ data.mode.forget_password.wait_time = false; return; }
  }
  data.mode.forget_password.punkt ++;
  await scenario(mode);
  data.mode.forget_password.wait_time = false;
}

async function back_step_forget_password(){
  if (data.mode.forget_password.wait_time){ return; }
  data.mode.forget_password.wait_time = true;
  punkt = data.mode.forget_password.punkt;
  if (punkt == 1){ /* такого не может быть */ }
  else if (punkt == 2){
    data.mode.forget_password.code.edit_values = {};
    data.mode.forget_password.new_password.edit_values = {};
  }
  data.mode.forget_password.punkt --;
  await scenario(mode);
  data.mode.forget_password.wait_time = false;
}
// ============================ end.

// ------------------------ resize scale window
// ----- events
async function resize(){
  wh = window.innerHeight; ww = window.innerWidth;
  wh_half = Math.round(wh / 2); ww_half = Math.round(ww / 2);
  // главное окно
  // трансформированные прямоугольники
  background1.css({'height': wh, 'width': ww_half + 500, 'left': -500});
  background2.css({'height': wh, 'width': ww_half + 500, 'right': -500});
  // главное окно заполнения формы
  main_container.css({'margin-left': ww_half - 250});
  set_height_main_container(mode, window_resize = true);
}
resize();
window.addEventListener("resize", () => resize());

// ----- функция обработки происшествий на экране
async function window_events(){
  // главные переменные
  wh = window.innerHeight; ww = window.innerWidth;
  wh_half = Math.round(wh / 2); ww_half = Math.round(ww / 2);
  // делаем поле зелёными, если они красные
  $('.main_container-input').on('click', function(){
    try{
      input = $(this);
      inputbox = $(`#inputbox_${input.attr('id').split('_')[1]}`);
      inputbox.find('.main_container-input_label').css({'color': ''});
      inputbox.find('.main_container-input_underline').css({'background': '#4caf50', 'width': ''});
    }
    catch{}
  });
};

$(function(){ window_events(); });

// нажатия по клавишам
document.onkeydown = fkey;
function fkey(e){
  e = e || window.event;
  if (e.keyCode == 13){
    $('.main_container-login_button').trigger('click');
  }
 }

// ----- запускаем сценарий мода
scenario(mode);


// end.
