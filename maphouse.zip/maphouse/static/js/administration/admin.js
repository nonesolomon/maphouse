// =========================================== просто полезные функции
// выйти из аккаунта
async function logout(){
  window.location.replace('/admin/auth/logout');
}

// поставить нолик в начале
function readable_time(number){
  var number = Number(number);
  if (number < 10){ return '0' + number.toString(); }
  return number.toString();
}

// прочитать текст из файла
async function enter_value_from_file(field_index, type_inner_file='application/json'){
  // значения поля
  var field = $('#field_' + field_index);
  var input_field = field.find('#field_input_' + field_index);
  // находим ввод файла внизу
  var input_file = field.find(`#field_read_from_file_input_${field_index}`);
  input_file.click();
  input_file.on('change', function(){
    var file = this.files[0];
    // проверяем типы
    var type_file = file.type;
    if (type_file != type_inner_file){
      var n_text = `<span style='font-size: 16px;'>Не подходит тип файла<br><span style='font-size: 13px;'>Нужен формат - (${type_inner_file})</span></span>`;
      open_notification('error', n_text);
    }
    else{
      // если файл открыли, то получаем значение (читаем)
      var reader = new FileReader();
      reader.onload = function(){
        var inner_file_text = reader.result;
        // вписыаем в поле
        input_field.html(inner_file_text);
      }
      reader.readAsText(file);
    }
  });
}

// рандомное значение массива
function random_array_el(arr) {
    var rand = Math.floor(Math.random() * arr.length);
    return arr[rand];
}

// посмотреть методы класса
function view_methods_on_object(ob){
  for (key in ob){
    console.log(key);
  }
}

// получить по номеру месяц
data_month = {'number': {1: 'январь', 2: 'февраль', 3: 'март', 4: 'апрель', 5: 'май', 6: 'июнь', 7: 'июль', 8: 'август', 9: 'сентябрь', 10: 'октябрь', 11: 'ноябрь', 12: 'декабрь'},
              'month': {'январь': 1, 'февраль': 2, 'март': 3, 'апрель': 4, 'май': 5, 'июнь': 6, 'июль': 7, 'август': 8, 'сентябрь': 9, 'октябрь': 10, 'ноябрь': 11, 'декабрь': 12},
              'days': {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}};

// функция "Слово с заглавной буквы"
const capitalize = (str, lower = false) =>
  (lower ? str.toLowerCase() : str).replace(/(?:^|\s|["'([{])+\S/g, match => match.toUpperCase());
;

// сортировка по полю
function byField(field) {
  return (a, b) => a[field] > b[field] ? 1 : -1;
}

// request json function
async function request_for_json(url){

  let response = await fetch(url);
  if (response.ok) {
    var json = await response.json();
    return json
  }
  else{
    return response
  }
}
// request POST json function
async function request_for_json_post(url, data, basik=false){
  // проверяем на базовость
  if (basik){ var data_main = data;                 var headers = {'X-CSRFToken': csrf_token}; }
  else{       var data_main = JSON.stringify(data); var headers = {'Content-Type': 'application/json;charset=utf-8', 'X-CSRFToken': csrf_token}; }
  // заполянем запрос
  var header = {
    method: 'POST',
    headers: headers,
    body: data_main
  };
  let response = await fetch(url, header);
  if (response.ok) {
    var json = await response.json();
    return json
  }
  else{
    return response
  }
}


// изображение на весь экран
function open_image_in_full_window(src, bl = true){
  var img = $('.dark-strong-img-center');
  var dark = $('.dark-strong');
  if (bl){
    img.attr('src', src);
    // меняем размер
    img.on('load', function(){
      wh = window.innerHeight; ww = window.innerWidth;
      nh = this.naturalHeight; nw = this.naturalWidth;
      // случаи рассматриваем
      if (wh > nh && ww > nw){
        img.css({'height': nh, 'width': nw, 'top': Math.round((wh - nh) / 2), 'left': Math.round((ww - nw) / 2)});
      }
      else{
        // находим наибольшее отношение
        var max_attitude = Math.max.apply(null, [nh / (wh - 100), nw / (ww - 100)]);
        var new_h = Math.round(nh / max_attitude);
        var new_w = Math.round(nw / max_attitude)
        img.css({'height': new_h, 'width': new_w, 'top': Math.round((wh - new_h) / 2), 'left': Math.round((ww - new_w) / 2)});
      }
      img.css({'display': 'inline'});
      dark.css({'opacity': 0.7, 'width': '100%', 'transition': 'opacity 0.2s'});
    });
  }
  else{
    img.css({'display': 'none'});
    dark.css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
  }
}

// ============================== MAIN CODE
var data = {'apps': '', 'models': {}, 'objects': {}, 'objects_checked': {}, 'edit': {'object': {'quantity': 0, 'data': {}}, 'new_object': {'quantity': 0, 'data': {}}}, 'bookmarks': {'quantity': 0, 'data': {}}};
index_model_global = 0;
index_object_global = 0;

// переменные для событий на экране
var data_events = {'date_choose': {
             'state': 'hide',
             'step': 1,
             'container': $('.date_choose'),
             'dark': $('.dark-strong-date'),
             'step1': $('.date_choose-step1'),
             'step2': $('.date_choose-step2'),
             'create': false,
             'year': 2020,
             'month': 'август',
             'day': 18,
             'hour': 0,
             'minute': 0,
             'second': 0,
             'utc': '+00:00',
             'quantity_days': 31,
             'container_days': undefined,
             'container_months': $('.date_choose-cont_months'),
             'date_choose_month': $('#date_choose_month'),
             'arrow': $('.date_choose-cont1-arrow_div'),
             'map_line': $('.date_choose-cont5-map-line'),
             'map_timezone': $('.date_choose-cont5-map-timezone'),
             'max_number': {'date_choose_hour': 23, 'date_choose_minute': 59, 'date_choose_second': 59}}};

// ---- vars events
dark = $('.dark');
dark_strong = $('.dark-strong');
textarea_main_div = $('.textarea_full_screen-div');
textarea_main = $('.textarea_full_screen');

// открыть textarea на весь экран
textarea_full_screen_mode_open = false;
textarea_full_screen_field_index = 0;
async function open_textarea_full_screen(field_index=0, bl=false){
  if (bl){
    if (textarea_full_screen_mode_open){ return; }
    if (field_index == 0){ return; }
    var input = $(`#field_input_${field_index}`);
    var value = input.val();
    // открываем ввод на весь экран
    dark_strong.css({'opacity': 0.7, 'width': '100%', 'transition': 'opacity 0.2s'});
    textarea_main_div.css({'display': 'inline'});
    textarea_main.val(value);
    window['textarea_full_screen_mode_open'] = true;
    window['textarea_full_screen_field_index'] = field_index;
  }
  else{
    if (!textarea_full_screen_mode_open){ return; }
    dark_strong.css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
    textarea_main_div.css({'display': 'none'});
    if (textarea_full_screen_field_index != 0){
      var value = textarea_main.val()
      var input = $(`#field_input_${textarea_full_screen_field_index}`);
      input.val(value);
    }
    window['textarea_full_screen_mode_open'] = false;
    window['textarea_full_screen_field_index'] = 0;
    textarea_main.val('');
  }
}

// открыть окно закладок
open_window_bookmark_value = false;
async function open_window_bookmark(){
  var container = $('.window_bookmark');
  if (!open_window_bookmark_value){
    if (open_window_notification_value){
      var container2 = $('.window_notification_all');
      container2.css({'height': 0, 'width': 0, 'border': '0px #0B243B solid'});
      window['open_window_notification_value'] = false;
    }
    container.css({'height': 500, 'width': 300, 'border': '2px rgb(66, 66, 70) solid'});
    window['open_window_bookmark_value'] = true;
  }
  else{
    container.css({'height': 0, 'width': 0, 'border': '0px rgb(66, 66, 70) solid'});
    window['open_window_bookmark_value'] = false;
  }
}

// добавить в закладки
async function add_bookmark(){
  var new_index_bookmark = data.bookmarks.quantity + 1;
  // information from object_edit
  var which = $('.window_edit-save_button').attr('onclick').toString().split('(');
  var name = which[0];
  if (name == 'save_editable_object'){
    var index_object = Number(which[1].split(')')[0]);
    var inf = data.objects[index_object];
    var index_model = inf[3]; var name_model = inf[1]; var pk = inf[2];
    var edit_values = await get_values_of_editable_window(index_object, object_save=false, new_object_save=false, bookmark=[true, 'object', index_object]);
    var dictic = {'type': 'Object', 'index_object': index_object, 'data': edit_values, 'index_model': index_model, 'name_model': name_model, 'pk': pk};
  }
  else if (name == 'save_editable_new_object'){
    var index_edit_new_object = Number(which[1].split(',')[0]);
    var index_model = Number(which[1].split(',')[1].split(')')[0]);
    var name_model = data.models[index_model][1];
    var edit_values = await get_values_of_editable_window(index_edit_new_object, object_save=false, new_object_save=false, bookmark=[true, 'new_object', index_edit_new_object]);
    var dictic = {'type': 'New object', 'index_object': index_edit_new_object, 'data': edit_values, 'index_model': index_model, 'name_model': name_model, 'pk': ''};
  }
  data.bookmarks.data[new_index_bookmark] = dictic;
  data.bookmarks.quantity ++;
  // проверяем, нет ли совпадающих закладок
  for (bmark_index in data.bookmarks.data){
    if (bmark_index == new_index_bookmark){ continue; }
    var bmark = data.bookmarks.data[bmark_index];
    var del = false;
    if (bmark.data == dictic.data){ del = true; }
    if (bmark.type == 'Object' && bmark.pk == dictic.pk){ del = true; }
    if (del){
      // удаляем предыдущий
      delete data.bookmarks.data[bmark_index];
      // удаляем у пользователя
      var bmark_el = $('#bookmark_' + bmark_index);
      bmark_el.remove();
    }
  }
  // прописываем на экране пользователя
  var container = $('.window_bookmark-list');
  var line = `
  <div class='window_bookmark-bookmark' id='bookmark_${new_index_bookmark}' onclick='open_bookmark_to_edit_window(${new_index_bookmark});'>
    <button class='window_bookmark-bookmark_id'>${new_index_bookmark}</button>
    <div class='window_bookmark-bookmark_text_div'><button class='window_bookmark-bookmark_text'>${dictic.type + ' ' + dictic.name_model + ' ' + dictic.pk}</button></div>
  </div>`;
  container.append(line);
  container.scrollTop(container.prop('scrollHeight'));
}

// открываем закладку обратно в окно редактирования
async function open_bookmark_to_edit_window(index_bookmark){
  // сначал закрываем окно выбора даты (если оно открыто)
  if (data_events.date_choose.state == 'show'){ close_window_date_choose(act='hide'); }
  // продолжаем
  var inf_bookmark = data.bookmarks.data[index_bookmark];
  var index_model = inf_bookmark.index_model;
  var data_values = inf_bookmark.data;
  // информация
  var inf_model = data.models[index_model];
  var name_model = inf_model[1];
  var dict_fields = inf_model[5].dict;
  var list_fields = inf_model[5].list;
  // находим контейнер
  var container = $('.window_edit');
  container_field = $('.window_edit-list_fields');
  container_field.html('');
  // прописываем на экране у пользователя каждое поле
  for (i = 0; i < list_fields.length; i++){
    var field_name = list_fields[i];
    var field = dict_fields[field_name];
    field.index = (i + 1);
    // вносим значение
    field.value = data_values[field.index].value;
    // вписываем в контейнер
    field.name_line = `<div class='window_edit-name_field'>` + field.name + `</div>`;
    // готовые элементы
    field.hr_line = `<div class='window_edit-hr'></div>`;
    // тип строки
    field.type_line = `<div class='window_edit-type_line'>Тип данных: ` + field.type + `</div>`;
    // получаем текст поля (html)
    if (field.type == 'FileField'){
      if (inf_bookmark.type == 'Object'){ index_object = inf_bookmark.index_object; field.value = data.objects[index_object][4][field.index]; }
      else if (inf_bookmark.type == 'New object'){ field.value = ['Файл не выбран', '']; }
    }
    else if (field.type == 'BooleanField'){
      if (field.value == true){ field.value = 'checked'; }
      else if (field.value == false){ field.value = 'not_checked'; }
    }
    var field = new_line_from_input_field(field);
    // добавляем его в контейнер
    container_field.append("<div id='field_" + field.index + "'>" + field.name_line + field.line + field.type_line + field.hr_line + "</div>");
  }
  // меняем (буковочки)
  if (inf_bookmark.type == 'Object'){
    var pk = inf_bookmark.pk;
    var index_object = inf_bookmark.index_object;
    // меняем централ текст
    var central_text = 'Редактировать объект ' + pk + ' - ' + name_model;
    container.find('.window_edit-central_text').html(central_text);
    // меняем верхний цвет
    container.find('.window_edit-header').css({'background': random_array_el(['#544f63', '#3f4d63', '#424246', '#171407'])});
    // меняем параметры функции у кнопки сохранить
    container.find('.window_edit-save_button').attr('onclick', 'save_editable_object(' + index_object + ');');
  }
  else if (inf_bookmark.type == 'New object'){
    var index_edit_new_object = inf_bookmark.index_object;
    // централ текст
    central_text = 'Добавить объект - ' + name_model;
    container.find('.window_edit-central_text').html(central_text);
    // меняем верхний цвет
    container.find('.window_edit-header').css({'background': random_array_el(['#544f63', '#3f4d63', '#424246', '#171407'])});
    // меняем параметры функции у кнопки сохранить
    container.find('.window_edit-save_button').attr('onclick', 'save_editable_new_object(' + index_edit_new_object + ', ' + index_model + ');');
    // значение прокрутки устанавливаем на 0
    container.find('.window_edit-scroll').scrollTop(0);
  }
  // показываем окно
  show_window_edit(bl = true);
  // значение прокрутки устанавливаем на 0
  $('.window_edit-scroll').scrollTop(0);
}


// фильтры объектов
async function filter_objects(index_model, value, check=true){
  if (check && data.models[index_model][6] == value){ return; }
  // находим элемент
  var model_objects_list_main = $('#model_objects_' + index_model);
  var model_objects_list = model_objects_list_main.find('.model-objects-list-2');
  var container = model_objects_list.find('.object_header-filter');
  // информация
  var objects_indexes = data.models[index_model][4];
  var objects_html = [];
  // проходимся по списку, забираем html элемента
  for (index_object in objects_indexes){
    var object_el = model_objects_list.find('#object_' + index_object);
    var html = `<div class="object" id="object_${index_object}">` + object_el.html() + '</div>';
    var title = object_el.find('.object-name').html().toString();
    var pk = objects_indexes[index_object];
    objects_html.push( {'index': index_object, 'html': html, 'title': title, 'title_up': capitalize(title).trim(), 'pk': Number(pk)} );
  }
  // выделения снимаем с объектов
  var mfilter1 = model_objects_list_main.find('#object_header_filter_1');
  var mfilter2 = model_objects_list_main.find('#object_header_filter_2');
  var mfilter3 = model_objects_list_main.find('#object_header_filter_3');
  mfilter1.css({'border-bottom': '2px white solid'}); mfilter2.css({'border-bottom': '2px white solid'}); mfilter3.css({'border-bottom': '2px white solid'});
  // какой расклад смотрим, сортируем данные
  if (value == 'pk_down'){
    objects_html.sort(byField('pk'));
    // выделяем объект
    mfilter1.css({'border-bottom': '2px #088A85 solid'});
  }
  else if (value == 'pk_up'){
    objects_html.sort(byField('pk'));
    objects_html.reverse();
    // выделяем объект
    mfilter2.css({'border-bottom': '2px #088A85 solid'});
  }
  else if (value == 'alphabet'){
    objects_html.sort(byField('title_up'));
    // выделяем объект
    mfilter3.css({'border-bottom': '2px #088A85 solid'});
  }
  // вставляем обратно на экран пользователя
  var text_all = '';
  objects_html.forEach(function(item, i, array) {
    var line = item.html; // объект
    text_all += line;
  });
  model_objects_list.html(text_all);
  // записываем значение сортировки
  data.models[index_model][6] = value;
  // делаем checked, на всех у кого она была
  var checked_objects = data.objects_checked[index_model].objects;
  for (index_object in checked_objects){
    var object_el = model_objects_list.find('#object_' + index_object);
    object_el.css({'background': '#f6f7cd'});
    var input_check = object_el.find('.object-checkbox');
    input_check.prop('checked', true);
  }
}


// открыть окно уведомлений
open_window_notification_value = false;
async function open_window_notifications(){
  var container = $('.window_notification_all');
  if (!open_window_notification_value){
    if (open_window_bookmark_value){
      container2 = $('.window_bookmark');
      container2.css({'height': 0, 'width': 0, 'border': '0px rgb(66, 66, 70) solid'});
      window['open_window_bookmark_value'] = false;
    }
    container.css({'height': 500, 'width': 300, 'border': '2px #0B243B solid'});
    window['open_window_notification_value'] = true;
  }
  else{
    container.css({'height': 0, 'width': 0, 'border': '0px #0B243B solid'});
    window['open_window_notification_value'] = false;
  }
}

// уведомления
notification_timeout = setTimeout(close_notification, 3500);
// functions notification
async function close_notification(){
  var container = $('.window_notification');
  container.css({'right': -350});
}
async function open_notification(value, text){
  if (!open_window_notification_value){ clearTimeout(notification_timeout); }
  var container = $('.window_notification');
  var container_text = container.find('.window_notification-text');
  if (value == 'good'){
    var color = '#ECF8E0';
    // если окно уведомлений не открыто, то показываем уведомление
    if (!open_window_notification_value){
      container_text.html(text + '<div style="height: 10px;"></div>');
      container.css({'background': '#ECF8E0', 'right': 15, 'height': 'auto', 'overflow-x': 'hidden', 'overflow-y': 'hidden'});
      container_text.css({'font-size': 16});
    }
  }
  else if (value == 'error'){
    var color = '#F8E0E0';
    // если окно уведомлений не открыто, то показываем уведомление
    if (!open_window_notification_value){
      container_text.html(text + '<div style="height: 10px;"></div>');
      container.css({'background': '#F8E0E0', 'right': 15, 'height': 170, 'overflow-x': 'scroll', 'overflow-y': 'scroll'});
      container_text.css({'font-size': 13});
    }
  }
  if (!open_window_notification_value){
    window['notification_timeout'] = setTimeout(close_notification, 3500);
  }
  // прописываем в списке всех уведомлений
  var nlist = $('.window_notification_all-list');
  var line = `<div class='window_notification_all-list-notification' style='background: ${color}'>${text}</div>`;
  nlist.append(line);
  // ставим прокрутку в конец
  nlist.scrollTop(nlist.prop('scrollHeight'));
}


// получить значение всех полей окна редактирования
async function get_values_of_editable_window(index_object, object_save=true, new_object_save=false, bookmark=[false, 'object', 1], app='', model=''){
  var object_inf_main = '';
  // получаем информацию
  if (object_save){ var object_fields = data.edit.object.data[index_object]; }
  else if (new_object_save){ var object_fields = data.edit.new_object.data[index_object]; }
  else if (bookmark[0]){
    if (bookmark[1] == 'object'){ var object_fields = data.edit.object.data[bookmark[2]]; }
    else if (bookmark[1] == 'new_object'){ var object_fields = data.edit.new_object.data[bookmark[2]]; }
  }
  // проходимся по полям
  var index_field = 0;
  for (field_index in object_fields){
    index_field ++;
    var inf = object_fields[index_field];
    var ftype = inf['type'];
    // получаем элемент
    var input = $('#field_input_' + index_field);
    // получаем значение
    if (ftype == 'BooleanField'){ value = input.is(':checked'); }
    else if (ftype == 'FileField'){
      // если мы сохраняем имеющийся объект
      if (object_save){
        try{
          var file = input[0].files[0];
          if (file == undefined){ lalala; }
          var url = '/admin/upload_file_from_save';
          // если нет информации о модели и приложении, то получаем
          if (object_inf_main == ''){
            var object_inf_main = data.objects[index_object];
          }
          // формируем дату
          var data_file = new FormData();
          data_file.append("app", object_inf_main[0]);
          data_file.append("model", object_inf_main[1]);
          data_file.append("pk", object_inf_main[2]);
          data_file.append("index", index_field);
          data_file.append("file", file);
          // отправляем файл на сервер
          var json = await request_for_json_post(url, data_file, basik = true);
          if (json.status != 'Ok'){
            open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
          }
          else{
            open_notification('good', text = `Файл успешно загружен в объект ${object_inf_main[2]}!`);
          }
        }
        catch{}
        var value = null;
      }
      // если мы сохраняем новый объект
      else if (new_object_save){
        try{
          var file = input[0].files[0];
          if (file == undefined){ lalala; }
          // формируем дату запроса
          var data_file = new FormData();
          data_file.append("app", app);
          data_file.append("model", model);
          data_file.append("index", index_field);
          data_file.append("file", file);
          // записываем в значение
          var value = data_file;
        }
        catch{ var value = null; }
      }
      else if (bookmark[0]){
        try{
          var file = input[0].files[0];
          if (file == undefined){ lalala; }
          var value = file;
        }
        catch{ var value = null; }
      }
    }
    else{ var value = input.val(); }
    // сохраняем новое значение
    object_fields[index_field].value = value;
  }
  return object_fields;
}

// сохранить изменения в базе данных
async function save_editable_object(index_object){
  // получаем информацию
  var data_inf = data.objects[index_object];
  var pk = data_inf[2];
  var index_model = data_inf[3];
  // получаем значение полей
  var edit_values = await get_values_of_editable_window(index_object, object_save = true, new_object_save=false);
  // отправляем json для сохранения объекта
  var request_post_data = {'app': data_inf[0], 'model': data_inf[1], 'pk': pk, 'data': edit_values}
  var url = '/admin/save_object';
  var json = await request_for_json_post(url, request_post_data);
  // проверяем на ошибку на сервере
  if (json.status != 'Ok'){
    open_notification('error', text = '<b style="font-size: 15px;">' + json.status + '</b><div style="height: 0px;"></div><br>' + json.error);
    return;
  }
  else{
    // меняем название на новое
    var title = json.data.title;
    var object = $('#object_' + index_object);
    object.find('.object-name').html(title);
    // обновляем внутренний список в нашей модели
    data.models[index_model][2][pk] = title;
  }
  // показываем приятное уведомление о сохранении
  open_notification('good', text = 'Object ' + data_inf[2] + ' успешно сохранён!');
}

// сохранить новый объект в базе данных
async function save_editable_new_object(index_new_object, index_model){
  // получаем информацию
  var data_inf = data.models[index_model];
  // получаем значение полей
  var edit_values = await get_values_of_editable_window(index_new_object, object_save=false, new_object_save = true, app = data_inf[0], model = data_inf[1]);
  // проходимся по полям и убираем файлы
  var request_data_files = {};
  for (index_field in edit_values){
    var field = edit_values[index_field];
    if (field.type == 'FileField' && field.value != null){
      request_data_files[index_field] = field.value;
      edit_values[index_field].value = null;
    }
  }
  // MAIN REQUEST -----------------------
  // отправляем json для сохранения объекта
  var request_post_data = {'app': data_inf[0], 'model': data_inf[1], 'data': edit_values}
  var url = '/admin/save_new_object';
  var json = await request_for_json_post(url, request_post_data);
  // проверяем на ошибку на сервере
  if (json.status != 'Ok'){
    open_notification('error', text = '<b style="font-size: 15px;">' + json.status + '</b><div style="height: 0px;"></div><br>' + json.error);
    return;
  }
  else{
    var pk = json.data.pk;
    var title = json.data.title;
    var new_index_object = index_object_global + 1;
    // обновляем внутренние списоки
    data.models[index_model][2][pk] = title;
    data.objects[new_index_object] = [data_inf[0], data_inf[1], pk, index_model, ''];
    data.models[index_model][4][new_index_object] = pk;
    data.models[index_model][3] ++; // количество увеличиваем на 1
    index_object_global ++;
    // меняем количество на экране
    cheked_object(new_index_object, main_check = true, change_quantity = false);
    // распростанение объектов, добавляем новый в объект на экран
    var text = create_component('object', new_index_object, object_name = title, object_pk = pk);
    var container = $('#model_objects_' + index_model);
    if (data_inf[6] == 'pk_down'){ container.find('.model-objects-list-2').append(text); }
    else if (data_inf[6] == 'pk_up'){ container.find('.model-objects-list-2').prepend(text); }
    else if (data_inf[6] == 'alphabet'){
      container.find('.model-objects-list-2').append(text);
      filter_objects(index_model, 'alphabet', check=false);
    }
    else{ container.find('.model-objects-list-2').append(text); }
  }
  // FILES REQUESTS --------------------
  for (request_file_index in request_data_files){
    var url = '/admin/upload_file_from_save';
    var data_file = request_data_files[request_file_index];
    data_file.append('pk', pk);
    // отправляем файл на сервер
    var json = await request_for_json_post(url, data_file, basik = true);
    if (json.status != 'Ok'){
      open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
    }
    else{
      open_notification('good', text = `Файл успешно загружен в новый объект ${pk}!`);
    }
  }
  // показываем приятное уведомление о сохранении
  open_notification('good', text = 'Object ' + pk + ' успешно создан!');
}


// устанавливаем реальное сейчасшнее время
async function install_time_to_input_now(field_index){
  var now = new Date();
  var time = now.toISOString().split('T');
  var time1 = time[0];
  var time2 = time[1].split('.')[0];
  var input = $('#field_input_' + field_index).val(time1 + ' ' + time2);
}

// открыть, закрыть окошко с выбором времени
async function close_window_date_choose(act='hide'){
  if (act == 'show' && data_events.date_choose.state == 'hide'){
    data_events.date_choose.dark.css({'opacity': 0.4, 'width': '100%', 'transition': 'opacity 0.2s'});
    data_events.date_choose.container.css({'height': 508, 'top': Math.round(window.innerHeight / 2 - 254), 'opacity': 1.0});
    data_events.date_choose.state = 'show';
  }
  else if (act == 'hide' && data_events.date_choose.state == 'show'){
    data_events.date_choose.dark.css({'opacity': 0.0, 'width': 0, 'transition': 'opacity 0.2s'});
    data_events.date_choose.container.css({'height': 0, 'top': Math.round(window.innerHeight / 2 - 304), 'opacity': 0.0});
    data_events.date_choose.state = 'hide';
  }
}

// выделить какой-то день
async function highlight_day_from_window_choose(day){
  // убираем предыдущий
  var day_button_previous = data_events.date_choose.container.find(`#date_choose_day_${data_events.date_choose.day}`);
  day_button_previous.css({'background': '', 'color': ''});
  // ставим новый
  var day = day.toString();
  var day_button = data_events.date_choose.container.find(`#date_choose_day_${day}`);
  day_button.css({'background': '#0080FF', 'color': 'white'});
  // изменяем данные
  data_events.date_choose.day = day;
}

// изменить количество дней
async function change_quantity_days(month){
  var month = month.toLowerCase().trim();
  var year = data_events.date_choose.container.find('#date_choose_year').val();
  if (month == 'февраль' && Number(year) % 4 == 0){ var quantity_days = 29; }
  else{ var quantity_days = data_month.days[data_month.month[month]]; }
  // remove or append
  var day_numbers_container = data_events.date_choose.container.find('.date_choose-cont3-number_days');
  if (data_events.date_choose.quantity_days < quantity_days){
    for (let i = data_events.date_choose.quantity_days + 1; i <= quantity_days; i++){
      var line = `<button id='date_choose_day_${i}' class='date_choose-cont3-number_day'>${i}</button>`;
      day_numbers_container.append(line);
    }
    // если нажали на кнопку дня (обновление)
    $('.date_choose-cont3-number_day').on('click', function(){
      var day = $(this).html();
      data_events.date_choose.container.find('#date_choose_day').val(day);
      highlight_day_from_window_choose(day);
    });
  }
  else if (data_events.date_choose.quantity_days > quantity_days){
    for (let i = quantity_days + 1; i <= data_events.date_choose.quantity_days; i++){
      day_numbers_container.find(`#date_choose_day_${i}`).remove();
    }
  }
  data_events.date_choose.quantity_days = quantity_days;
}

// вставить месяц в поле
async function put_month_name_to_input_month(month){
  var month = month.toLowerCase();
  data_events.date_choose.container.find(`#date_choose_month`).val(month);
  data_events.date_choose.container_months.hide();
  data_events.date_choose.month = month;
  // quantity days
  change_quantity_days(month);
}

// попробовать вставить значение из поля в окно
async function try_paste_time_in_window(value){
  var func = function(field_name, value){
    if (isNaN(value)){ return; }
    var value = parseInt(value).toString();
    if (field_name == 'day'){
      highlight_day_from_window_choose(value);
    }
    else if (field_name == 'month'){
      var value = Number(value);
      if (value < 1 || value > 12){ var value = value % 12; if (value == 0){ var value = 12;} }
      var value = data_month.number[value];
      change_quantity_days(value);
    }
    if (['hour', 'minute', 'second'].includes(field_name)){ var value = readable_time(value); }
    data_events.date_choose.container.find(`#date_choose_${field_name}`).val(value);
    data_events.date_choose[field_name] = value;
  };
  try{
    var v = value.split(' ');
    var v1 = v[0].split('-');
    // 1 - год, месяц, день
    var year = parseInt(v1[0]); func('year', year);
    var month = parseInt(v1[1]); func('month', month);
    var day = parseInt(v1[2]); func('day', day);
    // 2 - час, минута, секунда
    var v2 = v[1].split(':');
    var hour = parseInt(v2[0]); func('hour', hour);
    var minute = parseInt(v2[1]); func('minute', minute);
    var second = parseInt(v2[2]); func('second', second);
    // 3 - часовой пояс
    if (value.split('+').length >= 2){ var timezone = '+' + value.split('+')[1]; }
    else if (value.split('-').length >= 4){ var timezone = '-' + value.split('-')[3]; }
    else{ var timezone = '+00:00' }
    data_events.date_choose.container.find(`#date_choose_utc`).val(timezone);
    data_events.date_choose.utc = timezone;
  }
  catch{ return; }
}

// установить выбранную дату
async function apply_date_in_field(field_index){
  // проверка
  var year = data_events.date_choose.container.find('#date_choose_year').val();
  var day = data_events.date_choose.day;
  var hour = data_events.date_choose.container.find('#date_choose_hour').val();
  var minute = data_events.date_choose.container.find('#date_choose_minute').val();
  var second = data_events.date_choose.container.find('#date_choose_second').val();
  // формирование
  var time1 = [readable_time(year), readable_time(data_month.month[data_events.date_choose.month]), readable_time(day)].join('-');
  var time2 = [readable_time(data_events.date_choose.hour), readable_time(data_events.date_choose.minute), readable_time(data_events.date_choose.second)].join(':');
  var time3 = data_events.date_choose.container.find('#date_choose_utc').val();
  var input = $('#field_input_' + field_index).val(time1 + ' ' + time2 + time3);
  // дальнейший шаг
  if (data_events.date_choose.step != 2){
    install_time_to_input(field_index, step = data_events.date_choose.step + 1);
  }else{
    close_window_date_choose(act='hide');
  }
}

// событие при прокрутке поля ввода
function Wheel_Event(e){
  var e = e || window.event;
  var delta = e.deltaY || e.detail || e.wheelDelta;
  var el = $(this);
  if (delta > 0){ var act = '+'; }else{ var act = '-'; }
  var max_number = data_events.date_choose.max_number[el.attr('id')];
  var now_number = el.val();
  if (!isNaN(now_number)){
    var now_number = Number(now_number);
    if (act == '+'){
      if (now_number >= max_number){ var new_number = 0; }
      else{ var new_number = now_number + 1; }
    }
    else{
      if (now_number > 0){ var new_number = now_number - 1; }
      else{ var new_number = max_number; }
    }
    el.val(readable_time(new_number));
  }
}

// окошко с выбором времени
async function install_time_to_input(field_index = 1, step = 1, try_paste = true){
  var input = $(`#field_input_${field_index}`);
  // проходимся по шагам
  if (step == 1){
    data_events.date_choose.step = 1;
    data_events.date_choose.step1.show();
    data_events.date_choose.step2.hide();
    // заголовок
    data_events.date_choose.container.find('.date_choose-cont1-title').html('Выбрать дату');
    // если внутренние элементы не созданы, то создаём
    if (!data_events.date_choose.create){
      data_events.date_choose.create = true;
      // названия дней
      var day_names_container = data_events.date_choose.container.find('.date_choose-cont2-day_names');
      var day_names_array = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
      day_names_array.forEach(function(item, index, array){
        var line = `<div class='date_choose-cont2-day_name'>${item}</div>`;
        day_names_container.append(line);
      });
      // номера дней
      var day_numbers_container = data_events.date_choose.container.find('.date_choose-cont3-number_days');
      for (let i = 1; i <= 31; i++){
        var line = `<button id='date_choose_day_${i}' class='date_choose-cont3-number_day'>${i}</button>`;
        day_numbers_container.append(line);
      };
      // если нажали на кнопку дня
      $('.date_choose-cont3-number_day').on('click', function(){
        var day = $(this).html();
        data_events.date_choose.container.find('#date_choose_day').val(day);
        highlight_day_from_window_choose(day);
      });
      // вставляем месяцы в контейнер прокрутки
      for (month in data_month.month){
        var line = `<button class='date_choose-cont_months-name_month' onclick='put_month_name_to_input_month("${month}");'>${month}</button>`;
        data_events.date_choose.container_months.append(line);
      }
      // ставим обработчики на поля ввода
      data_events.date_choose.container.find('#date_choose_year').on('keyup input', function(){
        var year = this.value;
        if (!isNaN(year)){
          try{ change_quantity_days(data_events.date_choose.container.find('#date_choose_month').val()); }
          catch{}
        }
      });
      data_events.date_choose.container.find('#date_choose_day').on('keyup input', function(){
        var day = this.value;
        if (!isNaN(day)){
          try{ highlight_day_from_window_choose(day); }
          catch{}
        }
      });
      data_events.date_choose.date_choose_month.on('focus', function(){
        data_events.date_choose.container_months.show();
      });
      // стрелка
      data_events.date_choose.arrow.on('mouseenter', function(){
        $(this).find('.date_choose-cont1-arrow_img').attr('src', '/static/img/admin/arrow_purple.png');
      }).on('mouseleave', function(){
        $(this).find('.date_choose-cont1-arrow_img').attr('src', '/static/img/admin/arrow_black.png');
      }).on('click', function(){
        if (data_events.date_choose.step == 1){ install_time_to_input(field_index = field_index, step = 2, try_paste = false); }
        else if (data_events.date_choose.step == 2){ install_time_to_input(field_index = field_index, step = 1, try_paste = false); }
      });
      // линия по карте
      data_events.date_choose.container.find('.date_choose-cont5-map-event').on('mousemove', function(e){
        var el = $(this);
        var difference = e.pageX - el.offset().left - 295;
        var timezone = Math.ceil(((difference + 295.5) / 295) * 24) - 12;
        if (timezone == -12){ var timezone = -11; }
        if (timezone >= 0){ var timezone_str = `+${readable_time(timezone)}`; }else{ var timezone_str = `-${readable_time(Math.abs(timezone))}`; }
        data_events.date_choose.map_line.css({'display': 'inline', 'margin-left': difference});
        data_events.date_choose.map_timezone.css({'display': 'inline', 'margin-left': difference + 295 - 15});
        data_events.date_choose.map_timezone.html(timezone_str);
      }).on('mouseleave', function(e){
        data_events.date_choose.map_line.css({'display': 'none'});
        data_events.date_choose.map_timezone.css({'display': 'none'});
      }).on('click', function(e){
        var el = $(this);
        var difference = e.pageX - el.offset().left - 295;
        var timezone = Math.ceil(((difference + 295.5) / 295) * 24) - 12;
        if (timezone == -12){ var timezone = -11; }
        if (timezone >= 0){ var timezone_str = `+${readable_time(timezone)}`; }else{ var timezone_str = `-${readable_time(Math.abs(timezone))}`; }
        // устанавливаем
        data_events.date_choose.container.find('#date_choose_utc').val(`${timezone_str}:00`);
      });
      // делаем прокрутку на поля второго окна
      var elements = document.getElementsByClassName('date_input_wheel');
      for (var i = 0; i < elements.length; i++) {
        elements[i].addEventListener('wheel', Wheel_Event, false);
      }
      // при нажатии на стрелочки
      data_events.date_choose.container.find('.date_choose-cont5-inputs-cont-arrow').on('click', function(e){
        el = $(this);
        if (el.html() == '▼'){ var act = '+'; }else{ var act = '-'; }
        var el = el.parent(".date_choose-cont5-inputs-cont").find('input');
        var max_number = data_events.date_choose.max_number[el.attr('id')];
        var now_number = el.val();
        if (!isNaN(now_number)){
          var now_number = Number(now_number);
          if (act == '+'){
            if (now_number >= max_number){ var new_number = 0; }
            else{ var new_number = now_number + 1; }
          }
          else{
            if (now_number > 0){ var new_number = now_number - 1; }
            else{ var new_number = max_number; }
          }
          el.val(readable_time(new_number));
        }
      });
    }
    // если нажали на текущее время
    data_events.date_choose.container.find('.date_choose-cont4-now_time').attr('onclick', `install_time_to_input_now(${field_index});`);
    data_events.date_choose.container.find('.date_choose-cont4-apply').attr('onclick', `apply_date_in_field(${field_index});`);
    if (try_paste){
      // вставляем значения
      var value = input.val();
      try_paste_time_in_window(value);
    }
    // меняем стрелку
    data_events.date_choose.arrow.css({'transform': 'rotate(0deg)'});
    // открываем окно
    close_window_date_choose(act='show');
  }
  else if (step == 2){
    data_events.date_choose.step = 2;
    data_events.date_choose.step1.hide();
    data_events.date_choose.step2.show();
    // заголовок
    data_events.date_choose.container.find('.date_choose-cont1-title').html('Выбрать время');
    // меняем стрелку
    data_events.date_choose.arrow.css({'transform': 'rotate(180deg)'});
  }
}


async function click_to_input_file(field_index){
  var field = $('#field_' + field_index);
  var input = field.find('#field_input_' + field_index);
  input.click();
  input.on('change', function(){
    var file = this.files[0];
    // если файл открыли, то вписываем в help_text
    var help_text = field.find('.window_edit-file_help_text');
    help_text.html(`<b style='color: black;'>Загружено:</b><br>${file.name}<br>Размер: ${file.size} байт<br>Тип: ${file.type}`);
  });
}

// показать окно редактирования
function show_window_edit(bl = true){
  if (bl){
    $('.window_edit').css({'display': 'inline'});
    $('.dark').css({'opacity': 0.55, 'width': '100%', 'transition': 'opacity 0.2s'});
  }
  else{
    $('.window_edit').css({'display': 'none'});
    $('.dark').css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
  }
}


// создать текст нового input у поля
function new_line_from_input_field(field){
  // перебираем типы
  if (field.type == 'CharField' || field.type == 'EmailField'){
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <input type='text' value='` + field.value + `' class='window_edit-input' placeholder='` + field.help_text + `' id='field_input_` + field.index + `' autocomplete="off">
    `;
    field.full_screen = '';
  }
  else if (field.type == 'TextField'){
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <textarea type='text' class='window_edit-textarea' placeholder='` + field.help_text + `' id='field_input_` + field.index + `' autocomplete="off">` + field.value + `</textarea>
    `;
    field.full_screen = `
    <div class='window_edit-textarea-full_screen' onclick='open_textarea_full_screen(field_index=${field.index}, bl=true);'>
      <img src='/static/img/admin/full_screen.png' class='window_edit-textarea-full_screen-img'>
      <div class='window_edit-textarea-full_screen-text'>Открыть на полный экран</div>
    </div>
    `;
    field.read_from_file = `
    <input type='file' value='' id='field_read_from_file_input_` + field.index + `' style='display: none;' autocomplete="off" />
    <div class='window_edit-textarea-read_from_file' onclick='enter_value_from_file(${field.index}, type_inner_file="text/plain");'>
      <img src='/static/img/admin/read_from_file.png' class='window_edit-textarea-read_from_file-img'>
      <div class='window_edit-textarea-read_from_file-text'>Прочитать из файла</div>
    </div>
    `;
  }
  else if (field.type == 'JSONField'){
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <textarea type='text' class='window_edit-textarea' placeholder='` + field.help_text + `' id='field_input_` + field.index + `' autocomplete="off" style='height: 300px;overflow-x: scroll;overflow-y: scroll;'>` + field.value + `</textarea>
    `;
    field.full_screen = `
    <div class='window_edit-textarea-full_screen' onclick='open_textarea_full_screen(field_index=${field.index}, bl=true);'>
      <img src='/static/img/admin/full_screen.png' class='window_edit-textarea-full_screen-img'>
      <div class='window_edit-textarea-full_screen-text'>Открыть на полный экран</div>
    </div>
    `;
    field.read_from_file = `
    <input type='file' value='' id='field_read_from_file_input_` + field.index + `' style='display: none;' autocomplete="off" />
    <div class='window_edit-textarea-read_from_file' onclick='enter_value_from_file(${field.index}, type_inner_file="application/json");'>
      <img src='/static/img/admin/read_from_file.png' class='window_edit-textarea-read_from_file-img'>
      <div class='window_edit-textarea-read_from_file-text'>Прочитать из файла</div>
    </div>
    `;
  }
  else if (field.type == 'BooleanField'){
    field.line =
    `
    <input type='checkbox' ` + field.value + ` class='window_edit-checkbox' id='field_input_` + field.index + `' autocomplete="off">
    <div class='window_edit-checkbox_help_text'>` + field.help_text + `</div>
    `;
    field.full_screen = '';
  }
  else if (field.type == 'DateTimeField'){
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <input type='text' value='` + field.value + `' class='window_edit-input' placeholder='` + field.help_text + `' style='width: 300px;' id='field_input_` + field.index + `' autocomplete="off">
    <div class='window_edit-input-datefield-format'>Формат: 2020-09-12 18:23:02</div>
    <div class='window_edit-input-datefield-time_now' onclick='install_time_to_input(` + field.index + `);'>Выбрать время</div>
    `;
    field.type_line = `<div class='window_edit-type_line' style='margin-top: 10px;'>Тип данных: ` + field.type + `</div>`;
    field.full_screen = '';
  }
  else if (field.type == 'FileField'){
    if (field.value[0] == 'Файл не выбран'){
      var help_text_line = field.help_text + '<br><b style="color: #424242;">На данный момент:</b> <b style="color: #1e0521;">файл не загружен</b>';
    }
    else{
      var help_text_line = field.help_text + '<br><b style="color: #424242;">На данный момент:</b> <a class="window_edit-file_help_text-download_href" href="' + field.value[1] + '">' + field.value[0] + '</a>';
    }
    field.line =
    `
    <input type='file' value='` + field.value + `' id='field_input_` + field.index + `' style='display: none;' autocomplete="off">
    <button class='window_edit-file' onclick='click_to_input_file(` + field.index + `);'>Загрузить</button>
    <div class='window_edit-file_help_text'>` + help_text_line + `</div>
    `;
    field.type_line = `<div class='window_edit-type_line' style='margin-top: 25px;'>Тип данных: ` + field.type + `</div>`;
    field.full_screen = '';
  }
  else if (field.type == 'ManyToManyField'){
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <textarea type='text' class='window_edit-textarea' placeholder='` + field.help_text + `' id='field_input_` + field.index + `' autocomplete="off">` + field.value + `</textarea>
    `;
    field.full_screen = '';
  }
  else{
    field.line =
    `
    <div class='window_edit-input_help_text'>` + field.help_text + `</div>
    <input type='text' value='` + field.value + `' class='window_edit-input' placeholder='` + field.help_text + `' id='field_input_` + field.index + `' autocomplete="off">
    `;
    field.full_screen = '';
  }
  return field
}

// добавить информацию по полям
async function add_edit_information_new_object(index_model){
  // информация
  var inf_model = data.models[index_model];
  var name_model = inf_model[1];
  var dict_fields = inf_model[5].dict;
  var list_fields = inf_model[5].list;
  // находим контейнер
  var container = $('.window_edit');
  container_field = $('.window_edit-list_fields');
  container_field.html('');
  // создаём словарь данных
  var data_new_object = {};
  // прописываем на экране у пользователя каждое поле
  for (i = 0; i < list_fields.length; i++){
    var field_name = list_fields[i];
    var field = dict_fields[field_name];
    field.index = (i + 1);
    if (field.type == 'FileField'){ field.value = ['Файл не выбран', '']; }
    else{ field.value = ''; }
    // вписываем в контейнер
    field.name_line = `<div class='window_edit-name_field'>` + field.name + `</div>`;
    // готовые элементы
    field.hr_line = `<div class='window_edit-hr'></div>`;
    // тип строки
    field.type_line = `<div class='window_edit-type_line'>Тип данных: ` + field.type + `</div>`;
    // others
    field.read_from_file = '';
    // получаем текст поля (html)
    var field = new_line_from_input_field(field);
    // добавляем его в контейнер
    container_field.append("<div id='field_" + field.index + "'>" + field.name_line + field.line + field.type_line + field.full_screen + field.read_from_file + field.hr_line + "</div>");
    // записываем в словарь
    data_new_object[i + 1] = {'name': field.name, 'value': field.value, 'type': field.type};
  }
  // получаем индекс нашего нового объекта
  var quantity_new_obj = data.edit.new_object.quantity;
  // меняем централ текст
  var central_text = 'Добавить объект - ' + name_model;
  container.find('.window_edit-central_text').html(central_text);
  // меняем верхний цвет
  container.find('.window_edit-header').css({'background': random_array_el(['#544f63', '#3f4d63', '#424246', '#171407'])});
  // меняем параметры функции у кнопки сохранить
  container.find('.window_edit-save_button').attr('onclick', 'save_editable_new_object(' + quantity_new_obj + ', ' + index_model + ');');
  // значение прокрутки устанавливаем на 0
  container.find('.window_edit-scroll').scrollTop(0);
  // -------------------- заполянем данные
  data.edit.new_object.data[quantity_new_obj] = data_new_object;
  data.edit.new_object.quantity ++;
}

// добавить новый объект в модель
async function add_new_object(index_model){
  // получаем объекты по json и вставляем (если не получили в прошлом)
  var data_list = data.models[index_model];
  if (data_list[5] == ''){
    request_post_data = {'app': data_list[0], 'model': data_list[1]}
    var url = '/admin/get_fields_in_model';
    var json = await request_for_json_post(url, request_post_data);
    // проверяем на ошибку на сервере
    if (json.status != 'Ok'){
      open_notification('error', text = '<b style="font-size: 15px;">' + json.status + '</b><div style="height: 0px;"></div><br>' + json.error);
      return;
    }
    data.models[index_model][5] = json.result;
  }
  // добавляем информацию в окно
  add_edit_information_new_object(index_model);
  // показываем окно
  show_window_edit(bl = true);
  // значение прокрутки устанавливаем на 0
  $('.window_edit-scroll').scrollTop(0);
}


// добавить информацию по полям
async function add_edit_information_object(index_model, index_object, pk){
  // информация
  var inf_model = data.models[index_model];
  var name_model = inf_model[1];
  var dict_fields = inf_model[5].dict;
  var list_fields = inf_model[5].list;
  // находим контейнер
  var container = $('.window_edit');
  container_field = $('.window_edit-list_fields');
  container_field.html('');
  // создаём словарь данных
  var data_edit_object = {};
  // прописываем на экране у пользователя каждое поле
  for (i = 0; i < list_fields.length; i++){
    var field_name = list_fields[i];
    var field = dict_fields[field_name];
    field.index = (i + 1);
    // вносим значение
    field.value = data.objects[index_object][4][field.index];
    // вписываем в контейнер
    field.name_line = `<div class='window_edit-name_field'>` + field.name + `</div>`;
    // готовые элементы
    field.hr_line = `<div class='window_edit-hr'></div>`;
    // тип строки
    field.type_line = `<div class='window_edit-type_line'>Тип данных: ` + field.type + `</div>`;
    // others
    field.read_from_file = '';
    // получаем текст поля (html)
    var field = new_line_from_input_field(field);
    // добавляем его в контейнер
    container_field.append("<div id='field_" + field.index + "'>" + field.name_line + field.line + field.type_line + field.full_screen + field.read_from_file + field.hr_line + "</div>");
    // записываем в словарь
    data_edit_object[i + 1] = {'name': field.name, 'value': field.value, 'type': field.type};
  }
  // меняем централ текст
  var central_text = 'Редактировать объект ' + pk + ' - ' + name_model;
  container.find('.window_edit-central_text').html(central_text);
  // меняем верхний цвет
  container.find('.window_edit-header').css({'background': random_array_el(['#544f63', '#3f4d63', '#424246', '#171407'])});
  // меняем параметры функции у кнопки сохранить
  container.find('.window_edit-save_button').attr('onclick', 'save_editable_object(' + index_object + ');');
  // -------------------- заполянем данные
  data.edit.object.data[index_object] = data_edit_object;
  data.edit.object.quantity ++;
}

// отредактировать объект в модель
async function edit_object(index_object){
  // получаем информацию
  var inf = data.objects[index_object];
  var inf_model = data.models[inf[3]];
  // ------------------------ REQUEST 1
  // получаем объекты по json и вставляем (если не получили в прошлом)
  if (inf_model[5] == ''){
    var request_post_data = {'app': inf[0], 'model': inf[1]}
    var url = '/admin/get_fields_in_model';
    var json = await request_for_json_post(url, request_post_data);
    // проверяем на ошибку на сервере
    if (json.status != 'Ok'){
      open_notification('error', text = '<b style="font-size: 15px;">' + json.status + '</b><div style="height: 0px;"></div><br>' + json.error);
      return;
    }
    data.models[inf[3]][5] = json.result;
  }
  // ------------------------ REQUEST 2
  // получаем объекты по json и вставляем (если не получили в прошлом)
  var request_post_data = {'app': inf[0], 'model': inf[1], 'pk': inf[2]}
  var url = '/admin/get_fields_in_object';
  var json = await request_for_json_post(url, request_post_data);
  // проверяем на ошибку на сервере
  if (json.status != 'Ok'){
    open_notification('error', text = '<b style="font-size: 15px;">' + json.status + '</b><div style="height: 0px;"></div><br>' + json.error);
    return;
  }
  data.objects[index_object][4] = json.result;
  // добавляем информацию в окно
  add_edit_information_object(inf[3], index_object, inf[2]);
  // показываем окно
  show_window_edit(bl = true);
  // значение прокрутки устанавливаем на 0
  $('.window_edit-scroll').scrollTop(0);
}


async function delete_objects_in_model(index_model){
  var container = $('#model_objects_' + index_model);
  var data_list = data.models[index_model];
  var objects_checked_list = data.objects_checked[index_model].objects;
  var result_pk_list = {};
  // проверяем на доступ пользователя к модели
  var request_post_data = {'app': data_list[0], 'model': data_list[1]}
  var url = '/admin/check_permission_to_model';
  var json = await request_for_json_post(url, request_post_data);
  if (json.status != 'Yes'){
    open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
    return;
  }
  // раз всё прошло успешно, то на экране убираем объекты
  for (index_object in objects_checked_list){
    // добавляем в общий список
    var pk = objects_checked_list[index_object];
    result_pk_list[pk] = 1;
    // удаляем объект с глаз пользователя
    var object_element = $('#object_' + index_object);
    object_element.remove();
    // удаляем объект из списка объектов модели
    delete data.objects[index_object];
    delete data.models[index_model][4][index_object];
    data.models[index_model][3] --;
    data.objects_checked[index_model].quantity --;
    if (index_object in data.objects_checked[index_model].objects){
      delete data.objects_checked[index_model].objects[index_object];
    }
    // уменьшаем количество объектов на экране
    var quantity_objects_in_model = data.models[index_model][3];
    container.find('.object_header-quantity').html(quantity_objects_in_model + ' объектов');
    container.find('.object_header-delete').css({'display': 'none'});
    // -------
  }
  // если объектов не осталось, то выводим надпись об этом
  if (data.models[index_model][3] == 0){
    var line = "<center> <button class='no_models'> Не обнаружено объектов </button> </center>";
    container.html(line);
  }
  // ---------------- отправляем запрос на удаление
  var request_post_data = {'app': data_list[0], 'model': data_list[1], 'objects': result_pk_list};
  var url = '/admin/delete_objects_in_model';
  var json = await request_for_json_post(url, request_post_data);
  if (json.status != 'Ok'){
    open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
    return;
  }
  open_notification('good', text = `Выбранные объекты в модели ${data_list[1]} успешно удалены!`);
}


async function cheked_object(index, main_check = true, change_quantity = true){
  var object = $('#object_' + index);
  var input_check = object.find('.object-checkbox');
  // получаем информацию
  var inf = data.objects[index];
  var index_model = inf[3];
  var objects_checked_list = data.objects_checked[index_model];
  // проверяем
  if (input_check.is(':checked')){
    // меняем фон объекта на жёлтый
    object.css({'background': '#f6f7cd'});
    object.find('.object-click').css({'background': '#f6f7cd'});
    object.find('.object-name').css({'background': '#f6f7cd'});
    // записываем в словари
    if (change_quantity){
      objects_checked_list.quantity ++;
      objects_checked_list.objects[index] = inf[2];
    }
  }else{
    // меняем фон объекта на белый
    object.css({'background': 'white'});
    object.find('.object-click').css({'background': 'white'});
    object.find('.object-name').css({'background': 'white'});
    // записываем в словари
    if (change_quantity){
      objects_checked_list.quantity --;
      delete objects_checked_list.objects[index];
    }
  }
  // если надо менять значение главного, то меняем
  if (main_check){
    // меняем у пользователя на экране
    quantity_objects_in_model = data.models[index_model][3];
    quantity_cheked = objects_checked_list.quantity;
    model_objects_list = $('#model_objects_' + index_model);
    cont_quantity = model_objects_list.find('.object_header-quantity');
    // меняем значение количества
    if (quantity_cheked == 0){
      cont_quantity.html(quantity_objects_in_model + ' объектов');
      model_objects_list.find('.object_header-delete').css({'display': 'none'});
    }
    else{
      cont_quantity.html('Выбрано ' + quantity_cheked + ' из ' + quantity_objects_in_model + ' объектов');
      model_objects_list.find('.object_header-delete').css({'display': 'inline'});
    }
    // меняем значение главного чекбокса
    main_checkbox = model_objects_list.find('.object_header-checkbox');
    if (quantity_cheked == quantity_objects_in_model){
      main_checkbox.prop('checked', true);
    }
    else{
      main_checkbox.prop('checked', false);
    }
  }
}

async function cheked_all_objects(index_model){
  // находим элемент
  var model_objects_list = $('#model_objects_' + index_model);
  var input_check_main = model_objects_list.find('.object_header-checkbox');
  var cont_quantity = model_objects_list.find('.object_header-quantity');
  // находим данные
  var all_objects_in_model = data.models[index_model][4];
  var quantity_objects_in_model = data.models[index_model][3];
  var objects_checked_list = data.objects_checked[index_model];
  // проверяем
  if (input_check_main.is(':checked')){
    // проходимся по объектам и ставим галочки
    for (index_object in all_objects_in_model){
      // получаем элемент по индексу (объект)
      var object = $('#object_' + index_object);
      // ставим галочку
      object.find('.object-checkbox').prop('checked', true);
      cheked_object(index_object, main_check = false);
    }
    objects_checked_list.quantity = quantity_objects_in_model;
    cont_quantity.html('Выбрано ' + quantity_objects_in_model + ' из ' + quantity_objects_in_model + ' объектов');
    input_check_main.prop('checked', true);
    // кнопка удалить
    model_objects_list.find('.object_header-delete').css({'display': 'inline'});
  }else{
    // проходимся по объектам и ставим галочки
    for (index_object in all_objects_in_model){
      // получаем элемент по индексу (объект)
      var object = $('#object_' + index_object);
      // ставим галочку
      object.find('.object-checkbox').prop('checked', false);
      cheked_object(index_object, main_check = false);
    }
    objects_checked_list.quantity = 0;
    cont_quantity.html(quantity_objects_in_model + ' объектов');
    input_check_main.prop('checked', false);
    // кнопка удалить
    model_objects_list.find('.object_header-delete').css({'display': 'none'});
  }
}


// функция преобразования в html
function create_component(value, index, object_name = '', object_pk = ''){
  // добавляем текст в подкласс
  if (value == 'app'){
    var text = `
    <div class='app' id='app_` + index + `' onclick="open_app_component(` + index + `, true);">
      <button class='app-name'></button>
      <img src='/static/img/icons/new_build_arrow_white.png' class='component-arrow'>
    </div>
    <div class='app-models-list' id='app_models_` + index + `'> </div>
    `;
  }
  else if (value == 'model'){
    var text = `
    <div class='model' id='model_` + index + `' onclick="open_model_component(` + index + `, true);">
      <button class='model-name'></button>
      <img src='/static/img/icons/new_build_arrow.png' class='component-arrow'>
    </div>
    <div class='model-objects-list' id='model_objects_` + index + `'> </div>
    `;
  }
  else if (value == 'object-header'){
    var text = `
    <div class='object_header' id='object_header_` + index + `'>
      <div class='object_header-checkbox-div'> <input type="checkbox" class='object_header-checkbox' onclick='cheked_all_objects(` + index + `);'> </div>
      <div class='object_header-add-div'> <button class='object_header-add' onclick='add_new_object(` + index + `);'>+ Добавить</button> </div>
      <div class='object_header-quantity-div'> <button class='object_header-quantity'>10 объектов</button> </div>
      <div class='object_header-delete-div'> <button class='object_header-delete' onclick='delete_objects_in_model(` + index + `);'>Удалить</button> </div>
      <div class='object_header-filter'>
        <button id='object_header_filter_1' class='object_header-filter_button' onclick="filter_objects(${index}, 'pk_down')"; style='border-bottom: 2px #088A85 solid;'>⬇pk</button>
        <button id='object_header_filter_2' class='object_header-filter_button' onclick="filter_objects(${index}, 'pk_up')";>⬆pk</button>
        <button id='object_header_filter_3' class='object_header-filter_button' onclick="filter_objects(${index}, 'alphabet')";>Ab</button>
      </div>
    </div>
    `;
  }
  else if (value == 'object'){
    var text = `
    <div class='object' id='object_` + index + `'>
      <div class='object-checkbox-div'> <input type="checkbox" class='object-checkbox' onclick='cheked_object(` + index + `);'> </div>
      <div class='object-click' onclick="edit_object(` + index + `);">
        <button class='object-pk'>` + object_pk + `</button>
        <div class='object-name-div'> <button class='object-name'>` + object_name + `</button> </div>
      </div>
    </div>
    `;
  }
  return text
}



// показать / скрыть объекты в приложении
async function open_app_component(index, bl){
  if (bl){
    // находим елемент
    var app = $('#app_' + index);
    app.attr('onclick', 'open_app_component(' + index + ', false)');
    app.find('.component-arrow').css({'transform': 'rotate(180deg)'});
    // находим елемент списка
    var app_list = $('#app_models_' + index);
    app_list.css({'height': 'auto'});
  }
  else{
    // находим елемент
    var app = $('#app_' + index);
    app.attr('onclick', 'open_app_component(' + index + ', true)');
    app.find('.component-arrow').css({'transform': 'rotate(0deg)'});
    // находим елемент списка
    var app_list = $('#app_models_' + index);
    app_list.css({'height': 0});
  }
}

// вставляем объекты в список объектов модели
async function add_objects_to_model_list(index){
  // получаем объекты по json и вставляем (если не получили в прошлом)
  var data_list = data['models'][index];
  if (data_list[2] == ''){
    // выполняем запрос
    var request_post_data = {'app': data_list[0], 'model': data_list[1]}
    var url = '/admin/get_objects_in_model';
    var json = await request_for_json_post(url, request_post_data);
    if (json.status != undefined){
      open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
      return;
    }
    data['models'][index][2] = json;
  }
  // теперь добавляем объекты в модель
  var container = $('#model_objects_' + index);
  var text_all = '';
  // прописываем сверху опции
  var text_header = create_component('object-header', index);
  text_all += text_header;
  // добавляем объекты
  var index_object = 0;
  var objects = data['models'][index][2];
  // добавляем начало (контейнер самих объектов)
  text_all += "<div class='model-objects-list-2'>";
  for (pk in objects){
    index_object ++;
    index_object_global ++;
    var title_object = objects[pk];
    // создаём компонент объекта
    var text = create_component('object', index_object_global, object_name = title_object, object_pk = pk);
    text_all += text;
    // добавляем в общий словарь
    data['objects'][index_object_global] = [data_list[0], data_list[1], pk, index, ''];
    data['objects_checked'][index] = {'quantity': 0, 'objects': {}};
    data['models'][index][4][index_object_global] = pk;
  }
  text_all += '</div>';
  container.html(text_all);
  // прописываем сколько вообще объектов
  data['models'][index][3] = index_object;
  // если нет объектов, то пишем об этом
  if (index_object == 0){
    container.html(`<div style='margin-top: 0px;' class='object_header-add-div'> <button class='object_header-add' onclick='add_new_object(` + index + `);'>+ Добавить</button> </div>`);
    var line = "<center> <button class='no_models' style='margin-top: 5px;'> Не обнаружено объектов </button> </center>";
    container.append(line);
  }
  else{
    // прописываем сколько объектов
    container.find('.object_header-quantity').html(index_object + ' объектов');
  }
}
// показать / скрыть объекты в модели
async function open_model_component(index, bl){
  if (bl){
    // находим елемент
    var app = $('#model_' + index);
    app.attr('onclick', 'open_model_component(' + index + ', false)');
    app.find('.component-arrow').css({'transform': 'rotate(180deg)'});
    // находим елемент списка
    var app_list = $('#model_objects_' + index);
    // получаем объекты по json и вставляем (если не получили в прошлом)
    if (data['models'][index][2] == ''){
      await add_objects_to_model_list(index);
    }
    // меняем его стиль
    app_list.css({'height': 'auto', 'margin-top': 13, 'margin-bottom': 15});
  }
  else{
    // находим елемент
    var app = $('#model_' + index);
    app.attr('onclick', 'open_model_component(' + index + ', true)');
    app.find('.component-arrow').css({'transform': 'rotate(0deg)'});
    // находим елемент списка
    var app_list = $('#model_objects_' + index);
    //app_list.html('');
    app_list.css({'height': 0, 'margin-top': 0, 'margin-bottom': 0});
  }
}


async function show_apps(apps_names){
  // получаем имена моделей
  if (data['apps'] == ''){
    var url = '/admin/get_names_apps_and_models?all=False';
    var json = await request_for_json(url);
    if (json.status != undefined){
      open_notification('error', text = `<b style="font-size: 15px;">${json.status}</b><div style="height: 0px;"></div><br>${json.error}`);
    }
    data['apps'] = json;
  }
  // берём контейнер где приложения и обнуляем его
  $('.apps').html('');
  // создаём индекс приложений
  var index = 0;
  for (app_name in data['apps']){
    index ++;
    // создаём контейнер приложения
    var text = create_component('app', index);
    $('.apps').append(text);
    // меняем имя приложения
    $('#app_' + index).find('.app-name').html(app_name);
    // находим котэйнер с нашими будущими моделями
    var app_container = $('#app_models_' + index);
    // проходимся по именам моделям и вписываем
    var index_model = 0;
    for (model_name in data['apps'][app_name]){
      // получаем индекс модели
      index_model ++;
      index_model_global ++;
      // вставляем имя модели
      var text = create_component('model', index_model_global);
      app_container.append(text);
      // находим модель
      var model = $('#model_' + index_model_global);
      // меняем имя модели
      model.find('.model-name').html(model_name);
      // добавляем в общий список
      data['models'][index_model_global] = [app_name, model_name, '', 0, {}, '', 'pk_down'];
      // закрываем объекты в модели
      open_model_component(index_model_global, false);
    }
    // если нет моделей, то выводим текст
    if (index_model == 0){
      var line = "<center> <button class='no_models'> Не обнаружено моделей </button> </center>";
      app_container.append(line);
    }
    // показываем модели в приложении
    open_app_component(index, true);
  }
}

// показываем приложения и модели
show_apps();

// ------------------------ события мыши и курсора
window_notification_open_button = $('.window_notification_all-open_button');
window_bookmark_open_button = $('.window_bookmark-open_button');

async function window_events(){
  $(document).on('click', function(e){
    // проверка при скрытии окна подсказки месяца
    if (data_events.date_choose.state == 'show'){
      var input = data_events.date_choose.date_choose_month;
      var prompt_months = data_events.date_choose.container_months;
      if (e.target != prompt_months[0] && prompt_months.has(e.target).length == 0 && input.has(e.target).length == 0 && e.target != input[0]){
        prompt_months.hide();
      }
    }
  });
  // кликнуть по затемнению, то окно редактирования пропадёт
  dark.click(function(){
    show_window_edit(bl = false);
    // добавляем в закладки
    add_bookmark();
  });
  dark_strong.click(function(){
    open_textarea_full_screen(field_index=0, bl=false);
  });
  // перезапуск таймера, при наведении на него
  $('.window_notification').mouseenter(function(){
    clearTimeout(notification_timeout);
  }).mouseleave(function(){
    window['notification_timeout'] = setTimeout(close_notification, 3500);
  });
  // кнопка закладок при наведении на уведомления
  window_notification_open_button.mouseenter(function(){
    window_bookmark_open_button.css({'right': 210});
  }).mouseleave(function(){
    window_bookmark_open_button.css({'right': 90});
  });
  // кликнули по затемнению, убираем выбор даты
  data_events.date_choose.dark.on('click', function(){
    if (data_events.date_choose.state == 'show'){
      close_window_date_choose(act='hide');
    }
  });
}
$(function(){ window_events(); });

// ------------------------ resize scale window
// ---- events
async function resize(){
  wh = window.innerHeight;
  ww = window.innerWidth;
  // главное окно
  $('.div_main').css({'height': wh - 100});
  // окошко редактирования
  $('.window_edit').css({'height': wh - 100, 'left': Math.round(ww / 2 - 350)});
  $('.window_edit-scroll').css({'height': wh - 180});
  // затемнение документа
  dark.css({'height': wh - 100});
  dark_strong.css({'height': wh});
  // textarea
  textarea_main_div.css({'height': wh - 200, 'width': ww - 200, 'top': 50, 'left': 100});
  textarea_main.css({'height': wh - 200, 'width': ww - 200});
}
resize();
window.addEventListener("resize", () => resize());


// нажатия по клавишам
document.onkeydown = fkey;
function fkey(e){
        var e = e || window.event;

        if (e.keyCode == 27) { open_textarea_full_screen(field_index=0, bl=false); }
 }

// end.
