// определяем переменные
var params = {
         'webcams': [false, 'punkt_1', 'Вебкамеры', ''],
        'new_buildings': [true, 'punkt_3', 'Новостройки', ''],
        'districts': [false, 'punkt_9', 'Районы', ''],
        'infrastructure': [false, 'punkt_6', 'Инфраструктура', ''],
        'housing_stock': [false, 'punkt_2', 'Жилищный фонд', ''],
        'plots': [false, 'punkt_4', 'Участки', ''],
        'transport_accessibility': [false, 'punkt_5', 'Транс. доступность', ''],
        'selling_price': [false, 'punkt_7', 'Цена продажи', ''],
        'rent_price': [false, 'punkt_8', 'Цена аренды', '']
};


// =========================================== просто полезные функции
function view_methods_on_object(ob){
  for (key in ob){
    console.log(key);
  }
}

// request json function
async function request_for_json(url){
  let response = await fetch(url);
  if (response.ok) {
    var json = await response.json();
    return json
  }
  else{
    return response
  }
}

// изображение на весь экран
function open_image_in_full_window(src, bl = true){
  img = $('.dark-strong-img-center');
  dark = $('.dark-strong');
  if (bl){
    img.attr('src', src);
    // меняем размер
    img.on('load', function(){
      wh = window.innerHeight; ww = window.innerWidth;
      nh = this.naturalHeight; nw = this.naturalWidth;
      // случаи рассматриваем
      if (wh > nh && ww > nw){
        img.css({'height': nh, 'width': nw, 'top': Math.round((wh - nh) / 2), 'left': Math.round((ww - nw) / 2)});
      }
      else{
        // находим наибольшее отношение
        max_attitude = Math.max.apply(null, [nh / (wh - 100), nw / (ww - 100)]);
        new_h = Math.round(nh / max_attitude);
        new_w = Math.round(nw / max_attitude)
        img.css({'height': new_h, 'width': new_w, 'top': Math.round((wh - new_h) / 2), 'left': Math.round((ww - new_w) / 2)});
      }
      img.css({'display': 'inline'});
      dark.css({'opacity': 0.7, 'width': '100%', 'transition': 'opacity 0.2s'});
    });
  }
  else{
    img.css({'display': 'none'});
    dark.css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
  }
}

// функция преобразования в html
function create_new_build_component(cl_text){
  // добавляем текст в главный подкласс
  text = `
  <div class='new_build_watch-put_forward' onclick="open_new_build_component('` + cl_text + `', true);">
    <img src='/static/img/icons/new_build_doc.png' class='new_build_watch-put_forward-img'>
    <div class='new_build_watch-put_forward-header'>Документы</div>
    <img src='/static/img/icons/new_build_arrow.png' class='new_build_watch-put_forward-img-arrow'>
  </div>
  <div class='` + cl_text + `-list'>
  </div>
  `;
  return text
}

// открыть / зарыть компоненты новостройки
function open_new_build_component(cl, bl){
  c = $('.' + cl);
  if (bl){
    // показываем что внутри
    c.find('.' + cl + '-list').css({'height': 'auto'});
    // поворачиваем картинку
    c.find('.new_build_watch-put_forward-img-arrow').css({'transform': 'rotate(180deg)'});
    // меняем значение
    c.find('.new_build_watch-put_forward').attr('onclick', "open_new_build_component('" + cl + "', false);");
  }
  else{
    // показываем что внутри
    c.find('.' + cl + '-list').css({'height': 0});
    // поворачиваем картинку
    c.find('.new_build_watch-put_forward-img-arrow').css({'transform': 'rotate(0deg)'});
    // меняем значение
    c.find('.new_build_watch-put_forward').attr('onclick', "open_new_build_component('" + cl + "', true);");
  }
}


// ================================================= MAP (открыто)
var tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
	maxZoom: 18,
	attribution: 'maphouse.ru'
}), latlng = L.latLng(54.7324, 55.9458);

var Icon_camera = L.icon({
  iconUrl: '/static/img/icons/cam_icon.png',
  //shadowUrl: 'leaf-shadow.png',
  iconSize: [32, 37],
  iconAnchor: [parseInt(32 / 2), 37],
  popupAnchor: [0, -(37)]
});

var Icon_build = L.icon({
  iconUrl: '/static/img/icons/new_build.png',
  iconSize: [35, 30],
  iconAnchor: [17, 37],
  popupAnchor: [0, -(30)]
});

var map = L.map('map', {center: latlng,
                        zoom: 12,
                        layers: [tiles],
                        zoomDelta: 0.5,
                        zoomSnap: 0,
                        wheelPxPerZoomLevel: 70});

// scale map
L.control.scale({imperial: false}).addTo(map);

// controls zoom, scale
$('.leaflet-control').css({'margin-left': 260, 'transition': '0.3s'});
$('.leaflet-control-scale-line').css({'background': '#44535e', 'border': '2px white solid', 'color': 'white', 'box-shadow': '0px 0px 5px #44535e'});

// ------------------------------------------- создаём группы точек
//var webcam_markers = L.markerClusterGroup();
var webcam_markers = L.markerClusterGroup({
	iconCreateFunction: function(cluster) {
		return L.divIcon({ html: '<div class="claster_group2 group_webcams2"><div class="claster_group3">' + cluster.getChildCount() + '</div></div>', className: 'claster_group group_webcams', iconSize: L.point(40, 40) });
	}
});

var districts_polygons = new L.layerGroup();

var new_buildings_markers = L.markerClusterGroup({
	iconCreateFunction: function(cluster) {
		return L.divIcon({ html: '<div class="claster_group2 group_builds2"><div class="claster_group3">' + cluster.getChildCount() + '</div></div>', className: 'claster_group group_builds', iconSize: L.point(40, 40) });
	}
});
// ================================================ MAP (закрыто)


// для каждого фильтра своё окошечко на карте
function open_camera_view(pk, bl){
  if (bl){
    json = params['webcams'][3];
    title = json[pk][0]; server = json[pk][3];
    $('.camera-title').html(title);
    $('.camera-watch-video').attr('src', '/camera_embed?pk=' + pk);
    if (server == 'ufanet'){
      $('.camera-server').html('Трансляция идёт с сайта <a class="camera-server-a" href="http://maps.ufanet.ru/ufa">maps.ufanet.ru</a>');
    }
    // показываем
    $('.window_to_watch_camera').css({'display': 'inline'});
    $('.dark').css({'opacity': 0.55, 'width': '100%', 'transition': 'opacity 0.2s'});
  }
  else{
    // закрываем
    $('.window_to_watch_camera').css({'display': 'none'});
    $('.dark').css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
  }
}
// окно новостройки
async function open_window_to_new_build(pk, bl){
  if (bl){
    // ---------------- сначала получаем json
    url = '/all_inf_from_new_build?pk=' + pk;
    var json = await request_for_json(url);
    // ---------- обрабатываем (получаем значения)
    // сначала изображения
    // main photo
    $('.new_build_watch-photo-main').attr('src', json['photo']['big_quality'][0]);
    // others photo
    // clean div
    $('.new_build_watch-photo-divgrid').html('');
    photos_length = json['photo']['min_quality'].length;
    quantity_photo_columns = Math.ceil(photos_length / 2);
    $('.new_build_watch-photo-divgrid').css({'grid-template-columns': 'repeat(' + Math.max.apply(null, [2, quantity_photo_columns]) + ', 122px)'});
    for (i = 1; i < Math.max.apply(null, [5, quantity_photo_columns * 2 + 1]); i++){
      src_min = json['photo']['min_quality'][i];
      src_max = json['photo']['big_quality'][i];
      if (src_min != undefined){
        line = "<img src='" + src_min + "' class='new_build_watch-photo-other-photo' onclick=open_image_in_full_window('" + src_max + "')>";
      }else{
        line = "<div class='new_build_watch-photo-no-photo'></div>";
      }
      $('.new_build_watch-photo-divgrid').append(line);
    }
    // ---------------- теперь название
    title = json['title'];
    $('.new_build_watch-title').html(title);
    // --------- street
    street = json['street'];
    $('.new_build_watch-street').html(street.charAt(0).toUpperCase() + street.slice(1));
    // ---------------- creator, deadline
    creator = json['information']['creator'];
    $('.new_build_watch-developer').html("<span style='color: #44535e;'>Застройщик: </span> " + creator);
    deadline = json['information']['deadline'];
    $('.new_build_watch-deadline').html("<span style='color: #44535e;'>Срок сдачи: </span> " + deadline);
    // --------------- documents
    documents = json['others']['Documents'];
    cl_text = 'new_build_documents';
    cl = $('.' + cl_text);
    cl.html('');
    if (documents.length > 0){
      // добавляем текст в главный подкласс
      text = create_new_build_component(cl_text);
      cl.html(text);
      // проходимся по списку и добавляем
      for (i = 0; i < documents.length; i++){
        doc = documents[i];
        line = "<div><a class='new_build_watch-document-div' href='" + doc['downloadUrl'] + "'>" + doc['name'] + "</a></div>";
        $('.new_build_documents-list').append(line);
      }
      // закрываем
      open_new_build_component(cl_text, false);
      // показываем
      cl.css({'display': 'inline'});
    }
    else{
      cl.css({'display': 'none'});
    }
    // =============================
    // ------------- показываем
    $('.new_build_watch').css({'display': 'inline'});
    $('.dark').css({'opacity': 0.55, 'width': '100%', 'transition': 'opacity 0.2s'});
    // значение прокрутки устанавливаем на 0
    $('.new_build_watch-photo').scrollLeft(0);
  }
  else{
    // закрываем
    $('.new_build_watch').css({'display': 'none'});
    $('.dark').css({'opacity': 0.0, 'width': '0px', 'transition': 'opacity 0.2s'});
  }
}

// закрыть все окна фильтров (камеры и т.д.)
function close_all_filters_windows(){
  open_camera_view(1, false);
  open_window_to_new_build(1, false);
}

// ==================== ART MAP ===============================================
async function update_map_art(name, bl){
  // вебкамеры
  if (name == 'webcams'){
    if (bl){
      // сначала получаем json
      if (params[name][3] == ''){
        url = '/get_all_cameras';
        var json = await request_for_json(url);
        params[name][3] = json;
      }
      else{
        var json = params[name][3];
      }
      // теперь обрабатываем
      for (pk in json){
        x = json[pk][1]; y = json[pk][2];
        div = "<button class='button_to_open_camera_view' onclick='open_camera_view(" + pk + ", true);'>Смотреть камеру</button>";
        var marker = L.marker([x, y], {icon: Icon_camera});
        marker.bindPopup(div);
        webcam_markers.addLayer(marker);
      }
      // добавляем маркеры на карту
      map.addLayer(webcam_markers);
    }
    else{
      webcam_markers.removeFrom(map);
      webcam_markers.clearLayers();
    }
  }
  // районы
  if (name == 'districts'){
    if (bl){
      // сначала получаем json
      if (params[name][3] == ''){
        url = '/get_all_districts';
        var json = await request_for_json(url);
        params[name][3] = json;
      }
      else{
        var json = params[name][3];
      }
      // теперь обрабатываем
      for (pk in json){
        district_name = json[pk][0]; points = json[pk][1];
        div = "<div class='district-title'>" + district_name + "</div> <div class='district-button'>Искать в этом районе</div>";
        var polygon = L.polygon(points, {fillOpacity: 0.1, weight: 2});
        polygon.bindPopup(div);
        polygon.on('mouseover', function(){
          this.setStyle({fillOpacity: 0.25});
        });
        polygon.on('mouseout', function(){
          this.setStyle({fillOpacity: 0.1});
        });
        districts_polygons.addLayer(polygon);
      }
      // добавляем районы на карту
      map.addLayer(districts_polygons);
    }
    else{
      districts_polygons.removeFrom(map);
      districts_polygons.clearLayers();
    }
  }
  // новостройки
  if (name == 'new_buildings'){
    if (bl){
      // сначала получаем json
      if (params[name][3] == ''){
        url = '/get_all_new_buildings';
        var json = await request_for_json(url);
        params[name][3] = json;
      }
      else{
        var json = params[name][3];
      }
      // теперь обрабатываем
      for (pk in json){
        // получаем значения
        title = json[pk]['title'];
        coordinates = json[pk]['coordinates'];
        price_min = json[pk]['price_min'];
        quantity_m2_min = json[pk]['quantity_m2_min'];
        main_photo = json[pk]['main_photo'];
        // создаём контейнер
        div = "<div class='new_build_preview'> <img class='new_build_preview-photo' src='" + main_photo + "'> <div class='new_build_preview-title'>" + title + "</div> <div class='new_build_preview-hr'></div> <div class='new_build_preview-minprice'>Цена от <span class='new_build_preview-minprice-b'>" + quantity_m2_min + "м²</span> от <span class='new_build_preview-minprice-b'>" + price_min + "</span> </div> <button class='new_build_preview-button' onclick='open_window_to_new_build(" + pk + ", true);'>Больше информации</button> </div>";
        // создаём маркер и добавляем в общий список
        var marker = L.marker(coordinates, {icon: Icon_build});
        marker.bindPopup(div);
        // обработчики событий курсора
        marker.on('mouseover', function(){
          var marker_event = this;
          var popup_container = marker_event._popup._container;
          clearTimeout(marker_event._hide_timer);
          marker_event.openPopup();
          $(popup_container).mouseenter(function(){ clearTimeout(marker_event._hide_timer);
          }).mouseleave(function(){ marker_event._hide_timer = setTimeout(function(){marker_event.closePopup();}, 300); });
        });
        // === >>>
        marker.on('mouseout', function(){
          var marker_event = this;
          var popup_container = marker_event._popup._container;
          this._hide_timer = setTimeout(function(){ marker_event.closePopup(); }, 300);
          $(popup_container).mouseenter(function(){ clearTimeout(marker_event._hide_timer);
          }).mouseleave(function(){ marker_event._hide_timer = setTimeout(function(){marker_event.closePopup();}, 300); });
        });
        // добавляем в общий список новостроек
        new_buildings_markers.addLayer(marker);
      }
      // добавляем новостройки на карту
      map.addLayer(new_buildings_markers);
    }
    else{
      new_buildings_markers.removeFrom(map);
      new_buildings_markers.clearLayers();
    }
  }
}


// делаем выдвижение карты и кнопку к ней
var vidvig_map = 'open';
function strelka(){
  wh = window.innerHeight;
  ww = window.innerWidth;
  // переправляем
  if (vidvig_map == 'open'){
    $('.side-panel').css({'left': -200});
    $('.down-panel').css({'left': -200});
    $('.strelka').css({'left': 62, 'transform': 'rotate(180deg)'});
    $('.leaflet-control').css({'margin-left': 60});
    window['vidvig_map'] = 'close';
  }else{
    $('.side-panel').css({'left': 0});
    $('.down-panel').css({'left': 0});
    $('.strelka').css({'left': 262, 'transform': 'rotate(0deg)'});
    $('.leaflet-control').css({'margin-left': 260});
    window['vidvig_map'] = 'open';
  }
}

// тема карты
var tema_map = 'usual';
function change_tema_map(){
  tiles.removeFrom(map);
  if (tema_map == 'usual'){
    satelliteLayer = L.tileLayer("http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{attribution: "myhomeprice.ru", maxZoom: 18}).addTo(map);
    window['tema_map'] = 'spytnik';
    // добавляем border
    $('.side-panel').css({'border-right': '5px white solid'});
    $('.down-panel').css({'border-right': '5px white solid'});
    $('.strelka-img').attr('src', '/static/img/strelka_black.png');
    // изменяем src изображения
    $('.change_type_map-img').attr('src', '/static/img/one_map.png');
  } else {
    satelliteLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution: "myhomeprice.ru", maxZoom: 18}).addTo(map);
    window['tema_map'] = 'usual';
    // убираем border
    $('.side-panel').css({'border-right': '0px white solid'});
    $('.down-panel').css({'border-right': '0px white solid'});
    $('.strelka-img').attr('src', '/static/img/strelka.png');
    // изменяем src изображения
    $('.change_type_map-img').attr('src', '/static/img/spytnik.png');
  }
}

// ================= деалем высоту у боковой панели и если пользователь поменял
async function resize(){
  wh = window.innerHeight;
  ww = window.innerWidth;
  // переправляем
  $(".side-panel").css({'height': wh - 100 - 70});
  $(".side-panel-filters").css({'height': wh - 100 - 70 - 80});
  // окошко просмотра камеры
  $('.window_to_watch_camera').css({'height': wh - 100, 'left': Math.round(ww / 2 - 350)});
  // окошко просмотра новостройки
  $('.new_build_watch').css({'height': wh - 100, 'left': Math.round(ww / 2 - 350)});
  // затемнение документа
  $('.dark').css({'height': wh - 100});
  $('.dark-strong').css({'height': wh});
  // карта
  $('#map').css({'height': wh - 100, 'width': ww});
  await setTimeout(function(){ map.invalidateSize()}, 300);
}
resize();
window.addEventListener("resize", () => resize());


// фильтры меняем
function sbros_params(){
  for (key in params){
    els = params[key];
    params[key][0] = false;
  }
}

function update_params(el, pr){
  var el_id = el.attr('id').toString();
  var pnbtn = el.find(".toggle-input");
  var pnbtn_text = pnbtn.attr('value').toString();
  // обновляем
  params[pnbtn_text][0] = pr;
}

function update_punkt(el, bl_punkt){
  var inp = el.find(".toggle-input");
  var tgbtn = el.find(".toggle-button");
  var tgrnd = el.find(".toggle-round");
  var pt = el.find(".punkt-text");
  if (bl_punkt){
      inp.prop('checked', true);
      tgrnd.css({'background': '#F6CEEC', 'margin-left': 24, 'box-shadow': '-2px 5px 5px #31383d'});
      tgbtn.css({'background': '#b1bdbb', 'box-shadow': '0px 5px 5px #303b42'});
      pt.css({'text-decoration': 'none'});
  }else{
      inp.prop('checked', false);
      tgrnd.css({'background': 'white', 'margin-left': -4, 'box-shadow': '0px 5px 5px #2b486a'});
      tgbtn.css({'background': '#9A9999', 'box-shadow': '0px 0px 0px #303b42'});
      pt.css({'text-decoration': 'none'});
  }
}

function update_state(){
  for (key in params){
    els = params[key];
    bl = els[0]; el_id = '#' + els[1];
    el = $(el_id);
    update_punkt(el, bl);
    update_map_art(key, bl);
  }
}

function add_punkts_filters(){
  for (key in params){
    els = params[key];
    bl = els[0]; el_id = els[1]; el_name = els[2];
    line = "<div class='punkt' id='" + el_id + "'><div class='punkt-text'>" + el_name + "</div><div class='toggle'><input type='checkbox' class='toggle-input' value='" + key + "'><div class='toggle-button'><div class='toggle-round'></div></div></div><div style='height: 5px'></div>";
    $(".side-panel-filters").append(line);
    el = $('#' + el_id);
    update_punkt(el, bl);
    update_map_art(key, bl);
  }
}
add_punkts_filters();


// выпадающее меню
var open_down_box_var = 'close';

function open_down_box(cord, act){
  if (act == 'open' || open_down_box_var == 'open'){
    $(".header-down-box").css({'left': cord.left - 60, 'top': cord.top + 60, 'transition': '0.3s', 'height': 120, 'display': 'inline', 'opacity': 1.0, 'z-index': 1005});
  }
  else{ $(".header-down-box").css({'left': cord.left - 60, 'top': cord.top + 50, 'transition': '0.3s', 'height': 0, 'display': 'inline', 'opacity': 0.0, 'z-index': 1005}); }
}

$(function(){
        // кликнуть по input в filters
        $('.punkt').click(function(){
          var el = $(this);
          var inp = el.find(".toggle-input");
          var tgrnd = el.find(".toggle-round");
          if (inp.is(':checked')){
              bl_punkt = false;
          }else{
              bl_punkt = true;
          }
          //sbros_params();
          update_params(el, bl_punkt);
          update_punkt(el, bl_punkt);
          update_map_art(inp.attr('value').toString(), bl_punkt);
          //update_state();
        })
        // выпадающее меню
        $(".header-others").mouseenter(function() {
            var el = $(this);
            open_down_box(el.offset(), 'open');
        })
        .mouseleave(function(){
            var el = $(this);
            open_down_box(el.offset(), 'close');
        });
        $(".header-others").click(function() {
            window['open_down_box_var'] = 'open';
            var el = $(this);
            open_down_box(el.offset(), 'open');
        });
        // если кликнули по затемнению, то закрываем все окна
        $(".dark").click(function() {
            close_all_filters_windows();
        });
        $(".dark-strong").click(function() {
            open_image_in_full_window('', false);
        });
});

document.addEventListener("click", function(e){
  var x = e.pageX;
  var y = e.pageY;
  // выпадающая меню
  el = $(".header-down-box").offset();
  if (x < el.left || x > el.left + 160 || y < el.top - 40 || y > el.top + 120) {
    window['open_down_box_var'] = 'close';
    var el2 = $(".header-others");
    open_down_box(el2.offset(), 'close');
  }
});


// нажатия по клавишам
document.onkeydown = fkey;
function fkey(e){
        e = e || window.event;

        if (e.keyCode == 27) { open_image_in_full_window('', false); }
 }
