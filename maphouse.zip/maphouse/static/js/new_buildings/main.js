// start:

function create_array_true(n, value=true){
  var array = [];
  for (i=0; i<n; i++){
    array.push(value);
  }
  return array;
}

function count(array, from=0, n=true){
  var quantity = 0;
  for (var i=from; i<array.length; i++){ if (array[i] == n){ quantity++; } }
  return quantity;
}

function shorten_title(text, limit=10){
  if (text.length - limit > 1){ var text = text.substring(0, limit) + '...'; }
  return text;
}

function dhtmlLoadScript(url, func=function(){}){
  var e = document.createElement("script");
  e.addEventListener('load', func);
  e.src = url;
  e.type="text/javascript";
  document.getElementsByTagName("head")[0].appendChild(e);
}

function clone(obj){
  return Object.assign({}, obj);
}

function clone_array(obj){
  return Object.assign([], obj);
}

function range(l1, l2, diff=1){
  return [...Array(l2 - l1 + 1)].map((e, i) => i * diff + l1);
}

function sum_array(array, l1, l2){
  var sum = 0; var l2 = Math.min(l2, array.length - 1);
  for (var i=l1; i<=l2; i++){sum += array[i];}
  return sum;
}

function sum(array){
  return array.reduce((a, b) => a + b, 0);
}

function average_value(array, l1, l2){
  var sum = sum_array(array, l1, l2);
  return (sum / (l2 - l1 + 1));
}

function min(array){
  return Math.min(...array);
}

function average(array){
  return sum(array) / array.length;
}

function max(array){
  return Math.max(...array);
}

function max_value(array, l1, l2){
  var max_element = 0; var l2 = Math.min(l2, array.length - 1);
  for (var i=l1; i<=l2; i++){ if (max_element < array[i]){max_element = array[i];} }
  return max_element;
}

function sort(data, key_func = x => x){
  data.sort(function(a, b){ return key_func(a) > key_func(b) ? 1 : -1 });
  return data;
}

function split_into_n(data, n, func=average_value){
  var data_new = create_array_true(Math.ceil(data.length / n), 0);
  for (var index = 0; index < data_new.length * n; index += n){
    var a_value = func(data, index, index + n - 1);
    data_new[Number(index / n)] = a_value;
  }
  return data_new;
}

function concat(array1, array2){
  array2.forEach((item) => {array1.push(item);});
  return array1;
}

function delete_certain_els(array, el, leave=false){
  var new_array = [];
  array.forEach((item) => {
    if (item != el){ new_array.push(item); }
  });
  if (leave && new_array.length == 0){ return[el]; }
  return new_array;
}

function last_el_dict(dict){
  var keys = Object.keys(dict);
  return dict[keys[keys.length - 1]];
}

function last_el_list(array){
  return array[array.length - 1];
}

function bring_quarter_to_date(str_date){
  var splitted_date = str_date.split('кв.');
  return new Date(`${splitted_date[1].trim()}-${Data_vars.quarter_to_date[splitted_date[0].trim()]}`);
}

function get_date_procent(d1, d2){
  var d1 = bring_quarter_to_date(d1);
  var d2 = bring_quarter_to_date(d2);
  var days_diff1 = Math.ceil((global_date_now.getTime() - d1.getTime()) / (1000 * 3600 * 24));
  var days_diff2 = Math.ceil((d2.getTime() - d1.getTime()) / (1000 * 3600 * 24));
  var procent = days_diff1 / days_diff2;
  return Math.min(Math.floor(procent * 100) / 100, 1);
}

function deg_to_rad(deg){
  return deg * (Math.PI / 180);
}

function get_clip_polygon(procent){
  var angle = procent * 360;
  if (0 < procent && procent < 1/8){ return `50% 0%, 50% 50%, ${50 + Math.ceil(Math.tan(deg_to_rad(angle)) * 50)}% 0%`; }
  else if (1/8 == procent){ return `50% 0%, 50% 50%, 100% 0%`; }
  else if (1/8 < procent && procent < 3/8){ return `50% 0%, 50% 50%, 100% ${Math.ceil(50 *  Math.sqrt(2) * Math.sin(deg_to_rad(angle - 45)) / Math.sin(deg_to_rad(180 - angle)))}%, 100% 0%`; }
  else if (3/8 == procent){ return `50% 0%, 50% 50%, 100% 100%, 100% 0%`; }
  else if (3/8 < procent && procent < 5/8){ return `50% 0%, 50% 50%, ${100 - Math.ceil(50 *  Math.sqrt(2) * Math.sin(deg_to_rad(angle - 135)) / Math.sin(deg_to_rad(270 - angle)))}% 100%, 100% 100%, 100% 0%`; }
  else if (5/8 == procent){ return `50% 0%, 50% 50%, 0% 100%, 100% 100%, 100% 0%`; }
  else if (5/8 < procent && procent < 7/8){ return `50% 0%, 50% 50%, 0% ${100 - Math.ceil(50 * Math.sqrt(2) * Math.sin(deg_to_rad(angle - 225)) / Math.sin(deg_to_rad(360 - angle)))}%, 0% 100%, 100% 100%, 100% 0%`; }
  else if (7/8 == procent){ return `50% 0%, 50% 50%, 0% 0%, 0% 100%, 100% 100%, 100% 0%`; }
  else if (7/8 < procent && procent < 1){ return `50% 0%, 50% 50%, ${50 - Math.ceil(50 * Math.tan(deg_to_rad(360 - angle)))}% 0%, 0% 0%, 0% 100%, 100% 100%, 100% 0%`; }
  else{ return `none`; }
}


// класс отправления запросов
class Request_class{
  // request json function
  async request_for_json(url){
    // получаем ответ
    let response = await fetch(url);
    if (response.ok) {
      var json = await response.json();
      return json
    }
    else{
      return response
    }
  }
  // request POST json function
  async request_for_json_post(url, data, basik=false){
    // проверяем на базовость
    if (basik){ var data_main = data;                 var headers = {'X-CSRFToken': csrf_token}; }
    else{       var data_main = JSON.stringify(data); var headers = {'Content-Type': 'application/json;charset=utf-8', 'X-CSRFToken': csrf_token}; }
    // заполянем запрос
    var header = {
      method: 'POST',
      headers: headers,
      body: data_main
    };
    let response = await fetch(url, header);
    if (response.ok) {
      var json = await response.json();
      return json
    }
    else{
      return response
    }
  }
}

// класс переменных данных
class Data_vars_class{
  constructor(){
    this.months = {1: 'январь', 2: 'февраль', 3: 'март', 4: 'апрель', 5: 'май', 6: 'июнь', 7: 'июль', 8: 'август', 9: 'сентябрь', 10: 'октябрь', 11: 'ноябрь', 12: 'декабрь'};
    this.rome_numbers = {'I': 1, 'II': 2, 'III': 3, 'IV': 4};
    this.quarter_to_date = {'I': '03-31', 'II': '06-30', 'III': '09-30', 'IV': '12-31'};
    this.conditional_class_cut = {'эконом': ['Эк', '#FF3D67'], 'комфорт': ['К', '#28C3C2'], 'бизнес': ['Б', '#6554C0'], 'элитный': ['Эл', '#FACC2E']};
    this.districts_data = [undefined, undefined];
    this.districts_data_urls = ['/api/get_administrative_districts', '/api/get_micro_districts'];
    this.districts_names = ['Районы', 'Микрорайоны'];
    this.data_names_list = [
         'name', 'apartments_cost',
         'cumulative_rating', 'plot_index', 'parking_index', 'mop_index', 'elevators_index', 'share_oneroom_apartments',
         'global_name', 'adress', 'district', 'microdistrict', 'start_date', 'deadline', 'object_readiness', 'phone', 'site', 'developer', 'builder',
         'number_apartments_project', 'apartments_sale_developer',
         'floors', 'conditional_class', 'decoration_level', 'parking_places', 'quantity_elevators', 'cadastral_number', 'land_area', 'all_area', 'living_area', 'energy_efficiency_class', 'bearing_wall_material', 'erz_id', 'coordinates'];
    this.data_names = {}
    this.data_names_list.forEach((item, i) => {this.data_names[item] = i;});
    // sector 2
    this.sector2_items_array_block_1 = [['Год сдачи литера', data_summary['year']], ['Количество этажей', data_summary['floors']], ['Количество квартир', data_summary['q_a']]];
    this.sector2_items_array_block_2 = [['Административный район', ['Все районы'].concat(data_summary['district']), 238, create_array_true(data_summary['district'].length + 1), 'районов'],
                                        ['Риэлторский район', ['Все районы'].concat(data_summary['microdistrict']), 238, create_array_true(data_summary['microdistrict'].length + 1), 'районов'],
                                        ['Материал несущих стен', ['Все типы'].concat(data_summary['b_w_m']), 238, create_array_true(data_summary['b_w_m'].length + 1), 'типов'],
                                        ['Энергоэффективность', ['Все классы'].concat(data_summary['e_f_c']), 218, create_array_true(data_summary['e_f_c'].length + 1), 'классов']];
    this.sector2_open_filter = undefined;
    // sector 3
    this.map_lib_is_load = false;
    this.light_area = {'on': false, 'markers': [], 'polyline': undefined, 'line': undefined, 'last_point': [undefined, undefined], 'start': false, 'coord_array': []};
    this.check_district_map_index = undefined;
    this.animation_stop_apply_filters = false;
    this.an_rects_colors = ['#FF3D67', '#EF9752', '#28C3C2', '#6554C0'];
    this.load_circle_exists_sector3 = true;
    // sector 4
    this.sector4_charts_filter2 = [0.4, 0.4];
    this.sector4_chart2_legend_hidden = [null, null, null];
    // sector 5
    this.sector5_names_of_columns = ['Название литера', 'Стоимость квартир', 'Сводный рейтинг', 'Индекс участка', 'Парковочный индекс', 'Индекс МОП', 'Лифтовой индекс',
                                     'Доля однокомнатных квартир', 'Название новостройки', 'Адрес', 'Административный район', 'Риэлторский район',
                                     'Дата начала стройки', 'Срок сдачи', 'Готовность', 'Телефон', 'Сайт проекта', 'Девелопер', 'Застройщик', 'Общее количество квартир', 'Количество квартир в продаже',
                                     'Количество этажей', 'Условный класс', 'Уровень отделки', 'Количество парковочных мест',
                                     'Количество лифтов', 'Кадастровый номер', 'Площадь участка', 'Общая площадь', 'Жилая площадь',
                                     'Энергетический класс', 'Материал стен', 'Координаты'];
    var excel_data_names = ['1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.'];
    var excel_data_names2 = ['Количество', 'Мин. цена', 'Ср. цена', 'Макс. цена', 'Мин. м²', 'Ср. м²', 'Макс. м²', 'Мин. руб/м²', 'Ср. руб/м²', 'Макс. руб/м²'];
    this.sector5_names_of_columns_excel = [...this.sector5_names_of_columns];
    this.sector5_names_of_columns_excel_apart = excel_data_names.map(x => excel_data_names2.map(y => `${x} - ${y}`)).reduce((arr, new_arr) => arr.concat(new_arr))
    this.sector5_names_of_columns_excel.splice(this.data_names['apartments_cost'], 1, ...this.sector5_names_of_columns_excel_apart);
    this.sector5_width_of_items_min = [200, 172, 165, 130, 161, 115, 145, 210, 180, 150, 190, 170, 150, 130, 130, 150, 150, 150, 150,    200, 216, 161, 140, 150, 215, 150, 150, 150, 170, 150, 160, 150, 150];
    this.sector5_width_of_items = [200, 172, 165, 130, 161, 115, 145, 210, 180, 150, 190, 170, 150, 130, 130, 150, 150, 150, 150,    200, 216, 161, 140, 150, 215, 150, 150, 150, 170, 150, 160, 150, 150];
    this.sector5_sum_width = sum_array(this.sector5_width_of_items, 0, this.sector5_width_of_items.length - 1) + 330;
    this.sector5_houses_in_page = 50;
    this.sector5_table_height_items = [0, [48, 40, 32]];
    this.sector5_table_rate = ['cumulative_rating', 'plot_index', 'parking_index', 'mop_index', 'elevators_index', 'share_oneroom_apartments'];
    this.sector5_table_rate_indexes = this.sector5_table_rate.map(x => this.data_names[x]);
    this.sector5_table_datetime = ['start_date', 'deadline'];
    this.sector5_table_datetime_indexes = this.sector5_table_datetime.map(x => this.data_names[x]);
    this.sector5_table_checked_items = [];
    this.sector5_table_checked_items_quantity_true = 0;
    this.index_start_item = 0;
    this.sorted_column = [this.data_names['cumulative_rating'], 1];
    this.excel_librari_is_load = false;
    this.sector5_container_filter_values = false;
    this.filter_by_input_table = 'name'; this.filter_by_input_table_index = 0;
    this.filter_by_input_table_text = '';
    this.load_circle_exists_sector5 = true;
    this.names_params_by_table_input = [['name', 'Название литера'], ['cadastral_number', 'Кадастровый номер'], ['adress', 'Адрес литера'], ['developer', 'Девелопер'], ['builder', 'Застройщик'], ['decoration_level', 'Уровень отделки'], ['bearing_wall_material', 'Материал стен']];
    // table switch (liters and build)
    this.liter_or_build = 'liter';
    this.array_of_sum_in_build = ['number_apartments_project', 'apartments_sale_developer', 'parking_places', 'quantity_elevators', 'land_area', 'all_area', 'living_area'];
    this.array_of_comma_in_build = ['name', 'global_name', 'adress', 'district', 'microdistrict', 'start_date', 'deadline', 'object_readiness', 'phone', 'site', 'developer', 'builder', 'conditional_class', 'decoration_level', 'cadastral_number', 'energy_efficiency_class', 'bearing_wall_material', 'coordinates'];
    this.build_cost_apartments_data = {};
    this.filtered_data_table_build_indexes = [];
    // footer
    this.footer_menu_data = [['О нас', '/information/about_us'], ['Справка', '/information/help'], ['Обратная связь', '/information/feedback'], ['Коммерческие предложения', '/information/commercial_offers']];
    this.footer_down_menu_data = [['Правила использования', '/information/terms_of_use'], ['Конфиденциальность', '/information/confidentiality']];
    this.footer_menu_soc_seti = [['https://tg.com/maphouse', '/static/img/housing_stock/telegram.svg'], ['https://tg.com/maphouse', '/static/img/housing_stock/vk.svg'], ['https://tg.com/maphouse', '/static/img/housing_stock/facebook.svg'], ['https://tg.com/maphouse', '/static/img/housing_stock/instagram.svg']];
    this.email_unique = []; this.email_unique_messages = [];
    this.newsletter_message_open = false;
  }
  // фильтруем по фильтрам наш жилищный фонд
  async apply_filters(update=true){
    var filtered_data_new = []; var filtered_data_indexes_new = [];
    var limits = Event_vars.sector2_block1_toggle.limits;
    var values_true = [[], [], [], []];
    Data_vars.sector2_items_array_block_2.forEach(function(item_array, index_item_array, array){
      item_array[3].forEach(function(item, index, array){
        if (item && index != 0){ values_true[index_item_array].push(item_array[1][index]); }
      });
    });
    // проходимся по всем объектам
    Data_vars.data.forEach(function(object, index_main, array){
      Data_vars.object_passed = true;
      // лимиты
      var check_params = [['deadline', x => Number(x.split('кв.')[1].trim())], ['floors', x => x[1]], ['number_apartments_project', x => x]];
      check_params.forEach(function(item, index, array){
        var value = item[1](object[Data_vars.data_names[item[0]]]);
        if ( !(limits[index][0] <= value && value <= limits[index][1]) ){ Data_vars.object_passed = false; }
      });
      if (Data_vars.object_passed){
        // селекты
        var check_params = ['district', 'microdistrict', 'bearing_wall_material', 'energy_efficiency_class'];
        check_params.forEach(function(item, index, array){
          if ( !values_true[index].includes(object[Data_vars.data_names[item]]) ){ Data_vars.object_passed = false; }
        });
      }
      // лежит ли в выделенной области
      if (Data_vars.object_passed && Data_vars.light_area.on){
        var xy = Data_vars.light_area.array_limits;
        // выделенное поле на карте
        var coord = object[Data_vars.data_names['coordinates']];
        // пред-фильтр (чтобы все не проверять)
        Data_vars.object_passed = false;
        if ((xy[0][0] <= coord[0] && coord[0] <= xy[0][1]) && (xy[1][0] <= coord[1] && coord[1] <= xy[1][1])){
          // главный фильтр поля
          var result = MML.polygon.Is_point_in_polygon(coord, Data_vars.light_area.coord_array);
          if (result){ Data_vars.object_passed = true; }
        }
      }
      // поиск по полю ввода при таблице
      if (Data_vars.object_passed && Data_vars.filter_by_input_table_text != ''){
        var text_true = object[Data_vars.data_names[Data_vars.filter_by_input_table]].toString().toLowerCase();
        if (!text_true.includes(Data_vars.filter_by_input_table_text)){
          Data_vars.object_passed = false;
        }
      }
      if (Data_vars.object_passed){ filtered_data_new.push(object); filtered_data_indexes_new.push(index_main); }
    });
    Data_vars.filtered_data = filtered_data_new; Data_vars.filtered_data_indexes = filtered_data_indexes_new;
    if (update){ Data_vars.update_sectors(); }
  }
  // запустить процесс по отфильтрованным данным на экране
  async update_sectors(){
    // если началась анимация, то выключаем её
    if (Event_vars.animation_started){
      Data_vars.animation_stop_apply_filters = true;
      Ui_page.start_map_animation();
    }
    // карта
    Ui_page.insert_ans_show_house_markers(true);
    // графики
    Ui_page.update_charts();
    // таблица
    Ui_page.preparing_to_create_a_table(false);
  }
  // загружаем данные
  async load_data(){
    var data = await Request.request_for_json('/new_buildings/api/get_data');
    this.data = JSON.parse(data['data']);
    this.last_month = Number(this.data[0][this.data_names['apartments_cost']][0]) || 1;
    Event_vars.sector4_chart2_data_month = this.last_month;
    this.filtered_data = clone_array(this.data);
    this.filtered_data_indexes = range(0, this.filtered_data.length - 1);
  }
  // вычислить сумму по приросту
  calculate_sum_from_growth(data){
    var processed_data = create_array_true(data.length, 0);
    var sum = 0;
    data.forEach(function(item, index, array){
      sum += item;
      processed_data[index] += sum;
    });
    return processed_data;
  }
  // преобразовать отфильтрованную дату в нормальную форму для таблицы
  convert_filtered_date_to_normal_form_for_table(data){
    if (Data_vars.liter_or_build == 'liter'){
      var data_new = [];
      data.forEach(function(object, index, array){
        var object = clone_array(object);
        var floors = object[Data_vars.data_names['floors']];
        var coordinates = object[Data_vars.data_names['coordinates']];
        var site = object[Data_vars.data_names['site']];
        // переделываем
        object[Data_vars.data_names['floors']] = floors[1];
        object[Data_vars.data_names['coordinates']] = `${coordinates[0]}, ${coordinates[1]}`;
        if (site != 'Не определено'){object[Data_vars.data_names['site']] = `<a target=_blank href='${site}' rel="noopener">${site}</a>`;}
        object[Data_vars.data_names['phone']] = object[Data_vars.data_names['phone']].split(',').join(', ');
        object[Data_vars.data_names['apartments_cost']] = `<span onmouseenter='Ui_page.show_a_cost(${index});' onmouseleave='clearTimeout(Event_vars.window_cost_is_open_timer);' c_index='${index}'>- Показать -</span>`;
        Data_vars.sector5_table_rate.forEach(function(key){
          var procent = Math.round(object[Data_vars.data_names[key]] * 100);
          object[Data_vars.data_names[key]] = `${procent} %<div style='width:calc((100% - 45px) / 100 * ${procent});'></div>`;
        });
        object.splice(Data_vars.data_names['erz_id'], 1);
        data_new.push(object);
      });
      return data_new;
    }
    else if (Data_vars.liter_or_build == 'build'){
      // собираем в списки новостроек их литеры
      var new_buildings = {};
      data.forEach((object, i) => {
        var key = object[Data_vars.data_names['erz_id']];
        (key in new_buildings) ? new_buildings[key].push([i, object]) : new_buildings[key] = [[i, object]];
      });
      Data_vars.filtered_data_table_build_indexes = [];
      // для каждой новостройки суммируем параметры литеров
      var data_new = [];
      for (var erz_id in new_buildings){
        var liters = new_buildings[erz_id].map(x => x[1]);
        Data_vars.filtered_data_table_build_indexes.push(new_buildings[erz_id].map(x => x[0]));
        var new_build = create_array_true(Data_vars.data_names_list.length, '');
        // --- переделываем
        // 1. индексы класности
        Data_vars.sector5_table_rate.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          var indexes = liters.map(x => x[index]);
          var procent = Math.round(average(indexes) * 100);
          new_build[index] = `${procent} %<div style='width:calc((100% - 45px) / 100 * ${procent});'></div>`;
        });
        // 2. стоимость квартир
        var apartments_cost = liters.map(x => x[Data_vars.data_names['apartments_cost']][1][Data_vars.last_month]);
        var result_cost = [];
        range(0, 4).forEach((item, i) => {
          var flat_object = [];
          var flat_apartments = apartments_cost.map(x => x[item]);
          var func_array = [sum, min, average, max, min, average, max, min, average, max];
          var quantities = flat_apartments.map(x => x[0]);
          var summ_quantity = sum(quantities);
          func_array.forEach((func, i) => {
            if ([2, 5, 8].includes(i)){
              var result = (summ_quantity != 0) ? sum(flat_apartments.map((x, index) => (x.length > i) ? (x[i] * quantities[index]) : 0)) / summ_quantity : 0;
            }else{
              var result = func(delete_certain_els(flat_apartments.map(x => (x.length > i) ? x[i] : 0), 0, true));
            }
            flat_object.push(result);
          });
          result_cost.push(flat_object);
        });
        Data_vars.build_cost_apartments_data[erz_id] = {'global_name': liters[0][Data_vars.data_names['global_name']], 'cost': result_cost};
        new_build[Data_vars.data_names['apartments_cost']] = `<span onmouseenter='Ui_page.show_a_cost(${erz_id});' onmouseleave='clearTimeout(Event_vars.window_cost_is_open_timer);' c_index='${erz_id}'>- Показать -</span>`;
        // 3. переделываем этажи
        new_build[Data_vars.data_names['floors']] = max(liters.map(x => x[Data_vars.data_names['floors']][1]));
        // 4. суммируем определённые столбцы
        Data_vars.array_of_sum_in_build.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          new_build[index] = sum(liters.map(x => +x[index]));
        });
        // 5. оставшиеся столбцы перечисляем через запятую
        Data_vars.array_of_comma_in_build.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          if (item == 'phone'){
            new_build[index] = [...new Set(liters.map(x => x[index]).reduce((a, b) => a.concat(b.split(',')), []))].join(', ');
          }
          else{
            new_build[index] = [...new Set(liters.map(x => x[index]))].join(';   ');
          }
        });
        new_build.splice(Data_vars.data_names['erz_id'], 1);
        // 6. меняем столбцы с именами
        [new_build[Data_vars.data_names['name']], new_build[Data_vars.data_names['global_name']]] = [new_build[Data_vars.data_names['global_name']], new_build[Data_vars.data_names['name']]];
        // --- сохраняем
        data_new.push(new_build);
      }
      return data_new;
    }
  }
  // объединить массив и индексы
  concate_array_and_indexes(data, indexes){
    data.forEach(function(item, index, array){
      item.push(indexes[index]);
    });
    return data;
  }
  // разъединить массив и индексы
  delete_array_and_indexes(data){
    var indexes = [];
    data.forEach(function(item, index, array){
      var this_index = item.pop();
      indexes.push(this_index);
    });
    return [data, indexes];
  }
  // обёртка для функции загрузки excel
  async wrapper_excel_download(func){
    if (Data_vars.excel_librari_is_load){
      func();
    }else{
      dhtmlLoadScript('/static/js/xlsx/exceljs.js', function(){
        dhtmlLoadScript('/static/js/xlsx/file_saver.js', function(){
          Data_vars.excel_librari_is_load = true;
          func();
        });
      });
    }
  }
  // проверка правильности email
  check_right_email(text){
    if (text.trim() == ''){ return [false, 'Поле не должно быть пустым']; }
    if (text.trim().split(' ').length > 1){ return [false, 'В этом поле не может быть пробелов']; }
    if (!text.includes('@')){ return [false, 'Нет символа @']; }
    var listic = text.split('@');
    if (listic.length != 2){ return [false, 'Знаков @ больше одного']; }
    var name = listic[0]; var server = listic[1];
    if (name.trim() == ''){ return [false, 'Нет логина почты']; }
    if (server.trim() == ''){ return [false, 'Нет домена почты']; }
    if (!server.includes('.')){ return [false, 'Нет доменного разделения']; }
    var name_server = server.split('.')[0]; var com_server = server.split('.')[1];
    if (name_server.trim() == ''){ return [false, 'Нет названия сервера почты']; }
    if (com_server.trim() == ''){ return [false, 'Нет букв после точки']; }
    return [true, 'All is ok'];
  }
}

// класс переменных событий
class Event_vars_class{
  constructor(){
    // шапка
    this.header = $('header');
    this.header_main_links = this.header.find('.header-main_links_container');
    this.header_main_links_scroll = this.header.find('.header-main_links_container-scroll');
    // sector 1
    this.sector1 = $('#sector1');
    // сектор 2
    this.sector2 = $('#sector2');
    this.sector2_block1_toggle = {'pressed': [false * 6], 'numbers': {0: 37, 1: 307, 2: 37, 3: 307, 4: 37, 5: 307}, 'limits': [clone(data_summary['year']), clone(data_summary['floors']), clone(data_summary['q_a'])]};
    // сектор 3
    this.sector3 = $('#sector3');
    this.animation_started = false;
    this.animation_stopped = false;
    this.animation_time_wait = 1000;
    this.animation_time_wait_change = false;
    this.open_params_window = false;
    this.open_params_window_timer = true;
    // сектор 4
    this.sector4 = $('#sector4');
    this.sector4_filter_window_open = [false, false];
    this.sector4_filter_toggle_pressed = [false, false];
    this.sector4_data_q_or_s = 1;
    this.sector4_data_rooms = [0];
    this.sector4_chart2_data_index = 0;
    this.sector4_chart2_data_month = undefined;
    // сектор 5
    this.sector5 = $('#sector5');
    this.change_width_column = undefined;
    this.window_change_hp_open = false;
    this.window_cost_is_open_timer = undefined;
    this.window_cost_display_timer = undefined;
    this.window_cost_is_open = [false, undefined, undefined];
    this.window_cost_data_index = 0;
    // низ
    this.footer = $('footer');
  }
}


// класс обработки дизайна страницы
class Ui_page_class{
  // ------------------------------------- ШАПКА
  // убираем, показываем стрелку
  async show_or_hide_arrow(act, element){
    if (act == 'hide'){
      element.css({'cursor': 'default', 'pointer-events': 'none'});
      element.find('img').css({'display': 'none'});
    }
    else{
      element.css({'cursor': 'pointer', 'pointer-events': 'auto'});
      element.find('img').css({'display': 'inline'});
    }
  }
  // вставляем верхнее меню
  async insert_the_top_menu(){
    var item_checked_main = 1;
    var main_links = [['Жилищный фонд', '/housing_stock'], ['Новостройки', '/new_buildings'], ['Квартиры в продажу', '/housing_stock'], ['Аналитика рынка', '/housing_stock'], ['Эл. риэлтор', '/housing_stock'], ['Новости рынка', '/housing_stock'], ['Обществ. мнение', '/housing_stock']];
    var line_result = '';
    main_links.forEach(function(values, index, array){
      var title = values[0]; var link = values[1]; if (item_checked_main == index){var line_checked = 1}else{var line_checked = 0;};
      if (line_checked == 1){var line_color = 'var(--blue_main)';}else{var line_color = 'white';}
      var line = `<div class='header-main_links_container-scroll-item_container' style='margin-left: ${182 * index + 15 * index}px; margin-top: ${-63 * Math.min(index, 1)}px;' onclick="window.location.replace('${link}');" title='${title}'> <button class='header-main_links_container-scroll-item_button'>${shorten_title(title, 14)}</button> <div style='background: ${line_color};' class='header-main_links_container-scroll-item_line'></div> </div>`;
      line_result += line;
    });
    Event_vars.header_main_links_scroll.append(line_result);
    this.header_main_links_scroll_width = 182 * main_links.length + 15 * (main_links.length - 1);
    // устанавливаем открытую область на главный объект
    var width1 = parseFloat(Event_vars.header_main_links.css('width')); var width2 = this.header_main_links_scroll_width;
    if (width1 >= width2){
      Event_vars.header_main_links_scroll.css({'margin-left': 0});
      var element = Event_vars.header.find(`[data_number=1]`);
      Ui_page.show_or_hide_arrow('hide', element);
      var element = Event_vars.header.find(`[data_number=2]`);
      Ui_page.show_or_hide_arrow('hide', element);
    }
    else{
      if (item_checked_main == 0){ var new_margin_left = 0;  }
      else if (item_checked_main == main_links.length - 1){ var new_margin_left = width2 - width1;  }
      else if (item_checked_main < main_links.length / 2){ var new_margin_left = Math.max(0, (182 + 15) * (item_checked_main - 1)); }
      else if (item_checked_main >= main_links.length / 2){ var new_margin_left = Math.min((182 + 15) * (item_checked_main - 2), width2 - width1); }
      else{ var new_margin_left = 0; }
      Event_vars.header_main_links_scroll.css({'margin-left': -new_margin_left});
      if (new_margin_left == 0){ var acting = true; var data_number = 1; var act = 'hide';}
      if (new_margin_left == width2 - width1){ var acting = true; var data_number = 2; var act = 'hide';}
      if (acting){
        var element = Event_vars.header.find(`[data_number="${data_number}"]`);
        Ui_page.show_or_hide_arrow(act, element);
      }
    }
  }
  // убирать или не убирать стрелки
  async clean_up_or_not_arrows(width1, width2, new_margin_left){
    // 1
    if (new_margin_left == width1 - width2){var data_number = 2; var act = 'hide';}else{var data_number = 2; var act = 'show';}
    var element = Event_vars.header.find(`[data_number="${data_number}"]`);
    Ui_page.show_or_hide_arrow(act, element);
    // 2
    if (new_margin_left == 0){var data_number = 1; var act = 'hide';}else{var data_number = 1; var act = 'show';}
    var element = Event_vars.header.find(`[data_number="${data_number}"]`);
    Ui_page.show_or_hide_arrow(act, element);
  }
  // передвигаем верхнее меню
  async move_the_top_menu(bool){
    var width1 = parseFloat(Event_vars.header_main_links.css('width')); var width2 = this.header_main_links_scroll_width; var margin_left = parseFloat(Event_vars.header_main_links_scroll.css('margin-left'));
    if (bool == 1){
      var new_margin_left = Math.max(Math.min(0, width1 - width2), margin_left - (182 + 15) * 3);
      Event_vars.header_main_links_scroll.css({'margin-left': new_margin_left});
      // показываем или скрываем стрелку
      Ui_page.clean_up_or_not_arrows(width1, width2, new_margin_left);
    }else{
      var new_margin_left = Math.min(0, margin_left + (182 + 15) * 3);
      Event_vars.header_main_links_scroll.css({'margin-left': new_margin_left});
      // показываем или скрываем стрелку
      Ui_page.clean_up_or_not_arrows(width1, width2, new_margin_left);
    }
  }
  // ---------------------------------- СЕКТОР 2
  // создать фильтры
  async insert_filters_the_sector2(){
    // первый блок
    var line_result_1 = '';
    Data_vars.sector2_items_array_block_1.forEach(function(values, index, array){
      var title = values[0]; var numbers = values[1];
      var line = `
        <div class='sector2-block-1-item' style='margin-left: ${(344 + 44) * index}px;'>
          <div class='sector2-block-1-item-title'>${title}</div>
          <div class='sector2-block-1-item-line' id='sector1-line_toggle${index}'></div>
          <div class='sector2-block-1-item-limit sector2-block-1-item-limit1'>${numbers[0]}</div>
          <div class='sector2-block-1-item-limit sector2-block-1-item-limit2'>${numbers[1]}</div>
          <div class='sector2-block-1-item-toggle_container' id='sector1-toggle${index * 2}' style='margin-left: 37px;'>
            <div class='sector2-block-1-item-toggle_container-toggle'></div>
            <button class='sector2-block-1-item-toggle_container-text'>${numbers[0]}</button>
          </div>
          <div class='sector2-block-1-item-toggle_container' id='sector1-toggle${index * 2 + 1}' style='margin-left: 307px;'>
            <div class='sector2-block-1-item-toggle_container-toggle'></div>
            <button class='sector2-block-1-item-toggle_container-text'>${numbers[1]}</button>
          </div>
        </div>`;
      line_result_1 += line;
    });
    Event_vars.sector2.find('.sector2-block-1').html(line_result_1);
    // второй блок
    var line_result_2 = '';
    var margin_left = 0;
    Data_vars.sector2_items_array_block_2.forEach(function(values, index, array){
      var title = values[0]; var values_of_select = values[1]; var width_item = values[2];
      var line = `
        <div class='sector2-block-2-item' id='sector2_block_2_item_${index}' style='margin-left: ${margin_left}px; width: ${width_item}px;'>
          <div class='sector2-block-2-item-title'>${title}</div>
          <div class='sector2-block-2-item-open_select_button_div' onclick='Ui_page.show_or_hide_filter_values(${index});'>
            <button class='sector2-block-2-item-open_select_button'>${values_of_select[0]}</button>
            <img class='sector2-block-2-item-select_arrow' src='/static/img/housing_stock/sector2_select_arrow.png' ondragstart="return false;">
          </div>
        </div>`;
      line_result_2 += line;
      margin_left += (width_item + 48);
    });
    Event_vars.sector2.find('.sector2-block-2').html(line_result_2);
    Event_vars.sector2_block_2_container_input = Event_vars.sector2.find('.sector2-block-2-item-open_select_button_div');
  }
  // убрать или поставить галочки на фильтры по массиву
  async tick_off_filters(array){
    var container = $('.sector2-block-2-item-filters_container');
    array.forEach(function(bool, index_item, array){
      if (bool){ var color = '#EFEFEF'; }else{ var color = 'white'; }
      var el = container.find(`#sector2_filter${index_item}`);
      el.find('input').prop('checked', bool);
      el.find('button').css({'background': color});
    });
  }
  // показать или скрыть фильтры
  async show_or_hide_filter_values(index){
    // проверка по открытому сейчас фильтру
    if (Data_vars.sector2_open_filter == index){
      Event_vars.sector2_filters_container.remove();
      Data_vars.sector2_open_filter = undefined;
      Event_vars.sector2.find(`#sector2_block_2_item_${index}`).find('.sector2-block-2-item-select_arrow').css({'transform': 'rotate(0deg)'});
      return false;
    }
    else if (Data_vars.sector2_open_filter != undefined){
      Event_vars.sector2_filters_container.remove();
      Event_vars.sector2.find(`#sector2_block_2_item_${Data_vars.sector2_open_filter}`).find('.sector2-block-2-item-select_arrow').css({'transform': 'rotate(0deg)'});
    }
    Data_vars.sector2_open_filter = index;
    // создаём элементы
    var container = Event_vars.sector2.find(`#sector2_block_2_item_${index}`);
    container.find('img').css({'transform': 'rotate(180deg)'});
    var values = Data_vars.sector2_items_array_block_2[index][1];
    var line_header = `<div class='sector2-block-2-item-filters_container' id='sector2_filters_container${index}' style='height: ${values.length * 30 + 1}px;'>`;
    var line_in = '';
    values.forEach(function(value, index_item, array){
      if (index_item == 0){ var line_border = 'border-bottom: 1px var(--black_main) dashed;'; }else{ var line_border = ''; }
      if (Data_vars.sector2_items_array_block_2[index][3][index_item] == true){ var color = '#EFEFEF'; var checked = 'checked'; }else{ var color = 'white'; var checked = ''; }
      line_in += `
        <div id='sector2_filter${index_item}' style='margin-top: ${index_item * 30 + Math.min(index_item, 1)}px;${line_border}'>
          <input type='checkbox' ${checked}>
          <button style='background: ${color};'>${value}</button>
        </div>
      `;
    });
    container.append(line_header + line_in + '</div>');
    Event_vars.sector2_filters_container = Event_vars.sector2.find('.sector2-block-2-item-filters_container');
    Data_vars.sector2_filter_checked = [true * values.length];
    Event_vars.sector2_filters_container.find('input').on('change', function(){
      var el = $(this);
      var filter_container = el.parent();
      var index = Number(filter_container.attr('id').split('sector2_filter')[1]);
      var index_main = Number(filter_container.parent().attr('id').split('sector2_filters_container')[1]);
      if (this.checked){
        if (index == 0){ Data_vars.sector2_items_array_block_2[index_main][3] = create_array_true(Data_vars.sector2_items_array_block_2[index_main][1].length, true); }
        else{
          Data_vars.sector2_items_array_block_2[index_main][3][index] = true;
          if (!Data_vars.sector2_items_array_block_2[index_main][3].includes(false, 1)){ Data_vars.sector2_items_array_block_2[index_main][3][0] = true; }
        }
      }
      else{
        if (index == 0){ Data_vars.sector2_items_array_block_2[index_main][3] = create_array_true(Data_vars.sector2_items_array_block_2[index_main][1].length, false); }
        else{
          Data_vars.sector2_items_array_block_2[index_main][3][index] = false;
          Data_vars.sector2_items_array_block_2[index_main][3][0] = false;
        }
      }
      Ui_page.tick_off_filters(Data_vars.sector2_items_array_block_2[index_main][3]);
      // вставляем текст в превью
      var button = $(`#sector2_block_2_item_${index_main}`).find('.sector2-block-2-item-open_select_button');
      var quantity_true = count(Data_vars.sector2_items_array_block_2[index_main][3], 1, true);
      if (quantity_true == 1){ var button_text = shorten_title(Data_vars.sector2_items_array_block_2[index_main][1][Data_vars.sector2_items_array_block_2[index_main][3].indexOf(true)], 11); }
      else if (quantity_true < Data_vars.sector2_items_array_block_2[index_main][1].length - 1){ var button_text = `${quantity_true} из ${Data_vars.sector2_items_array_block_2[index_main][1].length - 1} ${Data_vars.sector2_items_array_block_2[index_main][4]}`; }
      else { var button_text = Data_vars.sector2_items_array_block_2[index_main][1][0]; }
      button.html(button_text);
      // обновляем
      setTimeout(Data_vars.apply_filters, 1);
    });
  }
  // ---------------------------------- СЕКТОР 3
  // вставить карту
  async insert_map_the_sector3(){
    Data_vars.map_themes = ['https://mt0.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', 'https://tile2.maps.2gis.com/tiles?x={x}&y={y}&z={z}'];
    // ссылка темы
    var tiles = L.tileLayer(Data_vars.map_themes[0], {maxZoom: 18, attribution: 'maphouse.ru'});
    Data_vars.theme_map = 'default';
    Data_vars.map_tiles = tiles;
    // смена темы в параметрах
    Data_vars.theme_map_params = 0;
    // центр
    var latlng = L.latLng(54.7524, 55.9958);
    // создаём иконку дома
    var icon_default = L.icon({
      iconUrl: '/static/img/new_buildings/new_build.png',
      iconSize: [34, 28],
      iconAnchor: [parseInt(34 / 2), parseInt(28 / 2)],
      popupAnchor: [0, -parseInt(28 / 2)]
    });
    Data_vars.map_icon = icon_default;
    var map_highlight_area_icon = L.icon({
      iconUrl: '/static/img/housing_stock/highlight_area_marker_icon.svg',
      iconSize: [20, 20],
      iconAnchor: [parseInt(20 / 2), parseInt(20 / 2)],
      popupAnchor: [0, -(20)]
    });
    var map_highlight_area_icon_onmouse = L.icon({
      iconUrl: '/static/img/housing_stock/highlight_area_marker_icon.svg',
      iconSize: [24, 24],
      iconAnchor: [parseInt(24 / 2), parseInt(24 / 2)],
      popupAnchor: [0, -(24)]
    });
    Data_vars.map_highlight_area_icon = map_highlight_area_icon;
    Data_vars.map_highlight_area_icon_onmouse = map_highlight_area_icon_onmouse;
    // создаём карту
    var map = L.map('map', {center: latlng,
                            zoom: 12,
                            layers: [tiles],
                            zoomDelta: 0.5,
                            zoomSnap: 0,
                            wheelPxPerZoomLevel: 70});
    Data_vars.map = map;

    // scale map
    L.control.scale({imperial: false}).addTo(map);

    // controls zoom, scale
    $('.leaflet-control').css({'border': 'none', 'transition': 'margin-left 0.3s'});
    $('.leaflet-control-zoom-in').css({'border-radius': '50%', 'width': 38, 'height': 34, 'overflow': 'hidden', 'box-shadow': '0px 6px 18px rgba(0, 0, 0, 0.3)', 'padding-top': 4, 'user-select': 'none'});
    $('.leaflet-control-zoom-out').css({'border-radius': '50%', 'width': 38, 'height': 34, 'overflow': 'hidden', 'box-shadow': '0px 6px 18px rgba(0, 0, 0, 0.3)', 'padding-top': 4, 'user-select': 'none', 'margin-top': 8});
    $('.leaflet-control-scale-line').css({'margin-left': 8, 'background': '#44535e', 'border': '2px white solid', 'color': 'white', 'box-shadow': '0px 0px 5px #44535e', 'opacity': '0.8'});
    $('.leaflet-control-attribution').remove();
    // создаём группы объектов
    // районы на карте
    Data_vars.districts_polygons = L.layerGroup();
    Data_vars.districts_polygons.addTo(map);
    // дома на карте
    var house_markers = L.markerClusterGroup();
    Data_vars.house_markers = house_markers;
    // точки, при выделении области на карте
    var highlight_area_markers = L.layerGroup();
    Data_vars.light_area.markers = highlight_area_markers;
    Data_vars.light_area.markers.addTo(map);
    // кружочки домов при анимации
    var house_animation_rects = L.layerGroup();
    Data_vars.house_animation_rects = house_animation_rects;
  }
  // меняем тему карты
  async change_theme_map(){
    Data_vars.map_tiles.removeFrom(Data_vars.map);
    var button_year_animation = Event_vars.sector3.find('.map-animation-year').find('div');
    if (Data_vars.theme_map == 'default'){
      Data_vars.theme_map = 'satellite';
      var new_map_theme = 'http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      var new_map_theme_img = '/static/img/housing_stock/map_theme_default.png';
      button_year_animation.css({'background': 'var(--green_light)'});
    }
    else if (Data_vars.theme_map == 'satellite'){
      Data_vars.theme_map = 'default';
      var new_map_theme = Data_vars.map_themes[Data_vars.theme_map_params];
      var new_map_theme_img = '/static/img/housing_stock/map_theme_satellite.png';
      button_year_animation.css({'background': 'var(--purple_main)'});
    }
    var new_tiles = L.tileLayer(new_map_theme, {attribution: "maphouse.ru", maxZoom: 18}).addTo(Data_vars.map);
    Data_vars.map_tiles = new_tiles;
    Event_vars.sector3.find('.map-theme-switcher-img').attr('src', new_map_theme_img);
  }
  // меняем тему карты (google, 2gis)
  async change_theme_map_params(){
    if (Data_vars.theme_map == 'satellite'){
      Data_vars.theme_map = 'default';
      var new_map_theme_img = '/static/img/housing_stock/map_theme_satellite.png';
      Event_vars.sector3.find('.map-theme-switcher-img').attr('src', new_map_theme_img);
      var button_year_animation = Event_vars.sector3.find('.map-animation-year').find('div');
      button_year_animation.css({'background': 'var(--purple_main)'});
    }
    Data_vars.map_tiles.removeFrom(Data_vars.map);
    var circle = Event_vars.sector3.find('.map_theme_switcher_2').find('div[dn="white_circle"]');
    var imgs = Event_vars.sector3.find('.map_theme_switcher_2').find('img');
    if (Data_vars.theme_map_params == 0){
      Data_vars.theme_map_params = 1;
      circle.css({'margin-left': 45});
      imgs.eq(0).attr('src', '/static/img/housing_stock/google_black.png');
      imgs.eq(1).attr('src', '/static/img/housing_stock/2gis_color.png');
    }
    else{
      Data_vars.theme_map_params = 0;
      circle.css({'margin-left': 0});
      imgs.eq(0).attr('src', '/static/img/housing_stock/google_color.png');
      imgs.eq(1).attr('src', '/static/img/housing_stock/2gis_black.png');
    }
    var new_tiles = L.tileLayer(Data_vars.map_themes[Data_vars.theme_map_params], {attribution: "maphouse.ru", maxZoom: 18}).addTo(Data_vars.map);
    Data_vars.map_tiles = new_tiles;
  }
  // открываем таблицу при карте
  async sector3_open_window_inf(index_in_data){
    var item = Data_vars.data[index_in_data];
    var container = Event_vars.sector3.find('.sector3-window_inf');
    container.find('div[dn="adress"]').html(item[0]);
    // показываем
    container.css({'margin-left': 0});
    $('.leaflet-control').css({'margin-left': 290});
    // вставляем значения
    var lines_table = '';
    for (var i=1; i<item.length; i++){
      var value = item[i];
      if (i == Data_vars.data_names['floors']){ var value = value[1]; }
      else if (i == Data_vars.data_names['apartments_cost']){ var value = `<div class='sector3-window_inf-cost' onmouseenter="Ui_page.show_a_cost(${index_in_data}, true, true);" onmouseleave="clearTimeout(Event_vars.window_cost_is_open_timer);">- Показать -</div>`; }
      else if (i == Data_vars.data_names['erz_id']){ var value = item[i + 1]; }
      else if (i == Data_vars.data_names['coordinates']){ break; }
      lines_table += `<tr><td>${Data_vars.sector5_names_of_columns[i]}</td><td>${value}</td></tr>`;
    }
    container.find('table').html(lines_table);
  }
  // скрываем окно при карте
  async sector3_close_window_inf(){
    var container = Event_vars.sector3.find('.sector3-window_inf');
    container.css({'margin-left': -277});
    $('.leaflet-control').css({'margin-left': 10});
  }
  // создать текст для маркера
  create_marker_text(object, index_in_data){
    // рассчитываем
    var floors = object[Data_vars.data_names['floors']];
    if (floors[0] == floors[1]){ var floors_str = floors[1]; }
    else{ var floors_str = `от ${floors[0]} до ${floors[1]}`; }
    var name = shorten_title(object[Data_vars.data_names['name']], 20);
    var cond_class = object[Data_vars.data_names['conditional_class']];
    var quantity_apart = object[Data_vars.data_names['number_apartments_project']];
    var maphouse_index = object[Data_vars.data_names['cumulative_rating']];
    var object_readiness = object[Data_vars.data_names['object_readiness']];
    if (object_readiness == 'Сдан'){ var object_readiness = ['Сдан', '#088A85']; }
    else if (object_readiness == 'Строится'){ var object_readiness = ['Строится', '#FE9A2E']; }
    else{ var object_readiness = ['Остановлено', '#FF3D67']; }
    var procent = (object_readiness[0] == 'Сдан') ? 1.0 : get_date_procent(object[Data_vars.data_names['start_date']], object[Data_vars.data_names['deadline']]);
    var polygon = get_clip_polygon(procent);
    var proc_number = Math.floor(procent * 100);
    if (proc_number < 100){
      var proc_line = [`<button>${proc_number}%</button>`, 'var(--purple_other)'];
    }else{
      var proc_line = [`<span></span>`, 'rgba(0, 0, 0, 0.07)'];
    }
    var values_array = [['Класс:', cond_class], ['Этажей:', floors_str], ['Квартир:', quantity_apart]];
    var values_lines = values_array.map(x => `<div dn='c'><span>${x[0]}</span><span style='color: var(--purple_other); white-space: nowrap;'>${x[1]}</span></div>`).join('');
    // текст маркера
    var marker_window = `
      <div class='map_marker_window'>
        <div dn='title'>${name}</div>
        <div style='margin-top: -22px;'> <button dn='short_readness' style='background: ${object_readiness[1]};'>${object_readiness[0]}</button> </div>
        <div class='map_marker_window-readness_container'>
          <div dn='path' style='clip-path: polygon(${polygon}); background: ${proc_line[1]};'></div>
          <div dn='procent_container'>${proc_line[0]}</div>
        </div>
        <div class='map_marker_window-values'>
          ${values_lines}
          <div class='map_marker_window-open_window' onclick='Ui_page.sector3_open_window_inf(${index_in_data});'>Показать все данные 🠖</div>
        </div>
        <div class='map_marker_window-rating'>
          <img src='/static/img/new_buildings/rating.svg'>
          <span>Рейтинг объекта:</span>
          <span style='font-family: Intro, sans-serif; font-size: 10px;'>${Math.floor(maphouse_index * 100)}%</span>
          <span dn='line'><div dn='line_in' style='width: ${Math.floor(maphouse_index * 270)}px;'></div></span>
        </div>
      </div>
    `;
    return marker_window;
  }
  // создать маркеры для массива
  async create_markers_to_array(data, add=true, indexes_in_data=[]){
    var markers = [];
    // проходимся по данным и создаём маркеры
    data.forEach(function(object, index, array){
      // если есть картинка, то одно изображение, если нет, то другое
      var marker_window = Ui_page.create_marker_text(object, indexes_in_data[index]);
      // создаём иконку картинки
      var image_icon = L.divIcon({html: `<div class='map_marker_image'><img src='/static/media/new_buildings/img/${data_summary['min_pk'] + Data_vars.filtered_data_indexes[index]}.png' loading="lazy"></div>`});
      // создаём маркер и добавляем в общий список
      var marker = L.marker(object[Data_vars.data_names['coordinates']], {icon: image_icon});
      marker.bindPopup(marker_window);
      // обработчики событий курсора
      marker.on('mouseover', function(){
        var marker_event = this;
        var popup_container = marker_event._popup._container;
        clearTimeout(marker_event._hide_timer);
        marker_event.openPopup();
        $(popup_container).mouseenter(function(){ clearTimeout(marker_event._hide_timer);
        }).mouseleave(function(){ marker_event._hide_timer = setTimeout(function(){marker_event.closePopup();}, 300); });
      });
      // === >>>
      marker.on('mouseout', function(){
        var marker_event = this;
        var popup_container = marker_event._popup._container;
        this._hide_timer = setTimeout(function(){ marker_event.closePopup(); }, 300);
        $(popup_container).mouseenter(function(){ clearTimeout(marker_event._hide_timer);
        }).mouseleave(function(){ marker_event._hide_timer = setTimeout(function(){marker_event.closePopup();}, 300); });
      });
      // добавляем в общий список маркеров
      if (add){ Data_vars.house_markers.addLayer(marker); }else{ markers.push(marker); }
    });
    if (!add){ return markers; }else{ return; }
  }
  // вставляем и показываем метки домов
  async insert_ans_show_house_markers(clear=false){
    if (clear){
      await Data_vars.house_markers.removeFrom(Data_vars.map);
      await Data_vars.house_markers.clearLayers();
    }
    // создаём маркеры
    await Ui_page.create_markers_to_array(Data_vars.filtered_data, true, Data_vars.filtered_data_indexes);
    if (Data_vars.load_circle_exists_sector3){
      Event_vars.sector3.find('.load_circle').remove();
      Data_vars.load_circle_exists_sector3 = false;
    }
    Data_vars.map.addLayer(Data_vars.house_markers);
  }
  // выделить обавть на карте (как отдельный фильтр)
  async highlight_area(){
    var func = async function(){
      Data_vars.map_lib_is_load = true;
      Data_vars.light_area.open = true;
      Ui_page.districts_is_interactive(false);
      // меняем текст на кнопке
      var button = Event_vars.sector3.find('.map-window_buttons-button').eq(1);
      button.html('Убрать выделение');
      button.attr('onclick', `Ui_page.clear_highlight_area();`);
      // ставим обработчик на движение мыши на карте
      Data_vars.map.on("mousemove", function(event){
        // ------------ перерисовываем линию
        if (Data_vars.light_area.open == false || Data_vars.light_area.last_point[0] == undefined){ return; }
        var lat = event.latlng.lat; var lng = event.latlng.lng;
        // если это не первая линия, то предыдущую удаляем
        if (Data_vars.light_area.line == undefined){
          Data_vars.light_area.line = L.polyline([Data_vars.light_area.last_point, [lat, lng]], {color: '#848484', interactive: false}).addTo(Data_vars.map);
        }
        else{
          Data_vars.light_area.line.setLatLngs([Data_vars.light_area.last_point, [lat, lng]]);
          Data_vars.light_area.line.redraw();
        }
      });
      Data_vars.map.on("click", function(event){
        // ---------- рисуем главную ломаную линию и ставим маркеры
        if (Data_vars.light_area.open == false){ return; }
        var lat = event.latlng.lat; var lng = event.latlng.lng;
        // рисуем линию, между предыдущей точкой и новой
        if (Data_vars.light_area.last_point[0] != undefined){
          if (Data_vars.light_area.polyline == undefined){
            Data_vars.light_area.polyline = L.polyline([Data_vars.light_area.last_point, [lat, lng]], {color: '#848484', interactive: false}).addTo(Data_vars.map);
          }
          else{
            Data_vars.light_area.polyline.addLatLng([lat, lng]);
          }
        }
        // рисуем новую точку
        var marker = L.marker([lat, lng], {icon: Data_vars.map_highlight_area_icon, draggable: false});
        marker.bindPopup('');
        // ставим обработчики
        marker.on('mouseover', function(){ this.setIcon(Data_vars.map_highlight_area_icon_onmouse);
        }).on('mouseout', function(){ this.setIcon(Data_vars.map_highlight_area_icon);
        }).on('click', function(){ this.closePopup(); });
        // если он первый, то при нажатии на него выделение прекращается
        if (Data_vars.light_area.last_point[0] == undefined){
          marker.on('click', function(){
            this.closePopup();
            Data_vars.light_area.open = false;
            Ui_page.districts_is_interactive(true);
            try{Data_vars.light_area.line.removeFrom(Data_vars.map);}catch{}
            Data_vars.light_area.line = undefined;
            Data_vars.light_area.polyline.addLatLng([this.getLatLng().lat, this.getLatLng().lng]);
            Data_vars.light_area.array_limits = Ui_page.find_limits_rectangle_of_coordinates(Data_vars.light_area.coord_array);
            Data_vars.light_area.on = true;
            Ui_page.highlight_area_step_2();
          });
        }
        Data_vars.light_area.markers.addLayer(marker);
        // переназначаем координаты
        Data_vars.light_area.last_point = [lat, lng];
        Data_vars.light_area.coord_array.push([lat, lng]);
      });
    };
    if (!Data_vars.map_lib_is_load){ dhtmlLoadScript('/static/js/maphouse_library/map_lib.js', function(){ func(); }); }
    else{ func(); }
  }
  // убрать выделение и вернуться обратно
  async clear_highlight_area(){
    Data_vars.map.off("mousemove"); Data_vars.map.off("click");
    if (Data_vars.light_area.polyline != undefined){ Data_vars.light_area.polyline.removeFrom(Data_vars.map); }
    if (Data_vars.light_area.line != undefined){ Data_vars.light_area.line.removeFrom(Data_vars.map); }
    Data_vars.light_area.markers.clearLayers();
    var markers = Data_vars.light_area.markers;
    Data_vars.light_area = {'on': false, 'markers': [], 'polyline': undefined, 'line': undefined, 'last_point': [undefined, undefined], 'start': false, 'coord_array': []};
    Data_vars.light_area.markers = markers;
    var button = Event_vars.sector3.find('.map-window_buttons-button').eq(1);
    button.html('Выделить область');
    button.attr('onclick', `Ui_page.highlight_area();`);
    Data_vars.apply_filters(true);
  }
  // второй шаг выделения (возможность перетаскивать маркеры)
  async highlight_area_step_2(){
    // update filters
    Data_vars.apply_filters();
    var marker_index = 1;
    Data_vars.light_area.markers.eachLayer((marker) => {
      marker.number = marker_index;
      var drag = new L.Draggable(marker.getElement());
      drag.on('predrag', function(event){
        var latlng = Data_vars.map.mouseEventToLatLng(event.originalEvent);
        marker.setLatLng(latlng);
        Data_vars.light_area.coord_array[marker.number-1] = [latlng.lat, latlng.lng];
        Data_vars.light_area.polyline.setLatLngs(Data_vars.light_area.coord_array.concat([Data_vars.light_area.coord_array[0]]));
      }).on('dragend', async function(event){
        marker.setLatLng(Data_vars.light_area.coord_array[marker.number-1]);
        Data_vars.light_area.array_limits = Ui_page.find_limits_rectangle_of_coordinates(Data_vars.light_area.coord_array);
        // update filters
        Data_vars.apply_filters();
      });
      drag.enable();
      marker_index += 1;
    });
  }
  // найти пределы
  find_limits_rectangle_of_coordinates(coord_array){
    var x = [false, false]; var y = [false, false];
    for (var i=0; i<coord_array.length; i++){
      var coord = coord_array[i];
      if (x[0] == false || x[0] > coord[0]){ x[0] = coord[0]; }
      if (x[1] == false || x[1] < coord[0]){ x[1] = coord[0]; }
      if (y[0] == false || y[0] > coord[1]){ y[0] = coord[1]; }
      if (y[1] == false || y[1] < coord[1]){ y[1] = coord[1]; }
    }
    return [x, y];
  }
  // проверить, загружена ли дата
  async check_load_data_district(index){
    if (Data_vars.districts_data[index] == undefined){
      var response = await Request.request_for_json(Data_vars.districts_data_urls[index]);
      if (response.status == 'ok'){
        Data_vars.districts_data[index] = response.data;
        return true;
      }
      else{
        alert('Извините, что-то пошло не так, если проблема останется просим написать нам об этом.');
        return false;
      }
    }
    else{ return true; }
  }
  // сделать районы интерактивными или нет
  async districts_is_interactive(bool){
    if (Data_vars.check_district_map_index == undefined){ return; }
    var polygons = [];
    Data_vars.districts_polygons.eachLayer(function(layer){
      layer.setStyle({interactive: bool});
      polygons.push(layer);
    });
    Data_vars.districts_polygons.clearLayers();
    polygons.forEach((layer, i) => {
      Data_vars.districts_polygons.addLayer(layer);
    });
  }
  // добавить районы на карту
  async push_districts_to_map(index){
    // проходимся и вставляем
    Data_vars.districts_data[index].forEach((item, i) => {
      for (var j=0; j<item.coordinates.length; j++){
        var coordinates = item.coordinates[j];
        if (Data_vars.light_area.open){ var interactive = false; }else{ var interactive = true; }
        var popup = `<div style='font-family: Montserrat_extrabold, sans-serif;'>${item.title}</div>`;
        var polygon = L.polygon(coordinates, {fillOpacity: 0.1, weight: 2, interactive: interactive});
        polygon.bindPopup(popup);
        polygon.on('mouseover', function(){this.setStyle({fillOpacity: 0.25});});
        polygon.on('mouseout', function(){this.setStyle({fillOpacity: 0.1});});
        Data_vars.districts_polygons.addLayer(polygon);
     }
    });
    // добавляем районы на карту
    Data_vars.map.addLayer(Data_vars.districts_polygons);
  }
  // показать районы
  async check_district_map(index){
    // решающее дерево
    if (Data_vars.check_district_map_index == undefined){
      Data_vars.check_district_map_index = index;
      // сначала проверяем наличие данных
      var result = await Ui_page.check_load_data_district(index);
      if (!result){ return; }
      // теперь обрабатываем
      Ui_page.push_districts_to_map(index);
    }
    else{
      await Data_vars.districts_polygons.clearLayers();
      if (Data_vars.check_district_map_index != index){
        Data_vars.check_district_map_index = index;
        // убираем галочку
        Event_vars.sector3.find('.map-params').find('.map_label').eq((index + 1) % 2).find('input').prop('checked', false);
        // сначала проверяем наличие данных
        var result = await Ui_page.check_load_data_district(index);
        if (!result){ return; }
        // теперь обрабатываем
        Ui_page.push_districts_to_map(index);
      }
      else{
        Data_vars.check_district_map_index = undefined;
      }
    }
  }
  // ---------------------------------- СЕКТОР 4
  // показываем или скрываем фильтры диаграмм
  async open_or_close_chart_filter(index){
    var index = Number(index) - 1;
    if (Event_vars.sector4_filter_window_open[index] == false){
      Event_vars.sector4_filter_window_open[index] = true;
      // проверяем на открытие второго селекта
      if (index == 0){ var index_second = 1; }else{ var index_second = 0; }
      if (Event_vars.sector4_filter_window_open[index_second] == true){
        var container_second = Event_vars.sector4.find(`#chart_container_${index_second + 1}`);
        container_second.find('.sector4-chart_container-filter1-select_container').remove();
        container_second.find('.sector4-chart_container-filter1-select').find('img').css({'transform': ''});
        Event_vars.sector4_filter_window_open[index_second] = false;
      }
      // находим контейнер
      var container = Event_vars.sector4.find(`#chart_container_${index + 1}`);
      // создаём
      var margin_left = (index == 0) ? 115 : 100;
      var width = (index == 0) ? 90 : 100;
      var months_order = range(0, 11).map(x => (x + Data_vars.last_month) % 12 + 1).reverse();
      var values_array = (index == 0) ? ['1-кмн.', '2-кмн.', '3-кмн.', '4-кмн.', 'мн-к.'] : months_order.map(x => Data_vars.months[x]);
      var line_header = `<div class='sector4-chart_container-filter1-select_container' style='height: ${Math.min(values_array.length * 22, 200)}px; margin-left: ${margin_left}px; width: ${width}px;'>`;
      var lines_all = '';
      values_array.forEach(function(value, index_item, array){
        if (index == 0){
          if (Event_vars.sector4_data_rooms.includes(index_item)){ var check_mark = '<span></span>'; }else{ var check_mark = ''; }
          var line = `<div class='chart1_check_cont' style='margin-top: ${22 * index_item}px;'><div>${value}</div>${check_mark}</div>`;
        }else{
          var line = `<button style='margin-top: ${index_item * 22}px; width: ${width}px;'>${value}</button>`;
        }
        lines_all += line;
      });
      container.find('.sector4-chart_container-filter1-select').find('img').css({'transform': 'rotate(180deg)'});
      container.append(line_header + lines_all + '</div>');
      // ------- обработчик на нажатие
      // chart 1
      container.find('.sector4-chart_container-filter1-select_container').find('.chart1_check_cont').on('click', function(){
        var el = $(this);
        var index = Number(el.index());
        if (Event_vars.sector4_data_rooms.includes(index)){
          el.find('span').remove();
          Event_vars.sector4_data_rooms.splice(Event_vars.sector4_data_rooms.indexOf(index), 1);
        }else{
          el.append('<span></span>');
          Event_vars.sector4_data_rooms.push(index);
        }
        // сокращаем
        Ui_page.update_charts(1);
      });
      // chart 2
      container.find('.sector4-chart_container-filter1-select_container').find('button').on('click', function(){
        var el = $(this);
        var container = el.parent().parent();
        var month = Number(el.index()); // from 0 to 11
        container.find('.sector4-chart_container-filter1-select').find('button').html(el.html());
        // обновляем
        Event_vars.sector4_chart2_data_month = ((12 - month - 1) + Data_vars.last_month) % 12 + 1;
        Ui_page.update_charts(2);
      });
    }
    else{
      Event_vars.sector4_filter_window_open[index] = false;
      var container = Event_vars.sector4.find(`#chart_container_${index + 1}`);
      // убираем
      container.find('.sector4-chart_container-filter1-select').find('img').css({'transform': ''});
      container.find('.sector4-chart_container-filter1-select_container').remove();
    }
  }
  // меняем "половину графика"
  async change_chart_half(){
    var container = Event_vars.sector4.find(`#chart_container_1`);
    var toggle = container.find('.sector4-chart_container-filter3-line').find('div');
    if (Event_vars.sector4_data_q_or_s == 1){
      toggle.css({'margin-left': 13});
      Event_vars.sector4_data_q_or_s = 2;
    }else{
      toggle.css({'margin-left': -2});
      Event_vars.sector4_data_q_or_s = 1;
    }
    // обновляем
    Ui_page.update_charts(1);
  }
  // создаём графики
  async create_chart_filters(index){
    //
    if (index == 1){
      var el = `
        <div class='sector4-chart_container-filter-text' style='margin-left: 296px;'>Скругление линий</div>
        <div class='sector4-chart_container-filter2-line'></div>
        <div class='sector4-chart_container-filter2-toggle'></div>
        <!-- -->
        <div class='sector4-chart_container-filter3-text' style='margin-left: 40px;'>Кол. кв.</div>
        <div class='sector4-chart_container-filter3-line' onclick='Ui_page.change_chart_half(${index - 1});' style='margin-left: 110px;'>
          <div></div>
        </div>
        <div class='sector4-chart_container-filter3-text' style='margin-left: 150px;'>Площадь</div>
        <!-- -->
        <div class='sector4-chart_container-filter-text' style='margin-left: 40px; margin-top: 358px;'>Комнаты:</div>
        <div class='sector4-chart_container-filter1-select' style='width: 90px; margin-top: 355px; margin-left: 115px;' onclick='Ui_page.open_or_close_chart_filter(${index});'>
          <button style='width: 75px; font-size: 11px;'>выбрать</button>
          <img style='margin-left: 70px;' src='/static/img/housing_stock/sector2_select_arrow.png' ondragstart="return false;" alt='""'>
        </div>
        <!-- -->
        <div class='sector4-chart_container-download' onclick='Ui_page.chart_data_download(${index - 1});'>
          <img src='/static/img/housing_stock/download.png' ondragstart="return false;" alt='""'>
          <div>Скачать таблицу графика</div>
        </div>
      `;
    }else{
      var checkbox_data = [['Стоимость', 0, 'checked'], ['Цена за м²', 124, ''], ['Площадь', 248, ''], ['Количество', 360, '']];
      var checkbox_lines = checkbox_data.map((x, i) => `<div class='wnd_cost_change' style='margin-left: ${x[1]}px;'><label class='cost_label' style='font-family: Montserrat_extrabold, sans-serif;font-size: 13px;'>${x[0]}<input type="checkbox" index='${i}' ${x[2]}><span class='cost_span'></span></label></div>`).join('');
      var el = `
        <div class='sector4-checkbox_container'>${checkbox_lines}</div>
        <!-- -->
        <div class='sector4-chart_container-filter-text' style='margin-left: 40px; margin-top: 358px;'>Месяц:</div>
        <div class='sector4-chart_container-filter1-select' style='width: 100px; margin-top: 355px; margin-left: 100px;' onclick='Ui_page.open_or_close_chart_filter(${index});'>
          <button style='width: 85px;'>март</button>
          <img style='margin-left: 80px;' src='/static/img/housing_stock/sector2_select_arrow.png' ondragstart="return false;" alt='""'>
        </div>
        <!-- -->
        <div class='sector4-chart_container-download' onclick='Ui_page.chart_data_download(${index - 1});'>
          <img src='/static/img/housing_stock/download.png' ondragstart="return false;" alt='""'>
          <div>Скачать таблицу графика</div>
        </div>
      `;
    }
    return el;
  }
  // создать макеты графика
  create_maket_of_line(label, data, color, index){
    //
    // #ffd6df #c8c3e8
    if (index == 2){ var background = 'rgba(255, 61, 103, 0.05)'; }else{ var background = 'rgba(101, 84, 192, 0.2)'; }
    var line = {
        label: label,
        data: data,
        type: 'line',
        pointRadius: 5,
        pointHoverRadius: 6,
        borderWidth: 3,
        pointBorderWidth: 1,
        pointBackgroundColor: color,
        backgroundColor: background,
        borderColor: color,
        order: index,
        fill: true
    };
    return line;
  }
  create_maket_of_bar_2(label, data, color, index, categoryPercentage, maxBarThickness){
    var bar = {
      label: label,
      type: 'bar',
      backgroundColor: color,
      data: data,
      stack: index,
      categoryPercentage: categoryPercentage,
      maxBarThickness: maxBarThickness
    };
    return bar;
  }
  // создать графики
  async create_charts(){
    // ------ график 1
    // создаём макет датасета
    var limits = Data_vars.sector2_items_array_block_1[0][1];
    var labels = range(limits[0], limits[1]);
    var datasets_fiction_data = create_array_true(limits[1] - limits[0] + 1, 0);
    // создаём макет
    Chart.defaults.global.legend.labels.fontFamily = 'Montserrat_extrabold';
    Chart.defaults.global.legend.labels.fontColor = '#848484';
    // --------- график 1
    var canvas_1 = $('#Chart_1');
    var config_1 = {
        type: "bar",
        data: {
          labels: [],
          datasets: [
            Ui_page.create_maket_of_line('Прирост', [], "#6554C0", 1),
            Ui_page.create_maket_of_line('Общее количество', [], "#FF6384", 2)
          ],
        },
        options: {
          scales: {
            yAxes: [{"display": true}],
            xAxes: [{"display": true}]
          },
          legend: {display: true},
          elements: {line: {tension: 0.4}}
        },
      };
    var chart_1 = new Chart(canvas_1, config_1);
    Data_vars.chart_1 = chart_1;
    // --------- график 2
    var canvas_2 = $('#Chart_2');
    var LegendClickHandler = function(e, legendItem) {
        var index = legendItem.datasetIndex;
        var ci = this.chart;
        var meta = ci.getDatasetMeta(index);
        meta.hidden = meta.hidden === null ? !ci.data.datasets[index].hidden : null;
        Data_vars.sector4_chart2_legend_hidden[index] = meta.hidden;
        ci.update();
    }
    var config_2 = {
        type: "bar",
        data: {
          labels: ['1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.'],
          datasets: [
            Ui_page.create_maket_of_bar_2("Минимальная", [0, 0, 0, 0, 0], "#28C3C2", 1, 0.5, 10),
            Ui_page.create_maket_of_bar_2("Средняя", [0, 0, 0, 0, 0], "#0052D6", 2, 0.46, 10),
            Ui_page.create_maket_of_bar_2("Максимальная", [0, 0, 0, 0, 0], "#FF6384", 3, 0.5, 10)
          ],
        },
        options: {
          scales: {
            yAxes: [{"display": true}],
            xAxes: [{"display": true}]
          },
          legend: {
              display: true,
              labels: {
                  generateLabels: function(){return [
                    {text: 'Минимальная', hidden: Data_vars.sector4_chart2_legend_hidden[0], fillStyle: 'Transparent', strokeStyle: '#28C3C2', lineWidth: 2, datasetIndex: 0},
                    {text: 'Средняя', hidden: Data_vars.sector4_chart2_legend_hidden[1], fillStyle: 'Transparent', strokeStyle: '#0052D6', lineWidth: 2, datasetIndex: 1},
                    {text: 'Максимальная', hidden: Data_vars.sector4_chart2_legend_hidden[2], fillStyle: 'Transparent', strokeStyle: '#FF6384', lineWidth: 2, datasetIndex: 2}
                  ];},
              },
              onClick: LegendClickHandler
          }
        },
      };
    Data_vars.chart_2 = new Chart(canvas_2, config_2);
    // -------- вставляем фильтры
    var chart1_filters = await Ui_page.create_chart_filters(1);
    var chart2_filters = await Ui_page.create_chart_filters(2);
    var container1 = Event_vars.sector4.find('#chart_container_1');
    var container2 = Event_vars.sector4.find('#chart_container_2');
    Event_vars.sector4.find('.load_circle').remove();
    container1.append(chart1_filters);
    container2.append(chart2_filters);
    // ставим обработчики на фильтры
    Event_vars.sector4.find('.sector4-chart_container-filter2-toggle').on('mousedown', function(){
      Event_vars.sector4_filter_toggle_pressed[Number($(this).parent().attr('id').split('chart_container_')[1]) - 1] = true;
    });
    container2.find('.cost_label').find('input').on('change', function(){
      var el = $(this);
      var index = Number(el.attr('index'));
      if (Event_vars.sector4_chart2_data_index == index){el.prop('checked', true);}
      else{
        container2.find('.cost_label').eq(Event_vars.sector4_chart2_data_index).find('input').prop('checked', false);
        Event_vars.sector4_chart2_data_index = index;
        Ui_page.update_charts(2);
      }
    });
  }
  // обработать данные для графиков
  async create_processed_data(){
    var apartments_cost = Data_vars.filtered_data.map(x => x[Data_vars.data_names['apartments_cost']][1]);
    // ------------------- ГРАФИК 1
    var result_cost = [];
    var square_func = function(x, month, item){return (x[month][item][0] > 0) ? x[month][item][0] * x[month][item][5] : 0;};
    var months_order = range(0, 10).map(x => (x + Data_vars.last_month + 1) % 12 + 1);
    months_order.forEach((month, i) => {
      var month_previous = (month - 2 + 12) % 12 + 1;
      var month_difference = []; var month_square_difference = [];
      range(0, 4).forEach((item, i) => {
        // количество
        var a = apartments_cost.map(x => x[month][item][0]);
        var a_previous = apartments_cost.map(x => x[month_previous][item][0]);
        var quantity_difference = sum(a_previous.map((x, index) => Math.max(x - a[index], 0)));
        // площадь
        var a_square = apartments_cost.map(x => square_func(x, month, item));
        var a_previous_square = apartments_cost.map(x => square_func(x, month_previous, item));
        var square_difference = sum(a_previous_square.map((x, index) => Math.max(x - a_square[index], 0)));
        // month_difference.push(quantity_difference);
        // month_square_difference.push(square_difference);
        month_difference.push(Math.floor(Math.random() * 30));
        month_square_difference.push(Math.floor(Math.random() * 100));
      });
      result_cost.push([month, month_difference, month_square_difference]);
    });
    Data_vars.processed_data1 = result_cost;
    // ------------------- ГРАФИК 2
    var result_cost = [];
    range(1, 12).forEach((month, i) => {
      var month_cost = [];
      range(0, 4).forEach((item, i) => {
        var flat_object = [];
        var flat_apartments = apartments_cost.map(x => x[month][item]);
        var func_array = [sum, min, average, max, min, average, max, min, average, max];
        var quantities = flat_apartments.map(x => x[0]);
        var summ_quantity = sum(quantities);
        func_array.forEach((func, i) => {
          if ([2, 5, 8].includes(i)){
            var result = (summ_quantity != 0) ? sum(flat_apartments.map((x, index) => (x.length > i) ? (x[i] * quantities[index]) : 0)) / summ_quantity : 0;
          }else{
            var result = func(delete_certain_els(flat_apartments.map(x => (x.length > i) ? x[i] : 0), 0, true));
          }
          flat_object.push(result);
        });
        month_cost.push(flat_object);
      });
      result_cost.push(month_cost);
    });
    Data_vars.processed_data2 = result_cost;
  }
  // обновить графики
  async update_charts(index_chart='all'){
    // пред-обработка
    if (index_chart == 'all'){
      await Ui_page.create_processed_data();
    }
    // сокращаем и показываем
    if (index_chart == 'all' || index_chart == 1){
      // ------------ Chart 1
      Data_vars.chart_1.data.labels = Data_vars.processed_data1.map(x => Data_vars.months[x[0]]);
      var func = function(x){
        return sum(x[Event_vars.sector4_data_q_or_s].map((number, index) => (Event_vars.sector4_data_rooms.includes(index)) ? number : 0));
      };
      var growth = Data_vars.processed_data1.map(x => func(x));
      var proc_sum = 0;
      var summa = growth.map(x => proc_sum = proc_sum + x);
      Data_vars.chart_1.data.datasets[0].data = growth;
      Data_vars.chart_1.data.datasets[1].data = summa;
      Data_vars.chart_1.update();
    }
    if (index_chart == 'all' || index_chart == 2){
      // ------------ Chart 2
      var index = Event_vars.sector4_chart2_data_index;
      var data_indexes = {0: [1, 2, 3], 1: [7, 8, 9], 2: [4, 5, 6], 3: [0, 0, 0]};
      var result = [[], [], []];
      Data_vars.processed_data2[Event_vars.sector4_chart2_data_month - 1].forEach((item, i) => {
        var item = item.map(x => ~~x);
        if (item.length == 1){
          if (i != 4){
            result[0].push(0); result[1].push(0); result[2].push(0);
          }
        }
        else if (index == 3){
          if (i != 4 || item[0] != 0){
            result[1].push(item[0]); result[0].push(0); result[2].push(0);
          }
        }
        else{
          var indexed = data_indexes[index];
          if (i != 4 || [item[indexed[0]], item[indexed[1]], item[indexed[2]]].filter(x => x == 0).length != 3){
            result[0].push(item[indexed[0]]);
            result[1].push(item[indexed[1]]);
            result[2].push(item[indexed[2]]);
          }
        }
      });
      result.forEach((item, i) => {
        Data_vars.chart_2.data.datasets[i].data = item;
      });
      if (result[0].length < 5){ Data_vars.chart_2.data.labels = ['1-комн.', '2-комн.', '3-комн.', '4-комн.']; }
      else{ Data_vars.chart_2.data.labels = ['1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.']; }
      Data_vars.chart_2.update();
    }
  }
  // скачать таблицу от графиков
  async chart_data_download(index){
    if (index == 0){
      Data_vars.wrapper_excel_download(function(){
        // 2 вкладки
        var workbook = new ExcelJS.Workbook();
        // первый лист
        var table_data_1 = [];
        for (var index in Data_vars.processed_data1){
          var item = Data_vars.processed_data1[index];
          table_data_1.push([Data_vars.months[item[0]], ...item[1]]);
        }
        UFE.create_worksheet(workbook, 'Количество', ['Месяцы', '1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.'], table_data_1, ['FFFFCC', 'FFF599'], create_array_true(6, 20), 'center');
        // второй лист
        var table_data_2 = [];
        for (var index in Data_vars.processed_data1){
          var item = Data_vars.processed_data1[index];
          table_data_1.push([Data_vars.months[item[0]], ...item[2]]);
        }
        UFE.create_worksheet(workbook, 'Площадь', ['Месяцы', '1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.'], table_data_2, ['FFFFCC', 'FFF599'], create_array_true(6, 20), 'center');
        // сохраняем
        UFE.save_excel(workbook, 'Продажи за 11 месяцев - Maphouse');
      });
    }
    else{
      Data_vars.wrapper_excel_download(function(){
        // дома и квартиры значит
        var workbook = new ExcelJS.Workbook();
        var table_data_1 = [];
        for (var i = Data_vars.last_month; i < Data_vars.last_month + 12; i++){
          var index = i % 12;
          var result_cost = Data_vars.processed_data2[index];
          // формируем в одну строку
          var data_cost = [];
          result_cost.forEach((item, i) => {
            if (item.length > 1){data_cost.splice(data_cost.length, 0, ...item);}
            else{data_cost.splice(data_cost.length, 0, ...create_array_true(10, 0));}
          });
          table_data_1.push([Data_vars.months[index + 1], ...data_cost]);
        }
        UFE.create_worksheet(workbook, 'Сводка по ценам', ['Месяцы', ...Data_vars.sector5_names_of_columns_excel_apart], table_data_1, ['FFFFCC', 'FFF599'], create_array_true(51, 16), 'center');
        // сохраняем
        UFE.save_excel(workbook, 'Цена за 11 месяцев - Maphouse');
      });
    }
  }
  // ---------------------------------- СЕКТОР 5
  // вставляем параметры в выбор параметров
  async insert_params_to_params_container(){
    var container = Event_vars.sector5.find('.sector5-input-choice').find('div[dn="container"]');
    container.css({'height': Math.min(Data_vars.names_params_by_table_input.length * 30, 300)});
    var lines = '';
    Data_vars.names_params_by_table_input.forEach((item, i) => {
      if (i == Data_vars.filter_by_input_table_index){ var addition = '<span></span>'; }else{ var addition = ''; }
      var line = `<div dn='global' style='margin-top: ${i * 30}px;' index='${i}'><div>${item[1]}</div>${addition}</div>`;
      lines += line;
    });
    container.html(lines);
    container.find('div[dn="global"]').on('click', function(){
      Ui_page.change_filter_by_input_table($(this).attr('index'));
    });
  }
  // показать табличку с выбором
  async show_table_input_filters(){
    var container = Event_vars.sector5.find('.sector5-input-choice');
    if (!Data_vars.sector5_container_filter_values){
      Data_vars.sector5_container_filter_values = true;
      container.find('div[dn="container"]').css({'display': 'inline'});
    }
    else{
      Data_vars.sector5_container_filter_values = false;
      container.find('div[dn="container"]').css({'display': 'none'});
    }
  }
  // изменить фильтры при таблице
  async change_filter_by_input_table(index){
    //
    var index = Number(index);
    var divs = Event_vars.sector5.find('.sector5-input-choice').find('div[dn="container"]').find('div[dn="global"]');
    divs.eq(Data_vars.filter_by_input_table_index).find('span').remove();
    divs.eq(index).append('<span></span>');
    var input = Event_vars.sector5.find('.sector5-input');
    var names_array = Data_vars.names_params_by_table_input[index];
    if (['developer', 'builder'].includes(names_array[0])){ var text = names_array[1].toLowerCase() + 'а'; }
    else{ var text = names_array[1].toLowerCase(); }
    input.attr('placeholder', `Начните вводить ${text}`);
    Data_vars.filter_by_input_table = names_array[0];
    Data_vars.filter_by_input_table_index = index;
    setTimeout(function(){Data_vars.apply_filters();}, 1);
  }
  // изменить ширину строки таблицы
  async change_row_height(index, check=true){
    // предварительно убираем окно цен
    Ui_page.hide_a_cost();
    //
    var index_old = Data_vars.sector5_table_height_items[0];
    if (index_old == index && check){ return; }
    var rows = Event_vars.sector5.find('.t_div');
    var new_height = Data_vars.sector5_table_height_items[1][index];
    document.documentElement.style.setProperty("--t_div_height", `${new_height}px`);
    rows.css({'height': new_height});
    // меняем изображение
    Event_vars.sector5.find(`.row_height`).eq(index_old).find('img').attr('src', `/static/img/housing_stock/table_row_h_${index_old + 1}_grey.svg`);
    Event_vars.sector5.find(`.row_height`).eq(index).find('img').attr('src', `/static/img/housing_stock/table_row_h_${index + 1}.svg`);
    Data_vars.sector5_table_height_items[0] = index;
  }
  // переходим на другую страницу таблицы
  async change_table_page(direction){
    // предварительно убираем окно цен
    Ui_page.hide_a_cost();
    //
    if (direction == -1 && Data_vars.index_start_item > 0){
      Data_vars.index_start_item = Math.max(0, Data_vars.index_start_item - Data_vars.sector5_houses_in_page);
      Ui_page.insert_values_to_table(false);
      var text = Event_vars.sector5.find('div[dn="page_text"]');
      var line = `${Data_vars.index_start_item + 1} - <span onclick='Ui_page.change_h_in_p();'>${Math.min(Data_vars.index_start_item + Data_vars.sector5_houses_in_page, Data_vars.table_data.length)}</span> из ${Data_vars.table_data.length}`;
      text.html(line);
    }
    else if (direction == 1 && Data_vars.index_start_item + Data_vars.sector5_houses_in_page < Data_vars.table_data.length){
      Data_vars.index_start_item = Math.min(Data_vars.table_data.length, Data_vars.index_start_item + Data_vars.sector5_houses_in_page);
      Ui_page.insert_values_to_table(false);
      var text = Event_vars.sector5.find('div[dn="page_text"]');
      var line = `${Data_vars.index_start_item + 1} - <span onclick='Ui_page.change_h_in_p();'>${Math.min(Data_vars.index_start_item + Data_vars.sector5_houses_in_page, Data_vars.table_data.length)}</span> из ${Data_vars.table_data.length}`;
      text.html(line);
    }
  }
  // удалить выбранные объекты
  async delete_checked_rows(){
    var new_filtered_data = []; var new_table_data = []; var new_filtered_data_indexes = []; var new_build_data_indexes = [];
    for (var index in Data_vars.sector5_table_checked_items){
      var bool = Data_vars.sector5_table_checked_items[index];
      if (!bool){
        if (Data_vars.liter_or_build == 'liter'){
          new_filtered_data.push(Data_vars.filtered_data[Data_vars.table_indexes_in_filtered_data[index]]);
          new_filtered_data_indexes.push(Data_vars.filtered_data_indexes[Data_vars.table_indexes_in_filtered_data[index]]);
        }else{
          var indexes = Data_vars.filtered_data_table_build_indexes[Data_vars.table_indexes_in_filtered_data[index]];
          var new_filtered_data = concat(new_filtered_data, indexes.map(x => Data_vars.filtered_data[x]));
          var new_filtered_data_indexes = concat(new_filtered_data_indexes, indexes.map(x => Data_vars.filtered_data_indexes[x]));
          new_build_data_indexes.push(indexes);
        }
        new_table_data.push(Data_vars.table_data[index]);
      }
    };
    Data_vars.filtered_data = new_filtered_data;
    Data_vars.filtered_data_indexes = new_filtered_data_indexes;
    var data_length = (Data_vars.liter_or_build == 'liter') ? Data_vars.filtered_data.length : [...new Set(Data_vars.filtered_data.map(x => x[+Data_vars.data_names['erz_id']]))].length;
    Data_vars.table_data = new_table_data;
    Data_vars.table_indexes_in_filtered_data = range(0, data_length - 1);
    if (Data_vars.liter_or_build == 'build'){
      // собираем в списки новостроек их литеры
      var new_buildings = {};
      Data_vars.filtered_data.forEach((object, i) => {
        var key = object[Data_vars.data_names['erz_id']];
        (key in new_buildings) ? new_buildings[key].push(i) : new_buildings[key] = [i];
      });
      Data_vars.filtered_data_table_build_indexes = [];
      // для каждой новостройки суммируем параметры литеров
      for (var erz_id in new_buildings){
        Data_vars.filtered_data_table_build_indexes.push(new_buildings[erz_id]);
      }
    }
    // обновляем
    if (Event_vars.animation_started){
      Data_vars.animation_stop_apply_filters = true;
      Ui_page.start_map_animation();
    }
    Ui_page.insert_ans_show_house_markers(true);
    Ui_page.update_charts();
    Ui_page.preparing_to_create_a_table(false, false);
    Event_vars.sector5.find('.delete_rows_undo').css({'display': 'inline'});
    var images = Event_vars.sector5.find('.tbc').find('img');
    images.css({'transform': 'rotate(0deg)'});
  }
  // отсортировать по колонке
  async sort_by_column(index, update_table=true, change_position=true){
    // предварительно убираем окно цен
    Ui_page.hide_a_cost();
    //
    var images = Event_vars.sector5.find('.tbc').find('img');
    images.css({'transform': 'rotate(0deg)'});
    var column = Data_vars.sorted_column[0]; var position = Data_vars.sorted_column[1];
    if (!change_position){ position *= -1; }
    if (column != index || position == -1){
      if (change_position){Data_vars.sorted_column = [index, 1];}
      // сортируем
      if (Data_vars.sector5_table_rate_indexes.includes(index)){var func = x => Number(x[index].split('%')[0]);}
      else if (Data_vars.sector5_table_datetime_indexes.includes(index) && Data_vars.liter_or_build == 'liter'){var func = function(x){return +`${x[index]}`.split('кв.')[1] * 4 + Data_vars.rome_numbers[`${x[index]}`.split('кв.')[0].trim()];} }
      else{var func = x => x[index];}
      Data_vars.table_data = Data_vars.concate_array_and_indexes(Data_vars.table_data, Data_vars.table_indexes_in_filtered_data);
      Data_vars.table_data = sort(Data_vars.table_data, func);
      var result = Data_vars.delete_array_and_indexes(Data_vars.table_data);
      Data_vars.table_data = result[0];
      Data_vars.table_indexes_in_filtered_data = result[1];
      // обновляем
      if (update_table){Ui_page.preparing_to_create_a_table(false, false);}
    }
    else{
      if (change_position){Data_vars.sorted_column[1] = -1;}
      // сортируем в обратку
      if (Data_vars.sector5_table_rate_indexes.includes(index)){var func = x => Number(x[index].split('%')[0]);}else{var func = x => x[index];}
      Data_vars.table_data = Data_vars.concate_array_and_indexes(Data_vars.table_data, Data_vars.table_indexes_in_filtered_data);
      Data_vars.table_data = sort(Data_vars.table_data, func);
      Data_vars.table_data.reverse();
      var result = Data_vars.delete_array_and_indexes(Data_vars.table_data);
      Data_vars.table_data = result[0];
      Data_vars.table_indexes_in_filtered_data = result[1];
      // обновляем
      if (update_table){Ui_page.preparing_to_create_a_table(false, false);}
      Event_vars.sector5.find(`.tb${index}`).find('img').css({'transform': 'rotate(180deg)'});
    }
  }
  // отменить удаление
  async undo_delete_rows(){
    Data_vars.apply_filters();
  }
  // изменить количество строк на странице таблицы
  async change_rows_by_number(number){
    Data_vars.sector5_houses_in_page = number;
    Ui_page.insert_values_to_table(false);
    var text = Event_vars.sector5.find('div[dn="page_text"]');
    var line = `${Data_vars.index_start_item + 1} - <span onclick='Ui_page.change_h_in_p();'>${Math.min(Data_vars.index_start_item + Data_vars.sector5_houses_in_page, Data_vars.table_data.length)}</span> из ${Data_vars.table_data.length}`;
    text.html(line);
  }
  // открыть окошко изменения количества строк в таблице
  async change_h_in_p(){
    if (Event_vars.window_change_hp_open){ return; }
    var header_container = Event_vars.sector5.find('.sector5-table-header');
    var span = Event_vars.sector5.find('div[dn="page_text"]').find('span');
    var margin_left = (span.offset().left - header_container.offset().left) + Math.round((span.width() - 50) / 2);
    var lines_all = `<div class='change_hp_window' style='margin-left: ${margin_left}px;'>`;
    var array = [50, 100, 300, 500];
    array.forEach(function(number, index, array){
      var line = `<button onclick='Ui_page.change_rows_by_number(${number});'>по ${number}</button>`;
      lines_all += line;
    });
    header_container.append(lines_all + '</div>');
    Event_vars.window_change_hp_open = true;
  }
  // создать линию таблицы
  create_table_line(array, index){
    // смотрим, выделена или нет
    if (Data_vars.sector5_table_checked_items[index]){ var style = ' style="background: #f6f7cd;"'; var checked = ' checked'; }else{ var style = ''; var checked = ''; }
    var lines_all = `
      <div class='t_div' id='t_div_${index}'${style}>
      <div class='t_checkbox'><input type='checkbox'${checked}></div>
    `;
    array.forEach(function(item, index, array){
      lines_all += `<div class='tb tb${index}'>${item}</div>`
    });
    return lines_all + '</div>';
  }
  // созадём первую строку таблицы (названия столбцов)
  async create_table_body_header(){
    var table_header = Event_vars.sector5.find('#table_header');
    var lines_all = `
      <div class='t_div' id='t_div_main'>
      <div class='t_checkbox'><input type='checkbox'></div>
    `;
    Data_vars.sector5_names_of_columns.forEach(function(name, index, array){
      lines_all += `<div class='tb tbc tb${index}'>${name}<img src='/static/img/housing_stock/table_arrow.svg' onclick='Ui_page.sort_by_column(${index});' ondragstart="return false;"><div></div></div>`
    });
    lines_all += '</div>';
    table_header.html(lines_all);
    // ширина всей таблицы
    Event_vars.sector5.find('#width_of_columns').html(`.t_div{width: ${Data_vars.sector5_sum_width}px;}`);
    // ставим обработчики
    var table_container = Event_vars.sector5.find('.table_container');
    // при прокрутке делаем тень
    table_container.on('scroll', $.debounce(250, true, function(){
      var el = $(this);
      el.find('#t_div_main').css({'box-shadow': '0px -5px 15px var(--green_light)'});
    }));
    table_container.on('scroll', $.debounce(250, function(){
      var el = $(this);
      el.find('#t_div_main').css({'box-shadow': ''});
    }));
    // изменение размера столбца
    table_header.find('.tbc').find('div').on('mousedown', function(){
      Event_vars.change_width_column = Number($(this).parent().attr('class').split('tb tbc tb')[1]);
      document.body.style.cursor = "col-resize";
    });
  }
  // установить ширину для определённого столбца
  async set_column_width(){
    var table_style = Event_vars.sector5.find('.table_style');
    var line_style = '<style>';
    Data_vars.sector5_width_of_items.forEach((item, index) => {
      var line = `.tb${index}{width: ${item}px;}`;
      line_style += line;
    });
    table_style.html(line_style + '</style>');
  }
  // обработчики событий
  table_checked_event(){
    var t_div = $(this).parent().parent();
    var index = t_div.prop('id').split('t_div_')[1];
    if (index == 'main'){
      var t_divs = Event_vars.sector5.find('.t_div');
      var inputs = t_divs.find('input');
      var button = Event_vars.sector5.find('.delete_rows');
      if (Data_vars.sector5_table_checked_items_quantity_true != Data_vars.filtered_data.length){
        Data_vars.sector5_table_checked_items = create_array_true(Data_vars.filtered_data.length, true);
        Data_vars.sector5_table_checked_items_quantity_true = Data_vars.filtered_data.length;
        t_divs.css({'background': '#f6f7cd'});
        inputs.prop('checked', true);
        button.css({'display': 'inline'});
      }
      else{
        Data_vars.sector5_table_checked_items = create_array_true(Data_vars.filtered_data.length, false);
        Data_vars.sector5_table_checked_items_quantity_true = 0;
        t_divs.css({'background': ''});
        inputs.prop('checked', false);
        button.css({'display': 'none'});
      }
    }
    else{
      var index = Number(index);
      var button = Event_vars.sector5.find('.delete_rows');
      var input = Event_vars.sector5.find('#t_div_main').find('input');
      if (!Data_vars.sector5_table_checked_items[index]){
        Data_vars.sector5_table_checked_items[index] = true;
        Data_vars.sector5_table_checked_items_quantity_true += 1;
        t_div.css({'background': '#f6f7cd'});
        button.css({'display': 'inline'});
        if (Data_vars.sector5_table_checked_items_quantity_true == Data_vars.sector5_table_checked_items.length){
          var t_div_main = Event_vars.sector5.find('#t_div_main');
          t_div_main.css({'background': '#f6f7cd'});
          input.prop('checked', true);
        }
      }
      else{
        Data_vars.sector5_table_checked_items[index] = false;
        Data_vars.sector5_table_checked_items_quantity_true -= 1;
        if (Data_vars.sector5_table_checked_items_quantity_true == Data_vars.sector5_table_checked_items.length - 1){
          var t_div_main = Event_vars.sector5.find('#t_div_main');
          t_div_main.css({'background': ''});
          input.prop('checked', false);
        }
        if (Data_vars.sector5_table_checked_items_quantity_true == 0){ button.css({'display': 'none'}); }
        t_div.css({'background': ''});
      }
    }
  }
  // создать в окне цен переключатели
  async create_checkboxes_in_cost_window(){
    var container = Event_vars.sector5.find('.sector5-popup_window').find('div[dn="checkbox_container"]');
    var data = [['Стоимость', 0], ['Цена за м²', 113], ['Площадь', 220], ['Количество', 325]];
    var lines = '';
    data.forEach((item, i) => {
      if (i == 0){ var checked = 'checked'; }else{ var checked = ''; }
      var line = `<div class='wnd_cost_change' style='margin-left: ${item[1]}px;'><label class='cost_label'>${item[0]}<input type="checkbox" index='${i}' ${checked}><span class='cost_span'></span></label></div>`;
      lines += line;
    });
    container.html(lines);
    // обработчики
    container.find('.cost_label').find('input').on('change', function(){
      var el = $(this);
      var index = Number(el.attr('index'));
      if (Event_vars.window_cost_data_index == index){el.prop('checked', true);}
      else{
        Event_vars.sector5.find('.cost_label').eq(Event_vars.window_cost_data_index).find('input').prop('checked', false);
        Event_vars.window_cost_data_index = index;
        Ui_page.push_data_to_cost_window_chart();
      }
    });
  }
  // сделать график цен (вставить данные)
  async push_data_to_cost_window_chart(in_map=false){
    if (in_map || Event_vars.window_cost_is_open[1] == 'map_index'){
      var object_data = Data_vars.data[Event_vars.window_cost_table_index][Data_vars.data_names['apartments_cost']][1][Data_vars.last_month];
    }else{
      if (Data_vars.liter_or_build == 'liter'){
        var object_data = Data_vars.filtered_data[Event_vars.window_cost_table_index][Data_vars.data_names['apartments_cost']][1][Data_vars.last_month];
      }else{
        var object_data = Data_vars.build_cost_apartments_data[Event_vars.window_cost_table_index].cost;
      }
    }
    var index = Event_vars.window_cost_data_index;
    var data_indexes = {0: [1, 2, 3], 1: [7, 8, 9], 2: [4, 5, 6], 3: [0, 0, 0]};
    var result = [[], [], []];
    object_data.forEach((item, i) => {
      var item = item.map(x => ~~x);
      if (item.length == 1){
        result[0].push(0); result[1].push(0); result[2].push(0);
      }
      else if (index == 3){
        result[1].push(item[0]); result[0].push(0); result[2].push(0);
      }
      else{
        result[0].push(item[data_indexes[index][0]]);
        result[1].push(item[data_indexes[index][1]]);
        result[2].push(item[data_indexes[index][2]]);
      }
    });
    result.forEach((item, i) => {
      Data_vars.table_cost_chart.data.datasets[i].data = result[i];
    });
    Data_vars.table_cost_chart.update();
  }
  // создать в окне цен макет графика
  async create_maket_cost_chart(){
    var config = {
        "type": "bar",
        "data": {
          "labels": ['1-комн.', '2-комн.', '3-комн.', '4-комн.', 'многок.'],
          "datasets": [{
            "label": "Минимальная",
            "type": "bar",
            "backgroundColor": "#28C3C2",
            "data": [15, 18, 19, 23, 24],
            stack: 1,
            categoryPercentage: 0.5,
            maxBarThickness: 10,
          }, {
            "label": "Средняя",
            "type": "bar",
            "backgroundColor": "#0052D6",
            "data": [16, 19, 20, 24, 26],
            stack: 2,
            categoryPercentage: 0.46,
            maxBarThickness: 10,
          }, {
            "label": "Максимальная",
            "type": "bar",
            "backgroundColor": "#FF6384",
            "data": [18, 21, 25, 27, 28],
            stack: 3,
            categoryPercentage: 0.5,
            maxBarThickness: 10,
          }]
        },
        "options": {
          'legend': {'display': false},
          "scales": {
            "yAxes": [{"display": true}],
            "xAxes": [{
              "display": true,
            }]
          }
        }
      };
    var canvas = $('#table_cost_canvas');
    var chart = new Chart(canvas, config);
    Data_vars.table_cost_chart = chart;
  }
  // показать цену за квартиры при наведении
  async show_a_cost(index, start=true, in_map=false){
    if (start){ Event_vars.window_cost_is_open_timer = setTimeout(Ui_page.show_a_cost, 80, index, false, in_map); return; }
    clearTimeout(Event_vars.window_cost_is_open[2]);
    clearTimeout(Event_vars.window_cost_display_timer);
    if (in_map){
      if (Event_vars.window_cost_is_open[0] && Event_vars.window_cost_is_open[1] == 'map_index'){
        Event_vars.window_cost_is_open = [true, 'map_index', undefined];
        return;
      }
    }else{
      if (Event_vars.window_cost_is_open[0] && Event_vars.window_cost_is_open[1] == index){
        Event_vars.window_cost_is_open = [true, index, undefined];
        return;
      }
    }
    if (in_map){
      var el = Event_vars.sector3.find(`.sector3-window_inf-cost`);
    }else{
      var el = Event_vars.sector5.find(`span[c_index="${index}"]`);
    }
    var container = Event_vars.sector5.find('.sector5-popup_window');
    // заполняем данными
    if (in_map){
      var data = Data_vars.data[index];
      container.find('div[dn="title"]').html(data[Data_vars.data_names['name']]);
      Event_vars.window_cost_table_index = index;
      Ui_page.push_data_to_cost_window_chart(true);
    }else{
      if (Data_vars.liter_or_build == 'liter'){
        var data = Data_vars.filtered_data[index];
        container.find('div[dn="title"]').html(data[Data_vars.data_names['name']]);
      }
      else{
        var data = Data_vars.build_cost_apartments_data[index];
        container.find('div[dn="title"]').html(data['global_name']);
      }
      Event_vars.window_cost_table_index = index;
      Ui_page.push_data_to_cost_window_chart();
    }
    // перемещаем
    if (in_map){
      var margin_left = Math.min(el.offset().left - Event_vars.sector5.offset().left - 5, window.innerWidth - Event_vars.sector5.offset().left - 550);
      var margin_top = -(Event_vars.sector5.offset().top - Event_vars.sector3.offset().top) + (el.offset().top - Event_vars.sector3.offset().top) + 25;
      Event_vars.window_cost_is_open = [true, 'map_index', undefined];
    }else{
      var margin_left = Math.min(el.offset().left - Event_vars.sector5.offset().left, window.innerWidth - Event_vars.sector5.offset().left - 550);
      var margin_top = el.offset().top - Event_vars.sector5.offset().top + 25;
      Event_vars.window_cost_is_open = [true, index, undefined];
    }
    container.css({'margin-left': margin_left, 'margin-top': margin_top + 15, 'display': 'inline', 'opacity': 0.5});
    container.find('div[dn="arrow"]').css({'margin-left': el.offset().left - container.offset().left + 20});
    setTimeout(function(container, margin_top){
      container.css({'margin-top': margin_top, 'opacity': 1.0});
    }, 1, container, margin_top);
  }
  // скрыть цену за квартиры
  async hide_a_cost(){
    var container = Event_vars.sector5.find('.sector5-popup_window');
    container.css({'margin-top': Number(container.css('margin-top').split('px')[0]) + 15, 'opacity': '0.5'});
    Event_vars.window_cost_display_timer = setTimeout(function(){container.css({'display': 'none'});}, 100, container);
    Event_vars.window_cost_is_open = [false, undefined, undefined];
  }
  // меняем литеры на новостройки или наоборот
  async change_liter_or_build(){
    var switcher = Event_vars.sector5.find('.liter_to_build_switcher');
    var circle = switcher.find('div[dn="line"]').find('div');
    var titles = switcher.find('div[dn="title"]');
    var header = Event_vars.sector5.find('#table_header');
    var field_1 = header.find(`.tb${Data_vars.data_names['name']}`);
    var field_2 = header.find(`.tb${Data_vars.data_names['global_name']}`);
    var change_title_func = function(field, title){ field.html(title + '<img' + field.html().split('<img')[1]); };
    if (Data_vars.liter_or_build == 'liter'){
      Data_vars.liter_or_build = 'build';
      circle.css({'margin-left': 13});
      change_title_func(field_1, 'Название новостройки');
      change_title_func(field_2, 'Название литера');
      titles.eq(0).css({'text-decoration': 'none'});
      titles.eq(1).css({'text-decoration': 'underline'});
    }
    else{
      Data_vars.liter_or_build = 'liter';
      circle.css({'margin-left': -2});
      change_title_func(field_2, 'Название новостройки');
      change_title_func(field_1, 'Название литера');
      titles.eq(0).css({'text-decoration': 'underline'});
      titles.eq(1).css({'text-decoration': 'none'});
    }
    header.find('.tbc').find('div').on('mousedown', function(){
      Event_vars.change_width_column = Number($(this).parent().attr('class').split('tb tbc tb')[1]);
      document.body.style.cursor = "col-resize";
    });
    setTimeout(function(){
      Ui_page.preparing_to_create_a_table(false, true, false);
    }, 1);
  }
  // вставить таблицу в div
  async insert_values_to_table(checked_main=true){
    // делаем таблицу
    var table = Event_vars.sector5.find('#table');
    var lines_all = '';
    var limits = [Data_vars.index_start_item, Math.min(Data_vars.index_start_item + Data_vars.sector5_houses_in_page, Data_vars.table_data.length)];
    for (var index = limits[0]; index < limits[1]; index ++){
      var item = Data_vars.table_data[index];
      var line = Ui_page.create_table_line(item, index);
      lines_all += line;
    };
    table.html(lines_all);
    if (Data_vars.load_circle_exists_sector5){
      Event_vars.sector5.find('.load_circle').remove();
      Data_vars.load_circle_exists_sector5 = false;
    }
    // ширина всей таблицы
    Event_vars.sector5.find('#width_of_columns').html(`.t_div{width: ${Data_vars.sector5_sum_width}px;}`);
    // меняем высоту
    Ui_page.change_row_height(Data_vars.sector5_table_height_items[0], false);
    // ширина столбцов
    Ui_page.set_column_width();
    // обработчики событий
    if (checked_main){ Event_vars.sector5.find('.t_checkbox').find('input').on('change', Ui_page.table_checked_event); }
    else{ Event_vars.sector5.find('#table').find('.t_checkbox').find('input').on('change', Ui_page.table_checked_event); }
  }
  // начальная подготовка к созданию таблицы
  async preparing_to_create_a_table(create_header=true, convert_table_data=true, checked_main=false){
    // сколько у нас объектов всего (для выделения)
    var data_length = (Data_vars.liter_or_build == 'liter') ? Data_vars.filtered_data.length : [...new Set(Data_vars.filtered_data.map(x => x[+Data_vars.data_names['erz_id']]))].length;
    Data_vars.sector5_table_checked_items = create_array_true(data_length, false);
    Data_vars.sector5_table_checked_items_quantity_true = 0;
    Data_vars.index_start_item = 0;
    // ширина колонок
    Ui_page.set_column_width();
    // делаем первую строку таблицы (названия столбцов)
    if (create_header){ Ui_page.create_table_body_header(); }
    else{
      var table_header = Event_vars.sector5.find('#t_div_main');
      table_header.css({'background': 'white'});
      table_header.find('input').prop('checked', false);
      Event_vars.sector5.find('.delete_rows').css({'display': 'none'});
    }
    // сверху страницу и номер
    var text = Event_vars.sector5.find('div[dn="page_text"]');
    var line = `1 - <span onclick='Ui_page.change_h_in_p();'>${Math.min(Data_vars.sector5_houses_in_page, data_length)}</span> из ${data_length}`;
    text.html(line);
    // переделываем значения в данных
    if (convert_table_data){
      Data_vars.table_data = Data_vars.convert_filtered_date_to_normal_form_for_table(Data_vars.filtered_data);
      Data_vars.table_indexes_in_filtered_data = range(0, data_length - 1);
      Event_vars.sector5.find('.delete_rows_undo').css({'display': 'none'});
      // сортируем
      Ui_page.sort_by_column(Data_vars.sorted_column[0], false, create_header==true);
    }
    // вставляем значения
    Ui_page.insert_values_to_table(checked_main);
  }
  // сформировать таблицу для скачивания
  async create_excel_table_data(){
    var data = [];
    if (Data_vars.liter_or_build == 'liter'){
      Data_vars.filtered_data.forEach(function(object, index, array){
        var object = clone_array(object);
        var floors = object[Data_vars.data_names['floors']];
        var coordinates = object[Data_vars.data_names['coordinates']];
        var site = object[Data_vars.data_names['site']];
        var cost = object[Data_vars.data_names['apartments_cost']][1][Data_vars.last_month];
        // переделываем
        object[Data_vars.data_names['floors']] = floors[1];
        object[Data_vars.data_names['coordinates']] = `${coordinates[0]}, ${coordinates[1]}`;
        object[Data_vars.data_names['phone']] = object[Data_vars.data_names['phone']].split(',').join(', ');
        object.splice(Data_vars.data_names['erz_id'], 1);
        // формируем данные о ценах
        var data_cost = [];
        cost.forEach((item, i) => {
          if (item.length > 1){data_cost.splice(data_cost.length, 0, ...item);}
          else{data_cost.splice(data_cost.length, 0, ...create_array_true(10, 0));}
        });
        object.splice(Data_vars.data_names['apartments_cost'], 1, ...data_cost);
        data.push(object);
      });
    }else{
      // собираем в списки новостроек их литеры
      var new_buildings = {};
      Data_vars.filtered_data.forEach((object, i) => {
        var key = object[Data_vars.data_names['erz_id']];
        (key in new_buildings) ? new_buildings[key].push([i, object]) : new_buildings[key] = [[i, object]];
      });
      // для каждой новостройки суммируем параметры литеров
      var data_new = [];
      for (var erz_id in new_buildings){
        var liters = new_buildings[erz_id].map(x => x[1]);
        var new_build = create_array_true(Data_vars.data_names_list.length, '');
        // --- переделываем
        // 1. переделываем этажи
        new_build[Data_vars.data_names['floors']] = max(liters.map(x => x[Data_vars.data_names['floors']][1]));
        // 2. суммируем определённые столбцы
        Data_vars.array_of_sum_in_build.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          new_build[index] = sum(liters.map(x => +x[index]));
        });
        // 3. оставшиеся столбцы перечисляем через запятую
        Data_vars.array_of_comma_in_build.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          if (item == 'phone'){
            new_build[index] = [...new Set(liters.map(x => x[index]).reduce((a, b) => a.concat(b.split(',')), []))].join(', ');
          }
          else{
            new_build[index] = [...new Set(liters.map(x => x[index]))].join(';   ');
          }
        });
        new_build.splice(Data_vars.data_names['erz_id'], 1);
        // 4. меняем столбцы с именами
        [new_build[Data_vars.data_names['name']], new_build[Data_vars.data_names['global_name']]] = [new_build[Data_vars.data_names['global_name']], new_build[Data_vars.data_names['name']]];
        // 5. индексы класности
        Data_vars.sector5_table_rate.forEach((item, i) => {
          var index = Data_vars.data_names[item];
          var indexes = liters.map(x => x[index]);
          new_build[index] = +average(indexes).toFixed(2);
        });
        // 6. стоимость квартир
        var apartments_cost = liters.map(x => x[Data_vars.data_names['apartments_cost']][1][Data_vars.last_month]);
        var result_cost = [];
        range(0, 4).forEach((item, i) => {
          var flat_object = [];
          var flat_apartments = apartments_cost.map(x => x[item]);
          var func_array = [sum, min, average, max, min, average, max, min, average, max];
          var quantities = flat_apartments.map(x => x[0]);
          var summ_quantity = sum(quantities);
          func_array.forEach((func, i) => {
            if ([2, 5, 8].includes(i)){
              var result = (summ_quantity != 0) ? sum(flat_apartments.map((x, index) => (x.length > i) ? (x[i] * quantities[index]) : 0)) / summ_quantity : 0;
            }else{
              var result = func(delete_certain_els(flat_apartments.map(x => (x.length > i) ? x[i] : 0), 0, true));
            }
            flat_object.push(result);
          });
          result_cost.push(flat_object);
        });
        var data_cost = [];
        result_cost.forEach((item, i) => {
          if (item.length > 1){data_cost.splice(data_cost.length, 0, ...item);}
          else{data_cost.splice(data_cost.length, 0, ...create_array_true(10, 0));}
        });
        new_build.splice(Data_vars.data_names['apartments_cost'], 1, ...data_cost);
        // --- сохраняем
        data.push(new_build);
      }
    }
    Data_vars.excel_filtered_data = data;
  }
  // скачать таблицу
  async download_table(){
    await Ui_page.create_excel_table_data();
    Data_vars.wrapper_excel_download(async function(){
      if (Data_vars.liter_or_build == 'liter'){
        await UFE.create_and_save_workbook('Литеры Уфы - MapHouse.xlsx', 'Литеры', Data_vars.sector5_names_of_columns_excel, Data_vars.excel_filtered_data);
      }else{
        await UFE.create_and_save_workbook('Новостройки Уфы - MapHouse.xlsx', 'Жилые комплексы', Data_vars.sector5_names_of_columns_excel, Data_vars.excel_filtered_data);
      }
      Data_vars.excel_filtered_data = [];
    });
  }
  // ---------------------------------- FOOTER
  async insert_back_houses(){
    var container = Event_vars.footer.find('.footer_preview-back_houses');
    var lines = '';
    for (var i=0; i<Math.ceil(window.innerWidth / 529); i++){
      var line = `<span style='margin-left: ${i * 529}px;'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="529px" height="55px" viewBox="0 0 529 55" version="1.1"><defs><image id="image6" width="529" height="55" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhEAAAA3CAYAAACy9BgQAAAABmJLR0QA/wD/AP+gvaeTAAAFFklEQVR4nO3d31HbShTH8d8aCojDvc+eUQtuQSnBtwSlBFIClGBKgBJICaEEmNlnLOMCIp/7YDmYYMCsJa3+fD8zeWHI5Ng44qddnbNOAAAgmM/Njvn7kzPnqqqlaaPYBQAAgG4iRAAAgCCECAAAEIQQAQAAghAiAABAEEIEAAAIQogAAABBCBEAACAIIQIAAAQ5jV0AAOB9h0xE7PLUQ3QXIaJnPrrYcKEBAFSF7QwAABCEEAEAAIKwnQEAOBrPbQwTKxEAACAIIQIAAAQhRAAAgCCECAAAEIQHK4EGHfLw2T48kAagjViJAAAAQQgRAFrP5zaPXUNV/KNNfW5zn9sydi3AsdjOANAFmc9NkzP3PXYhIfzKxlprJimTaRq7HqAqhAgAXdG5IOEXlspppkJZ7FqAOhAiAHRJ64OEX1mitWYyZZKS2PUAdSJEAOiaVgYJn9tM0kyFZrFrwfDE6vwiRADoolYECb+yRL+VyWkmVh0wQHRnlPzCLmLXAOBTslhdG35pmc/tVoXu5XQuAgQGipUIbVquygvBj9i1AE16Ywn0ofzzkunu1ddGetD69fdO/nE/q6jvAJmk5lcjTL1pOe0Thrk1jxAhSSeaK+ij1x5+ZWP9pnUMlUi0787aKX31NZO0//LLRRkYgMGHCL+wiy71bfuFpRop0VqJnBJJY0mpCnHZroBf2OYX5UhTrTWW01hSIqfx9nPCXQsAbPQmRPy9jHXIhX5nG6M7nG7fufvDsZxuJb2+w+74ShUA1KE3ISJID7YxgK77cwPgdCfTk6QHmZ400pPWe57DANAaww4RHdrGAHpv9/+j03vPWwBoidPPPs3KfjAAAJCGvhIBdNxbNwGEfQBNYNgUOs/ntvQLu/ArG8euBQCGpHUhwj/a1C/tV+w66lJOuruPXUfPjOV0rkL3ZZhgeiAANKBV2xl+aecyncvUuztKv7SsfG38gqvPNkyc+9yudKLLyRf3evIiBilomqHTnUb6NvninmooKXjCItAWrQgRfmVjFZrL+nf6XV/Cw3sXu5buv2cqlPncfsp02eAYZujF5+VJ+tOm+VC2cO62c7abaapCv/yj/Tf519FuCvwleojwC0tV6Frq1+pDX8JDD6RySn1uP+V0M/nqrmIXNDCbiapbu3GzjdFzv0Qj3frcvk/O3E3sYoA2iRoi/MIuOjcx8gOEhzB+ZYkKTWWaaqRUpmnFKxypTKnP7VxOl4QJfNJY0rVf2o/JV3cZu5gQtPNjn2O31OKuRNQYIJrea6wyPAxhn9Q/2lQnSsv3K1VRvm/bIUP1SWSaxzpCuik7n6HnEzm3p3C+cfImDmC68DkP7gJb0bczuo6Vh8OUB1ulcppKmkoaM3K8Ec8ncm5P4WQS5LGy2AUAbXF0iPC5LWW60qku63qCudVMvb6jrcz2YCsAQG9UMSeCHn00yq8sKedtXA9h6wcA2qrK7Qx69FGb8tj2mUZKVXBwGgC0QV3PRGx79K9kuqFHHyF8bjNt2gNTbff1WXcAgNb4dIj45PJxJsfAHwS7jl0A2o9OlA229rqryz+7prozNgN/lnYn6YoefQA1oBMFaFizLZ6mqaT5duAPS9P90OUUHSLG6x3aewygG2LNiUg+ao3s+4W6/LduygN+bngIFQDQNQybimsm00yFLnxuD7IyVNSoHPq0MVKi9c6QLPei6+F5aRgAgD0IEe2RNHKOyO7QJ/aLAQBHqGLYFAAAGKD/AWgSF2EjjA0EAAAAAElFTkSuQmCC"/></defs><g id="surface3"><use xlink:href="#image6"/></g></svg></span>`;
      lines += line;
    }
    container.html(lines);
  }
  // вставить менюшки
  async insert_footer_menu(){
    // меню 1
    var line_all = '';
    Data_vars.footer_menu_data.forEach(function(item, index, array){
      var line = `
        <div class='footer-section-1-item' style='margin-top: ${40 + index * 25}px;'>
          <div></div>
          <span><a href='${item[1]}' target='_blank'>${item[0]}</a></span>
        </div>
      `;
      line_all += line;
    });
    line_all += `<div class='footer-section-1-line' style='height: ${25 * (Data_vars.footer_menu_data.length - 1) + 1}px;'></div>`;
    Event_vars.footer.find('.footer-section-1').append(line_all);
    // меню 2 (соц сети)
    var line_all = '';
    Data_vars.footer_menu_soc_seti.forEach(function(item, index, array){
      var line = `
        <div class='footer-right-section-2-item' style='margin-left: ${73 + index * 58}px;'>
          <a href='${item[0]}' target='_blank' rel="noopener"><img src='${item[1]}' ondragstart="return false;"></a>
        </div>
      `;
      line_all += line;
    });
    Event_vars.footer.find('.footer-right-sector-2').append(line_all);
    // меню 3 (самое нижнее)
    var year_now = new Date();
    var line_all = `<div class="site_text">© Maphouse ${year_now.getFullYear()}</div>`;
    Data_vars.footer_down_menu_data.forEach(function(item, index, array){
      var line = `
        <div class='footer-down_menu-item' style='margin-left: ${195 + index * 180}px;'>
          <a href='${item[1]}' target='_blank'>${item[0]}</a>
        </div>
      `;
      line_all += line;
    });
    Event_vars.footer.find('.footer-down_menu').append(line_all);
  }
  // добавить емаил в рассылку
  async add_to_mailing_list(){
    var container = Event_vars.footer.find('div[dn="newsletter"]');
    var email = container.find('input').val();
    // проверка на то, что уже он есть
    if (Data_vars.email_unique.includes(email)){
      var index = Data_vars.email_unique.indexOf(email);
      Ui_page.button_firework_message(Data_vars.email_unique_messages[index][0], Data_vars.email_unique_messages[index][1]);
      return;
    }
    var check = await Data_vars.check_right_email(email);
    if (check[0]){
      // написано правильно, отправляем на сервер
      var url = '/service/add_email_to_mailing_list';
      var data_file = new FormData();
      data_file.append("email", email);
      var response = await Request.request_for_json_post(url, data_file, true);
      Data_vars.email_unique.push(email);
      if (response.status == 'ok'){
        Data_vars.email_unique.push(email);
        Ui_page.button_firework_message(true, response.message);
        Data_vars.email_unique_messages.push([true, response.message]);
        Ui_page.button_firework();
      }
      else{
        Data_vars.email_unique_messages.push([false, response.message]);
        Ui_page.button_firework_message(false, response.message);
      }
    }
    else{
      // написано неправильно, выводим ошибку
      Ui_page.button_firework_message(false, check[1]);
    }
  }
  // вывод ошибки или успеха
  async button_firework_message(act, message){
    var button = Event_vars.footer.find('div[dn="newsletter"]').find('div[dn="message"]');
    button.html('<div></div>' + message);
    if (act){ button.css({'background': 'var(--green_light)'});}else{ button.css({'background': 'var(--red_main)'}); }
    setTimeout(function(){
      var width = button.width();
      Data_vars.newsletter_message_open = true;
      button.css({'margin-left': Math.min(Math.floor((255 - width) / 2), 255 - width), 'display': 'inline'});
    }, 1)
  }
  // анимация салюта
  async button_firework(e){
    for(var i=0; i < 30; i++){
      Ui_page.button_firework_createParticle();
    }
  }
  async button_firework_createParticle(){
    var container = document.getElementsByClassName('particle')[0];
    var particle = document.createElement('particle1');
    container.appendChild(particle);
    var size = Math.floor(Math.random() * 20 + 5);
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    particle.style.background = `hsl(${Math.random() * 90 + 180}, 70%, 60%)`;
    var color_array = ['var(--green_light)', '#FACC2E', '#A9F5E1'];
    particle.style.background = color_array[Math.floor(Math.random() * color_array.length)];
    const destinationX = (Math.random() - 0.5) * 2 * 75;
    const destinationY = (Math.random() - 0.5) * 2 * 75;
    const animation = particle.animate([
      {
        transform: `translate(${0 - (size / 2)}px, ${0 - (size / 2)}px)`,
        opacity: 1
      },
      {
        transform: `translate(${destinationX}px, ${destinationY}px)`,
        opacity: 0
      }
    ], {
      duration: 500 + Math.random() * 1000,
      easing: 'cubic-bezier(0, .9, .57, 1)',
      delay: Math.random() * 200
    });
    animation.onfinish = () => {
      particle.remove();
    };
  }
}

// вспомогательные функции для экспорта в excel
class Useful_Functions_Excel{
  update_width_columns(worksheet, width_array){
    worksheet.columns.forEach(function(column, index){ column.width = width_array[index]; });
    return worksheet;
  }
  save_excel(workbook, filename){
    workbook.xlsx.writeBuffer().then((data) => {
      var blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
      saveAs(blob, filename);
    });
  }
  create_worksheet(workbook, sheetname, header_values, table_data, header_color, width_columns, align='center'){
    var worksheet = workbook.addWorksheet(sheetname);
    // добавляем заголовок
    var titleRow = worksheet.addRow(header_values);
    titleRow.font = {name: 'Arial Regular', family: 2, size: 9, bold: true, color: {argb: "00000000"}};
    titleRow.height = 50;
    titleRow.eachCell(function(cell, colNumber){
      var background = (colNumber % 2 == 1) ? header_color[0] : header_color[1];
      cell.alignment = {vertical: 'middle', horizontal: align, wrapText: true};
      cell.fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: background}};
    });
    // изменяем ширину (как в таблице на сайте)
    this.update_width_columns(worksheet, width_columns);
    // вставляем всю таблицу
    var bodyRows = worksheet.addRows(table_data);
  }
  create_and_save_workbook(filename, sheetname, header_values, table_data, header_color=['FFFFCC', 'FFF599'], width_columns=create_array_true(79, 20)){
    // создаём документ и добавляем туда листок таблицы
    var workbook = new ExcelJS.Workbook();
    this.create_worksheet(workbook, sheetname, header_values, table_data, header_color, width_columns);
    // сохраняем
    this.save_excel(workbook, filename);
  }
}


// инициализация классов
Request = new Request_class();
Data_vars = new Data_vars_class();
Event_vars = new Event_vars_class();
Ui_page = new Ui_page_class();
UFE = new Useful_Functions_Excel();

// главные изменения
if (user_auth.status == 'True'){
  var container_login = Event_vars.header.find('.header-menu-account');
  container_login.html(`<a href='/personal_area'><button class='header-menu-account-button'>${user_auth.email.toString()[0].toUpperCase()}</button></a>`);
  Event_vars.header.find('.header-menu-apps_button').css({'margin-left': 'calc(100vw - 217px)'});
  container_login.css({'margin-left': 'calc(100vw - 46px * 2 - 59px - 7px)'});
}

// события при наведении, и т.д.
async function window_events(){
  // ---- переменные экрана
  var wh = window.innerHeight; var ww = window.innerWidth;
  var wh_half = Math.round(wh / 2); var ww_half = Math.round(ww / 2);
  // -------------------- работа с функциями самого документа
  $(document).on('click', function(event){
    // проверка при скрытии окна фильтров
    if (Data_vars.sector2_open_filter != undefined){
      var input = Event_vars.sector2_block_2_container_input;
      var container_values = Event_vars.sector2_filters_container;
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        container_values.remove();
        Event_vars.sector2.find(`#sector2_block_2_item_${Data_vars.sector2_open_filter}`).find('.sector2-block-2-item-select_arrow').css({'transform': 'rotate(0deg)'});
        Data_vars.sector2_open_filter = undefined;
      }
    }
    // проверка при скрытии окна фильтров графиков
    if (Event_vars.sector4_filter_window_open.includes(true)){
      var index = Event_vars.sector4_filter_window_open.indexOf(true);
      var container = Event_vars.sector4.find(`#chart_container_${index + 1}`);
      var input = container.find('.sector4-chart_container-filter1-select');
      var container_values = container.find('.sector4-chart_container-filter1-select_container');
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        container_values.remove();
        input.find(`img`).css({'transform': ''});
        Event_vars.sector4_filter_window_open = [false, false];
      }
    }
    // проверка при скрытии окна изменения количества строк в таблице
    if (Event_vars.window_change_hp_open){
      var input = Event_vars.sector5.find('div[dn="page_text"]').find('span');
      var container_values = Event_vars.sector5.find('.change_hp_window');
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        container_values.remove();
        Event_vars.window_change_hp_open = false;
      }
    }
    // открыта оповещение рассылки
    if (Data_vars.newsletter_message_open){
      var input = Event_vars.footer.find('div[dn="newsletter"]').find('div[dn="message"]');
      var container_values = Event_vars.footer.find('div[dn="newsletter"]');
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        input.css({'display': 'none'});
        Event_vars.newsletter_message_open = false;
      }
    }
    // закрыть окошко фильтра при таблице
    if (Data_vars.sector5_container_filter_values){
      var input = Event_vars.sector5.find('div[dn="container"]');
      var container_values = Event_vars.sector5.find('div[dn="button"]');
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        input.css({'display': 'none'});
        container_values.find('div').css({'transform': ''});
        Data_vars.sector5_container_filter_values = false;
      }
    }
  });
  $(document).on('mouseup', function(event){
    // выключаем отслеживание
    if (Event_vars.sector2_block1_toggle.pressed.includes(true)){ Data_vars.apply_filters(); }
    Event_vars.sector2_block1_toggle.pressed = create_array_true(6, false);
    // если изменилась скривлённость линий в диаграммах, то обновляем их
    if (Event_vars.sector4_filter_toggle_pressed.includes(true)){
      var index = Event_vars.sector4_filter_toggle_pressed.indexOf(true);
      var new_tension_value = Data_vars.sector4_charts_filter2[index];
      if (index == 0){ var chart = Data_vars.chart_1; }else{ var chart = Data_vars.chart_2; }
      chart.options.elements.line.tension = new_tension_value;
      chart.update();
    }
    Event_vars.sector4_filter_toggle_pressed = [false, false];
    Event_vars.animation_time_wait_change = false;
    // ширина колонки таблицы
    if (Event_vars.change_width_column != undefined){
      document.body.style.cursor = 'auto';
      Event_vars.change_width_column = undefined;
    }
  });
  $(document).on('mousemove', function(event){
    // анимируем главную картинку
    /*
    var image = Event_vars.sector1.find('.sector1-image');
    var diffX = 650 - Math.min(event.pageX, 1300); var diffY = 500 - Math.min(event.pageY, 1000);
    image.css({'transform': `translate3d(${- diffX / 20}px, ${- diffY / 20}px, 0px)`, 'transition': '0.1s'});
    */
    // если нажата кнопка фильтра сектора 2
    if (Event_vars.sector2_block1_toggle.pressed.includes(true)){
      var x = event.pageX;
      var number_toggle = Event_vars.sector2_block1_toggle.pressed.indexOf(true);
      var line_x = Event_vars.sector2.find(`#sector1-line_toggle${Math.floor(number_toggle / 2)}`).offset().left;
      if (number_toggle % 2 == 0){
        var toggle2_location = Event_vars.sector2_block1_toggle.numbers[number_toggle + 1];
        if (x < line_x){ Event_vars.sector2_block1_toggle.numbers[number_toggle] = 37; }
        else if (x > line_x + toggle2_location - 37 - 23){ Event_vars.sector2_block1_toggle.numbers[number_toggle] = toggle2_location - 23; }
        else{ Event_vars.sector2_block1_toggle.numbers[number_toggle] = x - line_x + 37; }
      }
      else if (number_toggle % 2 == 1){
        var toggle1_location = Event_vars.sector2_block1_toggle.numbers[number_toggle - 1];
        if (x < line_x + toggle1_location - 37 + 23){ Event_vars.sector2_block1_toggle.numbers[number_toggle] = toggle1_location + 23; }
        else if (x > line_x + 270){ Event_vars.sector2_block1_toggle.numbers[number_toggle] = 307; }
        else{ Event_vars.sector2_block1_toggle.numbers[number_toggle] = x - line_x + 37; }
      }
      Event_vars.sector2.find(`#sector1-toggle${number_toggle}`).css({'margin-left': Event_vars.sector2_block1_toggle.numbers[number_toggle]});
      var limits = Data_vars.sector2_items_array_block_1[Math.floor(number_toggle / 2)][1];
      if (number_toggle % 2 == 0){
        var new_number = Math.round(limits[0] + (Event_vars.sector2_block1_toggle.numbers[number_toggle] - 37) / (270 - 23) * (limits[1] - limits[0]));
      }else if (number_toggle % 2 == 1){
        var new_number = Math.round(limits[0] + (Event_vars.sector2_block1_toggle.numbers[number_toggle] - 37 - 23) / (270 - 23) * (limits[1] - limits[0]));
      }
      // сохраняем и показываем
      Event_vars.sector2.find(`#sector1-toggle${number_toggle}`).find('.sector2-block-1-item-toggle_container-text').html(new_number);
      Event_vars.sector2_block1_toggle.limits[Math.floor(number_toggle / 2)][number_toggle % 2] = new_number;
    }
    // кнопка изменения скорости анимации
    if (Event_vars.animation_time_wait_change){
      var x = event.pageX;
      var container = Event_vars.sector3.find(`div[dn="speed_animation"]`);
      var line_x = container.find('div[dn="line"]').offset().left;
      var toggle = container.find('div[dn="toggle"]');
      if (x < line_x){ var margin_left = -5; }
      else if (x > line_x + 71){ var margin_left = -5 + 71; }
      else{ var margin_left = -5 + x - line_x; }
      Event_vars.animation_time_wait = 1000 - ((margin_left + 5) / 71) * 900;
      toggle.css({'margin-left': margin_left});
    }
    // если нажата кнопка фильтра сектора 4
    if (Event_vars.sector4_filter_toggle_pressed.includes(true)){
      var x = event.pageX;
      var index = Event_vars.sector4_filter_toggle_pressed.indexOf(true);
      var container = Event_vars.sector4.find(`#chart_container_${index + 1}`);
      var line_x = container.find('.sector4-chart_container-filter2-line').offset().left;
      var toggle = container.find('.sector4-chart_container-filter2-toggle');
      if (x < line_x){ var margin_left = 430; }
      else if (x > line_x + 78){ var margin_left = 430 + 78; }
      else{ var margin_left = 430 + x - line_x; }
      Data_vars.sector4_charts_filter2[index] = ((margin_left - 430) / 78) * 0.4 + 0.001;
      toggle.css({'margin-left': margin_left});
    }
    // изменение ширины столбца таблицы
    if (Event_vars.change_width_column != undefined){
      var index = Event_vars.change_width_column;
      var x = event.pageX;
      var min_width = Data_vars.sector5_width_of_items_min[index];
      var column = Event_vars.sector5.find(`.tb${index}`);
      var width_old = Data_vars.sector5_width_of_items[index];
      var width = x - column.offset().left - 5;
      if (Data_vars.sector5_width_of_items_min[index] <= width){
        if (width > 500){ var width = 500; }
        Data_vars.sector5_width_of_items[index] = width;
        column.css({'width': width});
        Data_vars.sector5_sum_width += width - width_old;
        Event_vars.sector5.find('#width_of_columns').html(`.t_div{width: ${Data_vars.sector5_sum_width}px;}`);
      }
    }
    // если открыто окно параметров при карте
    if (Event_vars.open_params_window && Event_vars.open_params_window_timer){
      var circle = Event_vars.sector3.find('.map-params');
      var button = Event_vars.sector3.find('.map-settings_button');
      if (event.target != button[0] && button.has(event.target).length == 0 && circle.has(event.target).length == 0 && event.target != circle[0]){
        circle.css({'height': 0, 'width': 0, 'margin-top': -20, 'margin-left': 'calc(100% - 100px)'});
        circle.find('div[dn="container"]').css({'margin-top': 90, 'margin-left': -124});
        var circle_back = Event_vars.sector3.find('.map-params-back');
        circle_back.css({'height': 0, 'width': 0, 'margin-top': -20, 'margin-left': 'calc(100% - 100px)'});
        Event_vars.open_params_window = false;
      }
    }
    // если открыто окно цен на квартиры при таблице
    if (Event_vars.window_cost_is_open[0] && Event_vars.window_cost_is_open[2] == undefined){
      var index = Event_vars.window_cost_is_open[1];
      if (index == 'map_index'){ var input = Event_vars.sector3.find(`.sector3-window_inf-cost`); }
      else{ var input = Event_vars.sector5.find(`span[c_index="${index}"]`); }
      var container_values = Event_vars.sector5.find('.sector5-popup_window');
      if (event.target != container_values[0] && container_values.has(event.target).length == 0 && input.has(event.target).length == 0 && event.target != input[0]){
        Event_vars.window_cost_is_open[2] = setTimeout(Ui_page.hide_a_cost, 300);
      }
    }
  });
  $(window).on('resize', (e) => {
    Ui_page.insert_back_houses();
  });
  // -------------------- шапка
  Event_vars.header.find('.header-menu-arrow-container').on('mouseenter', function(){
    Event_vars.header.find('.header-menu-shadow' + $(this).attr('data_number')).css({'box-shadow': '0px 0px 8px var(--green_light)'});
  }).on('mouseleave', function(){
    Event_vars.header.find('.header-menu-shadow' + $(this).attr('data_number')).css({'box-shadow': ''});
  });
  // меняем картинку меню при наведении
  Event_vars.header.find('.header-menu-apps_button').on('mouseenter', function(){
    $(this).attr('src', '/static/img/housing_stock/header_menu_apps_blue.png');
  }).on('mouseleave', function(){
    $(this).attr('src', '/static/img/housing_stock/header_menu_apps.png');
  });
  // 3дшное отображение кнопки вход
  if (user_auth.status == 'False'){
    Event_vars.header.find('.header-menu-account').find('div[dn="rect"]').on('mousemove', function(event){
      var el = $(this).find('div[dn="container"]');
      var x = event.pageX - el.offset().left; var y = event.pageY - el.offset().top;
      var sin = (38/2 - y) / (38/2); var cos = -(89/2 - x - 2) / (89/2);
      var deg = Math.max(Math.abs(Math.floor(sin * 30)), Math.abs(Math.floor(cos * 32)));
      el.css({'transform': `rotate3d(${sin}, ${cos}, 0, ${deg}deg)`});
      setTimeout(function(){ el.css({'transition': 'none'}); }, 1);
    }).on('mouseleave', function(event){
      var el = $(this).find('div[dn="container"]');
      el.css({'transition': '0.2s'});
      setTimeout(function(){ el.css({'transform': 'rotate3d(0, 0, 0, 0deg)'}); }, 1)
    }).on('click', function(){
      var el = $(this).find('div[dn="container"]');
      el.css({'transform': 'scale(0.7)', 'transition': '0.07s'});
      setTimeout(function(){ el.css({'transform': 'scale(1.0)'}); }, 70);
    });
  }
  // ----------- sector 1
  // -------------------- сектор 2
  // перетаскиваем фильтры с кружочками
  Event_vars.sector2.find('.sector2-block-1-item-toggle_container-toggle').on('mousedown', function(event){
    Event_vars.sector2_block1_toggle.pressed[Number($(this).parent().attr('id').split('sector1-toggle')[1])] = true;
  });
  // появляется синее окошко
  Event_vars.sector3.find('.map-settings_button').on('mouseenter', async function(e){
    var circle = Event_vars.sector3.find('.map-params');
    var circle_back = Event_vars.sector3.find('.map-params-back');
    circle.css({'height': 500, 'width': 500, 'margin-top': -250, 'margin-left': 'calc(100% - 350px)'});
    circle_back.css({'height': 500, 'width': 500, 'margin-top': -250, 'margin-left': 'calc(100% - 350px)'});
    circle.find('div[dn="container"]').css({'margin-top': 320, 'margin-left': 126});
    Event_vars.open_params_window = true;
    Event_vars.open_params_window_timer = false;
    setTimeout(async function(){Event_vars.open_params_window_timer = true;}, 100);
  });
  // -------------------- сектор 3
  Event_vars.sector3.find('div[dn="toggle"]').on('mousedown', function(event){
    if (Event_vars.animation_started){ Event_vars.animation_time_wait_change = true; }
  });
  // -------------------- сектор 5
  Event_vars.sector5.find('.sector5-download').on('mouseenter', function(event){
    var container = $(this);
    var x = event.pageX; var y = event.pageY;
    var offset = container.offset();
    var el = container.find('.sector5-download-hover');
    var margin_top = y - offset.top; var margin_left = x - offset.left;
    // пишем свойства
    container.find('img').attr('src', '/static/img/housing_stock/download_table_white.png');
    el.css({'transition': 'none'});
    el.css({'margin-top': margin_top, 'margin-left': margin_left});
    setTimeout(function(){
      el.css({'transition': '0.2s'});
      el.css({'height': 500, 'width': 500, 'margin-top': margin_top - 250, 'margin-left': margin_left - 250});
    }, 1);
  }).on('mouseleave', function(event){
    var container = $(this);
    var x = event.pageX; var y = event.pageY;
    var offset = container.offset();
    var el = container.find('.sector5-download-hover');
    var margin_top = y - offset.top; var margin_left = x - offset.left;
    // пишем свойства
    container.find('img').attr('src', '/static/img/housing_stock/download_table.png');
    el.css({'transition': 'none'});
    el.css({'margin-top': margin_top - 250, 'margin-left': margin_left - 250});
    setTimeout(function(){
      el.css({'transition': '0.2s'});
      el.css({'height': 0, 'width': 0, 'margin-top': margin_top, 'margin-left': margin_left});
    }, 1);
  });
  // ввод поля при таблице
  Event_vars.sector5.find('.sector5-input').on('focus keyup', function(){
    var text = $(this).val();
    // фильтрация
    Data_vars.filter_by_input_table_text = text.toLowerCase();
    Data_vars.apply_filters();
  });
  // отслеживаем нажатие
  Event_vars.sector3.find('.map-params').find('.map_label').find('input').on('change', function(){
    Ui_page.check_district_map($(this).parent().parent().index() - 1);
  });
  // удаляем таймер у окна цен при таблице
  Event_vars.sector5.find('.sector5-popup_window').on('mouseenter', function(){
    clearTimeout(Event_vars.window_cost_is_open[2]);
    Event_vars.window_cost_is_open[2] = undefined;
  });
}


$(async function(){
  // вставляем верхнее меню
  Ui_page.insert_the_top_menu();
  // вставляем фильтры в сектор 2
  Ui_page.insert_filters_the_sector2();
  // вставляем карту в сектор 3
  Ui_page.insert_map_the_sector3();
  // загружаем данные
  await Data_vars.load_data();
  // вставляем метки на карте
  Ui_page.insert_ans_show_house_markers();
  // загружаем библиотеку диаграмм
  dhtmlLoadScript('/static/js/chart/chart.js', function(){
    // делаем диаграммы
    Ui_page.create_charts();
    Ui_page.update_charts();
    // вставляем макет графика в окно цены при таблице
    Ui_page.create_maket_cost_chart();
  });
  // вставляем параметры ввода при таблице
  Ui_page.insert_params_to_params_container();
  // вставляем переключатели на окно цены
  Ui_page.create_checkboxes_in_cost_window();
  // вставляем таблицу
  Ui_page.preparing_to_create_a_table(true, true, true);
  // доделываем footer
  Ui_page.insert_back_houses();
  Ui_page.insert_footer_menu();
  // запускаем обработку событий
  window_events();
  // работа с изображениями
  $('img').attr('ondragstart', "return false;");
  $('img').attr('alt', '""');
});



// end.
