# -*- coding: utf-8 -*-
import os, sys, time, requests
# change envieron
delimeter = '\\' if os.name == 'nt' else '/'
path_list = os.getcwd().split(delimeter)
new_path = delimeter.join(path_list[:len(path_list) - 1])
sys.path.append(new_path)
# settings django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)
from datetime import datetime
from main.models import Districts
from random import randint

# new normal way
os.chdir(new_path)

header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}

url = 'https://ufa.antiagent.ru/xml/ufa.xml?v=1.21'
html = str(requests.get(url, headers = header).text)

elements = html.split('<ymaps:GeoObject>')
del elements[0]

for el in elements:
    title = el.split("<gml:name>")[1].split("</gml:name>")[0]
    data_xy = el.split('<gml:posList>')[1].split("</gml:posList>")[0].split()
    g_data = []
    for i in range(0, len(data_xy), 2):
        x = float(data_xy[i])
        y = float(data_xy[i + 1])
        g_data += [[y, x]]
    # saving
    district = Districts.objects.create(
        title = title,
        coordinates = g_data
    )
    district.save()
