# -*- coding: utf-8 -*-
# ================== настройка django ===================
import os, sys
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)
# =======================================================
# IMPORTS CLASSES
from main.models import New_buildings
# my imports
import requests, time, os, sys, asyncio, json, datetime
from bs4 import BeautifulSoup as BS
from threading import Thread
from random import random, randint, choice, shuffle
from fp.fp import FreeProxy


user_agents = []
header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}
proxies = {"http"  : '', "https" : ''}
random_sites = ['https://yandex.ru', 'https://google.com', 'https://mail.ru/', 'https://youtube.com/', 'https://useragents.ru/', 'https://youtube.com/', 'https://kmb.cybber.ru', 'https://stackoverflow.com/', 'https://python-scripts.com/', 'http://turfjs.org/', 'https://glyphicons.com/', 'https://html-color-codes.info']


def save_image(url):
    similar_url_yandex = f'https://yandex.ru/images/search?rpt=imageview&url={url}'
    response = requests.get(similar_url_yandex, headers=header).text
    print(response)
    time.sleep(1000)


objects = New_buildings.objects.all()

for object in objects:
    urls = object.images['photos']['big_quality']
    for url in urls:
        save_image(url)
