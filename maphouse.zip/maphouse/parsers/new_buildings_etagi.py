# -*- coding: utf-8 -*-
import os, sys, time, requests, json
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)
from datetime import datetime
from main.models import New_buildings
from random import randint, choice, random

header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}

url = 'https://ufa.etagi.com/zastr/'
html = str(requests.get(url, headers = header).text)

elements = html.split('{"count_1":')
del elements[0]
del elements[len(elements) - 1]

links = []
# получаем ссылки на объекты
for el in elements:
    parsed_site = 'etagi'
    el = '{"count_1":' + el.strip(',')
    try:
        el = json.loads(el)
    except:
        continue
    title = el['meta']['newcomplex']
    street = el['meta']['street']
    inf = {'developer': el['builder'], 'deadline': el['deadline'], 'walls': el['meta']['walls'], 'district': el['meta']['district'], 'object_id': el['object_id']}
    apartments = {}
    apartments_min_price = {}
    for i in range(1, 6):
        try:
            value1 = el['min_price_' + str(i)]
            value2 = el['min_square_' + str(i)]
        except:
            continue
        if value1 is not None:
            apartments_min_price[i] = [int(float(value1)), int(float(value2))]
    # получаем ссылку на объект
    parsed_site_link = 'https://ufa.etagi.com/zastr/jk/' + str(el['nntr']) + '-' + str(el['object_id']) + '/'
    # получаем html
    html = str(requests.get(parsed_site_link, headers = header).text)
    # фотографии новостройки
    imgs_links = list(map(lambda x: 'http:' + x.split('style="background-image: url(')[1].split(')')[0], html.split('class="mediaslider__slide mediaslider__slide--rest"')))
    del imgs_links[0]
    coordinates = list(map(float, imgs_links[0].split('?center=')[1].split('&')[0].split(',')))
    del imgs_links[0]
    inf['latlng'] = coordinates
    photo = imgs_links
    photo_quality = list(map(lambda x: 'https://cdn.esoft.digital/19201080/' + '/'.join(x.split('cdn.esoft.digital/')[1].split('/')[1:]), photo))
    # дополняем информацию
    price_min = html.split('<div class="desk-object-main-info_right-side"><div><div class="_3wbi">от <span>')[1].split('<')[0]
    price_min_m2 = html.split('<div class="_1Jex">от <span>')[1].split('<')[0]
    inf['price'], inf['price_m2'] = price_min, price_min_m2
    # детальная информация
    detals_inf = {}
    el_detals = html.split('<div class="Unp6">')
    del el_detals[0]
    for el_detal in el_detals:
        el_d1 = el_detal.split('<span class="_14Sc">')[1].split('<')[0]
        el_d2 = el_detal.split('<span class="_3DGh">')[1].split('<')[0]
        detals_inf[el_d1] = el_d2
    detailed_information = detals_inf
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=- saving
    try:
        El = New_buildings.objects.get(title = title)
        El.title = title,
        El.street = street,
        El.photo = photo,
        El.photo_quality = photo_quality,
        El.inf = inf,
        El.apartments = apartments,
        El.apartments_min_price = apartments_min_price,
        El.detailed_information = detailed_information,
        El.parsed_site = parsed_site,
        El.parsed_site_link = parsed_site_link
    except:
        El = New_buildings.objects.create(
            title = title,
            street = street,
            photo = photo,
            photo_quality = photo_quality,
            inf = inf,
            apartments = apartments,
            apartments_min_price = apartments_min_price,
            detailed_information = detailed_information,
            parsed_site = parsed_site,
            parsed_site_link = parsed_site_link
            )
    El.save()
    time.sleep(randint(1, 2))



# python new_buildings_etagi.py
