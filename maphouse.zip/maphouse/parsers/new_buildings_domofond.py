# -*- coding: utf-8 -*-
# ================== настройка django ===================
import os, sys
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)
# =======================================================
# IMPORTS CLASSES
from main.models import New_buildings
# my imports
import requests, time, os, sys, asyncio, json, datetime
from bs4 import BeautifulSoup as BS
from threading import Thread
from random import random, randint, choice, shuffle
from fp.fp import FreeProxy


user_agents = []
header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}
proxies = {"http"  : '', "https" : ''}
random_sites = ['https://yandex.ru', 'https://google.com', 'https://mail.ru/', 'https://youtube.com/', 'https://useragents.ru/', 'https://youtube.com/', 'https://kmb.cybber.ru', 'https://stackoverflow.com/', 'https://python-scripts.com/', 'http://turfjs.org/', 'https://glyphicons.com/', 'https://html-color-codes.info']

# ============================= functions ==============================
def normal_price(price):
    return int(float( ''.join(price.split()) ))

def price_visible(price):
    price = list(str(price))[::-1]
    ln = len(price)
    result = []
    for i in range(0, ln, 3):
        result = [''.join(price[i : min(i+3, ln)][::-1])] + result
    return ' '.join(result)

# ---------------------------------- SITES -----------------------------------
# рандомный агент
def choice_useragent(change_header = False):
    global user_agents
    if user_agents == []:
        user_agents = open('user_agents/list.txt', 'r').readlines()
    ug = choice(user_agents).rstrip('\n')
    if change_header:
        global header
        header['User-Agent'] = ug
    return ug

# нормальный url
def normal_url(url):
    if url == url.lstrip('http'):
        url = 'http:' + url
    return url

# запрос на рандомный сайт
def random_site_request():
    try:
        htmlfff = requests.get(choice(random_sites), headers = header)
        return {'status': 'ok'}
    except:
        return {'status': 'error'}

# ---------------------------------- PROXY -----------------------------------
# находим рабочий прокси
def get_proxy(proxies_change = False, timeout = 0.4):
    proxy = FreeProxy(country_id=['US', 'BR'], timeout = timeout, rand = True).get()
    if proxies_change:
        global proxies
        proxies = {'http': proxy, 'https': proxy}
    return proxy

# парсим изображения с яндекса
def get_list_images_yandex(text, use_proxy = False, new_proxy = False, quantity = 5):
    url = 'https://yandex.ru/images/search?from=tabbar&text=' + text
    if use_proxy:
        if new_proxy:
            get_proxy(proxies_change = True)
    choice_useragent(change_header = True)
    if use_proxy:
        html = str(requests.get(url, headers = header, proxies = proxies).text)
    else:
        html = str(requests.get(url, headers = header).text)
    soup = BS(html, 'html.parser')
    imgs = soup.find_all('div', class_='serp-item')
    if len(imgs) < quantity:
        print('error to yandex images')
        get_list_images_yandex(text, use_proxy = use_proxy, new_proxy = new_proxy, quantity = quantity)
    # словарь с картинками
    data = {'min_quality': [], 'big_quality': []}
    # проходимся по изображениям и сохраняем ссылки
    for img in imgs:
        data_bem = json.loads(img['data-bem'])
        photo_min_quality = normal_url(data_bem['serp-item']['thumb']['url'])
        photo_big_quality = normal_url(data_bem['serp-item']['preview'][0]['url'])
        data['min_quality'] += [photo_min_quality]
        data['big_quality'] += [photo_big_quality]
    return data

# ========================================================================

index = 0
objects = []

# функция, которая собирает информацию по одному объекту
def parse_domofond_build(url_build_domofond):
    global objects
    # ================ ЗАПРАШИВАЕМ HTML ДЛЯ ПОЛНОЙ ИНФОРМАЦИИ =================
    # меняем агент пользователя
    choice_useragent(change_header = True)
    # получаем html с объектом новостройки
    html = str(requests.get(url_build_domofond, headers = header).text)
    # преобразовываем данные в json формат
    dictic = json.loads( html.split('window.__INITIAL_DATA__ = ')[1].split('</script>')[0] )
    # =========================== ГЛАВНАЯ ИНФОРМАЦИЯ =========================
    item = dictic['itemState']['item']
    title = item['title']
    coordinates = [item['location']['latitude'], item['location']['longitude']]
    # ---------------- identify
    identify = {}
    identify['city'] = item['city']['name']
    identify['region'] = item['region']['name']
    identify['administrative_district'] = item['district']['name']
    identify['realtor_district'] = ''
    identify['title'] = item['title']
    identify['address'] = item['address']
    identify['liter'] = ''
    identify['composition_liter'] = ''
    identify['site_project'] = ''
    identify['cadastral_number'] = ''
    identify['developer'] = item['developerName']
    identify['developer_ul'] = ''
    identify['contact_email'] = item['developmentContactEmail']
    identify['contact_tel'] = item['developmentContactNumber']
    identify['documents'] = list(map(lambda el: {'title': el['name'], 'download_link': el['downloadUrl']}, item['developmentDocuments']))
    # ---------------- characteristic
    characteristic = {}
    characteristic['conditional class'] = ''
    characteristic['sales_status'] = ''
    characteristic['date_start_CMP'] = ''
    characteristic['deadline'] = list(filter(lambda el: el['name'] == 'Срок сдачи', item['details']))[0]['value']
    characteristic['willingness'] = ''
    characteristic['finishing_level'] = ''
    characteristic['type_contract'] = ''
    # ---------------- actualization
    actualization = {'flat_formats': {'others': [], 'statistic': {}}}
    quantity_rooms_statistic = []
    for flat in item['developmentPlans']:
        if not flat['isStudio'] and not flat['isFreePlan']:
            try:
                type_flat = int(flat['roomsOrdinal'])
                quantity_rooms_statistic.append(type_flat)
            except:
                actualization['flat_formats']['others'].append(flat)
                continue
        elif flat['isStudio']:
            type_flat = 'studio'
        else:
            actualization['flat_formats']['others'].append(flat)
            continue
        try:
            actualization['flat_formats'][type_flat] = {'min_area': flat['minArea'], 'max_area': flat['maxArea'], 'min_price': flat['minPrice'], 'max_price': flat['maxPrice']}
            delta_price = sorted([round(flat['minPrice'] / flat['minArea'], 4), round(flat['maxPrice'] / flat['maxArea'], 4)])
            actualization['flat_formats'][type_flat]['unit_price'] = {'min_delta_price': delta_price[0], 'medium_delta_price': round(sum(delta_price) / 2, 4), 'max_delta_price': delta_price[1]}
            actualization['flat_formats'][type_flat]['status'] = True
        except:
            actualization['flat_formats'][type_flat] = {'status': False}
    if len(quantity_rooms_statistic) > 0:
        actualization['flat_formats']['statistic'] = {'min_quantity_rooms': min(quantity_rooms_statistic), 'max_quantity_rooms': max(quantity_rooms_statistic)}
    actualization['quantity_rooms_from_developer'] = ''
    actualization['quantity_rooms_from_agency'] = ''
    actualization['price_1_parking_place'] = ''
    actualization['date_update'] = datetime.datetime.now().strftime('%d-%m-%Y %H-%M-%S')
    # ---------------- technical_characteristic
    technical_characteristic = {}
    technical_characteristic['constructive'] = {'construction_technology': '', 'exterior_wall_material': ''}
    technical_characteristic['quantity_section'] = ''
    technical_characteristic['storeys'] = {'min': '', 'madium': '', 'max': ''}
    technical_characteristic['ceiling_height'] = ''
    technical_characteristic['parking'] = {'type_parking': '', 'parking_area': '', 'quantity_place': {'in_parking': '', 'guest': '', 'all': ''}}
    technical_characteristic['elevators'] = {'quantity_elevators_all': '', 'passenger_elevators_quantity': '', 'cargo_elevators_quantity': '', 'elevators_mark': ''}
    technical_characteristic['plot'] = {'sum_area_plot': '', 'liter_area_plot': '', 'building_plot': '', 'improvement_plot': ''}
    technical_characteristic['sum_area_apartments'] = ''
    technical_characteristic['quantity_flats_in_project'] = {1: '', 2: '', 3: '', 4: '', 'studio': '', 'others': ''}
    technical_characteristic['uninhabited_area'] = ''
    technical_characteristic['MOP_area'] = ''
    technical_characteristic['energy_efficiency'] = ''
    technical_characteristic['estimated_cost_building'] = ''
    # ---------------- class_indicators
    class_indicators = {}
    class_indicators['site'] = ''
    class_indicators['plot'] = ''
    class_indicators['improvement'] = ''
    class_indicators['parking'] = ''
    class_indicators['MOP'] = ''
    class_indicators['elevators'] = ''
    class_indicators['medium_quantity_flat_in_floor'] = ''
    class_indicators['medium_area_flat'] = ''
    class_indicators['architecturally'] = ''
    class_indicators['engineering_equipment'] = ''
    class_indicators['volumetric_planning_solutions'] = ''
    # ============================ ФОТОГРАФИИ =================================
    # просто тупо копируем с domofond
    images = {'photos': {'min_quality': [], 'medium_quality':[], 'big_quality': []},
              'plan':   {'min_quality': [], 'medium_quality':[], 'big_quality': []},
              'flats':   {'min_quality': [], 'medium_quality':[], 'big_quality': []}}
    try:
        for photo_galery in item['galleries']:
            photo_images = photo_galery['images']
            images['photos']['min_quality'] += list(map(lambda x: x[0]['url'], photo_images))
            images['photos']['medium_quality'] += list(map(lambda x: x[1]['url'], photo_images))
            images['photos']['big_quality'] += list(map(lambda x: x[2]['url'], photo_images))
    except:
        pass
    try:
        images['plan']['min_quality'] += [item['developmentSitePlanUrl'][0]['url']]
        images['plan']['medium_quality'] += [item['developmentSitePlanUrl'][1]['url']]
        images['plan']['big_quality'] += [item['developmentSitePlanUrl'][2]['url']]
    except:
        pass
    try:
        for photo_galery in item['developmentPlanImageUrls']:
            photo_images = photo_galery['imageUrls']
            images['flats']['min_quality'] += list(map(lambda x: x[0]['url'], photo_images))
            images['flats']['medium_quality'] += list(map(lambda x: x[1]['url'], photo_images))
            images['flats']['big_quality'] += list(map(lambda x: x[2]['url'], photo_images))
    except:
        pass
    # ============================= СОХРАНЯЕМ =================================
    El = New_buildings(
        title = title,
        coordinates = coordinates,
        identify = identify,
        characteristic = characteristic,
        actualization = actualization,
        technical_characteristic = technical_characteristic,
        class_indicators = class_indicators,
        images = images
    )
    objects.append(El)
    return {'status': True, 'text': 'Ok, build is save'}


def parse_domofond(page = 1, view = False):
    global index
    # парсим вот эту ссылку
    url='https://www.domofond.ru/prodazha-novostroiki-ufa-c1514?Page='+str(page)
    # меняем агент пользователя
    choice_useragent(change_header = True)
    # получаем html со списком новостроек
    try:
        html = str(requests.get(url, headers = header).text)
    except:
        if view:
            print('No html receive...')
        return None
    # список новостроек
    try:
        elements = json.loads(html.split('window.__INITIAL_DATA__ = ')[1].split('</script>')[0])['itemsState']['items']
    except:
        if view:
            print('No elements in html code...')
        return None
    # получаем ссылки на объекты
    for el in elements:
        # передаём на получение и сохранение
        url_build_domofond = 'https://www.domofond.ru' + el['itemUrl']
        try:
            result = parse_domofond_build(url_build_domofond)
            # подсчёт
            if result['status']:
                index += 1
            else:
                if view:
                    print(result['text'])
            # если отображение включено, то печатаем
            if view and result['status']:
                print('+1 build on page ' + str(page))
                if index % 10 == 0:
                    print('========= Save {} buildings ========='.format(index))
        except:
            if view:
                print('Some error on build')
        # замедление
        time.sleep( randint(1, 3) )

# функция для вызова
def parse_domofond_call(pages = 7, view = False):
    for i in range(1, pages + 1):
        parse_domofond(page = i, view = view)



# ========================= CALL
parse_domofond_call(pages = 7, view = True)


# saving
New_buildings.objects.bulk_create(objects)


# python new_buildings_domofond.py
