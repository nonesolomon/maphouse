# -*- coding: utf-8 -*-
# start:

# ======================================================= 1
import os, sys
# change envieron
delimeter = '\\' if os.name == 'nt' else '/'
path_list = os.getcwd().split(delimeter)
new_path = delimeter.join(path_list[:len(path_list) - 1])
sys.path.append(new_path)
# settings django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)

# ======================================================= 2
# import database classes
from main.models import New_buildings
# import libraries
import requests, time, datetime, asyncio, json, datetime, copy, threading
from bs4 import BeautifulSoup as BS
from random import random, randint, choice, shuffle
from fp.fp import FreeProxy
# selenium
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
# import local library
import district_distributor
# import additions
from main.additions import *

# new normal way
os.chdir(new_path)


# set header
header = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control': 'no-cache',
    'pragma': 'no-cache',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36 Edg/89.0.774.68'
}


DATA = New_buildings.objects.all()

# ======================================================= 3
build_names = [
     #'жк белые росы',
     #'жк "уютный"',
     #'жк "город природы"',
     #'жк "цветы башкирии"',
     #'жк "8 марта"',
     #'жк "биосфера"',
     #'жк "республика"',
     #'жк "квартал мира"',
     #'жк "акварель"',
     #'жк "новый инорс"',
     #'жк "на кремлёвской"',
     #'жк "черниковские высотки"',
     #'жк "черника"',
     #'микрорайон "яркий"',
     'жк "новый город"',
     'жк "звездный"',
     'жк "снегири"',
]


class Request:
    def __init__(self):
        self.browser = webdriver.Chrome(ChromeDriverManager().install())

    def get(self, url):
        self.browser.get(url)
        return self.browser.page_source

request = Request()


def get_dist(array1, array2):
    x = abs(array1[0] - array2[0]); y = abs(array1[1] - array2[1]);
    return (x ** 2 + y ** 2) ** 0.5


# парсим весь список предложений по определённой новостройке
def parse_request(text):
    # 1. узнаём количество страниц в пагинации
    url = f'https://www.avito.ru/sterlitamak/kvartiry?p=2&q={text}'
    response = request.get(url)
    soup = BS(response, 'lxml')
    pages = soup.find_all('span', class_='pagination-item-1WyVp')
    try:
        last_page = int(pages[len(pages) - 2].text)
    except:
        last_page = 1
    time.sleep(randint(1, 2))
    links = []
    for page in range(1, last_page + 1):
        print(f'{text} -> ссылки на странице {page}')
        # 2. проходимся по странице и собираем ссылки
        url = f'https://www.avito.ru/sterlitamak/kvartiry?p={page}&q={text}'
        response = request.get(url)
        soup = BS(response, 'lxml')
        new_links = []
        for div in soup.find_all('div', class_='iva-item-content-m2FiN'):
            try:
                text_new = div.find('div', {'data-marker': 'item-development-name'}).text.strip().lower()
                if text.lower() == text_new.replace('«', '"').replace('»', '"'):
                    new_links.append(div.find('a', class_='iva-item-sliderLink-2hFV_').get('href'))
            except:
                continue
        print(f'{text} -> +{len(new_links)} ссылок')
        links += new_links
        time.sleep(randint(1, 2))
    return links


# получить данные по одному предложению
def get_data_by_link(name, link, data_in_base):
    # choice_useragent(True)
    response = request.get(link)
    soup = BS(response, 'lxml')
    price = int(soup.find('span', class_='js-item-price').get('content'))
    by_who = soup.find('div', class_='seller-info-col').find_all('div')[1].text.strip().split()[0]
    named_params = soup.find_all('li', class_='item-params-list-item')
    quantity_rooms = int(list(filter(lambda x: x.find('span').text.strip() == 'Количество комнат:', named_params))[0].text.lstrip('Количество комнат:'))
    area = float(list(filter(lambda x: x.find('span').text.strip() == 'Общая площадь:', named_params))[0].text.strip().lstrip('Общая площадь:').rstrip('\xa0м²'))
    # coord
    try:
        liter_name = list(filter(lambda x: x.find('span').text.strip() == 'Корпус, строение:', named_params))[0].text.strip().lstrip('Корпус, строение:')
    except:
        try:
            coord = soup.find('div', class_='b-search-map')
            lat = float(coord.get('data-map-lat'))
            lon = float(coord.get('data-map-lon'))
            # ищем ближайший
            liter_name = min(list(map(lambda x: [x.name, get_dist([lat, lon], x.coordinates)], data_in_base)), key=lambda x: x[1])[0]
        except:
            liter_name = name
    return {'name': name.capitalize(),
            'name_liter': liter_name.capitalize(),
            'price': price,
            'who': by_who.capitalize(),
            'quantity_rooms': quantity_rooms,
            'area': area}

# парсим определённую новостройку
def parse_by_build_name(build_name):
    data_in_base = filter(lambda x: x.global_name.lower() == build_name.lower(), DATA)
    # start parse
    links = parse_request(build_name)
    print(f'{build_name} -> Найдено {len(links)} предложений')
    # проходимся по ссылкам и парсим предложения
    for link in links:
        try:
            data_by_link = get_data_by_link(build_name, 'https://www.avito.ru' + link, data_in_base)
        except:
            continue
        file = open('result.csv', 'a', encoding='utf-8')
        file.write( ';'.join(list(map(lambda x: str(x).strip(), list(data_by_link.values()) ))) + '\n' )
        file.close()
        time.sleep(randint(1, 2))
    print(f'{build_name} -> Закончено')



# проходимся по новостройкам, суммируем все литеры в один список
all_liters = []
for build_name in build_names:
    parse_by_build_name(build_name)


print(all_liters[0])


# end.
