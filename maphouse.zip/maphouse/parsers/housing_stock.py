# start housing_stock parser:

# import modules, set django environ
import requests, bs4, time, os, sys, threading, random, datetime
# change envieron
delimeter = '\\' if os.name == 'nt' else '/'
path_list = os.getcwd().split(delimeter)
new_path = delimeter.join(path_list[:len(path_list) - 1])
sys.path.append(new_path)
# settings django
from django.core.management import execute_from_command_line
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
execute_from_command_line(sys.argv)
from main.models import Housing_stock
# new normal way
os.chdir(new_path)


header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}


# убрать пробелы из числа
def del_spaces(number):
    return ''.join(number.split())


# получить краткую информацию по всем домам
def get_short_information():
    url = 'https://dom.mingkh.ru/api/houses'
    html = requests.post(url, headers=header, data={'current': 1, 'rowCount': 5817, 'searchPhrase': '', 'region_url': 'bashkortostan', 'city_url': 'ufa'}).json()
    return html['rows']

# получить информацию по отдельному дому
def parse_house(link):
    html_house = requests.get(link, headers = header).text
    soup = bs4.BeautifulSoup(html_house, 'lxml')
    # делаем словаь со значениями
    dict_values = {}
    divs = soup.find_all('div', class_='table-responsive')
    for div in divs:
        elements = div.find_all('tr')
        for element in elements:
            values = element.find_all('td')
            try:
                dict_values[values[0].text.strip()] = values[-1].text.strip()
            except:
                pass
    # является ли дом аварийным
    # if dict_values['Дом признан аварийным'] == 'Да':
    #     return None
    # ищем кадастровый номер
    try:
        cadastral_number = html_house.split('<dt>Кадастровый номер</dt>')[1].split('<dd>')[1].split('</dd>')[0].strip()
    except:
        cadastral_number = 'Нет данных'
    # выбираем нужные, вставляем значения
    house = Housing_stock(
        adress = soup.find('ul', class_='breadcrumb').find_all('li')[-1].find('span').text.capitalize(),
        year_build = dict_values['Год ввода в эксплуатацию'],
        house_is_emergency = True if dict_values['Дом признан аварийным'] == 'Да' else False,
        floors = {'max_floors': 1 if 'Наибольшее количество этажей' not in dict_values else int(del_spaces(dict_values['Наибольшее количество этажей'])),
                  'min_floors': 1 if 'Наименьшее количество этажей' not in dict_values else int(del_spaces(dict_values['Наименьшее количество этажей']))},
        quantity_apartaments = 1 if 'Количество жилых помещений' not in dict_values else int(del_spaces(dict_values['Количество жилых помещений'])),
        type_of_building = 'Нет данных' if 'Серия, тип постройки здания' not in dict_values else dict_values['Серия, тип постройки здания'].capitalize(),
        bearing_wall_material = 'Нет данных' if 'Несущие стены' not in dict_values else dict_values['Несущие стены'].capitalize(),
        сadastral_number = cadastral_number,
        energy_efficiency_class = 'Нет данных' if 'Класс энергетической эффективности' not in dict_values else dict_values['Класс энергетической эффективности'].capitalize(),
        quantity_elevators = 0 if 'Количество лифтов' not in dict_values else dict_values['Количество лифтов'],
        space_m2 = {'living_space_m2': 0 if 'Площадь жилых помещений м2' not in dict_values else float(del_spaces(dict_values['Площадь жилых помещений м2'])),
                    'no_living_space_m2': 0 if 'Площадь нежилых помещений м2' not in dict_values else float(del_spaces(dict_values['Площадь нежилых помещений м2'])),
                    'common_property_area_m2': 0 if 'Площадь помещений общего имущества м2' not in dict_values else float(del_spaces(dict_values['Площадь помещений общего имущества м2']))},
        additional_information = 'Нет данных' if 'Дополнительная информация' not in dict_values else dict_values['Дополнительная информация'].capitalize(),
        coordinates = [float(soup.find('input', {'id': 'mapcenterlat'})['value']), float(soup.find('input', {'id': 'mapcenterlng'})['value'])]
    )
    return house


# получить полную информацию по всем домам
def get_full_information():
    url = 'https://dom.mingkh.ru/bashkortostan/ufa/houses?page='
    houses = []
    quantity = 0
    for page in range(1, 60):
        url_new = url + str(page)
        html = requests.get(url_new, headers = header).text
        soup = bs4.BeautifulSoup(html, 'lxml')
        links = list(map(lambda tr: 'https://dom.mingkh.ru' + tr.find_all('td')[2].find('a').get('href'), soup.find('table', class_ = 'table').find('tbody').find_all('tr')))
        for link in links:
            try:
                house = parse_house(link)
            except:
                print('error')
                continue
            if house is not None:
                houses.append(house)
                quantity += 1
            if quantity % 10 == 0:
                print(quantity)
    return houses


house_objects = get_full_information()
# Housing_stock.objects.bulk_create(house_objects)

# end.
