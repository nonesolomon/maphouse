# -*- coding: utf-8 -*-
import os, sys, time
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
execute_from_command_line(sys.argv)
from datetime import datetime
from main.models import Webcams
import requests
from random import randint

header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}

url = 'http://maps.ufanet.ru/ufa'
html = str(requests.get(url, headers = header).text)

elements = html.split('marker = L.marker(')
del elements[0]

for i, el in enumerate(elements):
    title = el.split("marker.name = '")[1].split("';")[0]
    ip = el.split("marker.server = '")[1].split("';")[0]
    number = el.split("marker.number = '")[1].split("';")[0]
    x = el.split("[")[1].split(",")[0]
    y = el.split(", ")[1].split("]")[0]
    href = 'http://maps.ufanet.ru/ufa#' + number
    href_m3u8 = 'http://136.169.226.39/001-999-134/tracks-v1/mono.m3u8?token=f0a07cc07d564278985686fd6a7c2ab5'
    camera = el.split("marker.is_camera = ")[1].split(";")[0]
    if camera != 'true':
        continue
    # saving
    cam = Webcams.objects.create(
        title = title,
        href = href,
        x = x, y = y,
        href_m3u8 = href_m3u8,
        server = 'ufanet',
        number = number
    )
    cam.save()
