# start:

# import modules, set django environ
import os, sys, math
# change envieron
delimeter = '\\' if os.name == 'nt' else '/'
path_list = os.getcwd().split(delimeter)
new_path = delimeter.join(path_list[:len(path_list) - 1])
sys.path.append(new_path)

# import
from django.core.management import execute_from_command_line
from django.db.models import F
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
execute_from_command_line(sys.argv)
from main.models import Housing_stock, Districts, Microdistricts

# new normal way
os.chdir(new_path)

# определяем координаты районов
d1, d2 = Districts.objects.all(), Microdistricts.objects.all()


# разделить координаты на линии по 2 точки
def split_coordinates_into_lines_by_2_points(array_coord):
    array_lines = []
    ln_array = len(array_coord)
    for i in range(ln_array - 1):
        array_lines.append([array_coord[i], array_coord[i + 1]])
    array_lines.append([array_coord[ln_array - 1], array_coord[0]])
    return array_lines

# убрать линии, у которых точки по x совпадающие
def discard_unnecessary_lines_coinciding_x(array_lines):
    array_lines_new = []
    for line in array_lines:
        if line[0][1] != line[1][1]:
            array_lines_new.append(line)
    return array_lines_new

# отделить от координат района неинформативные для нашей точки линии
def discard_unnecessary_lines(coord, array_lines):
    array_lines_new = []
    array_lines_ln = len(array_lines)
    for index in range(array_lines_ln):
        line = array_lines[index]
        if line[0][1] < coord[1] < line[1][1] or line[1][1] < coord[1] < line[0][1]:
            array_lines_new.append(line)
        elif line[1][1] == coord[1]:
            line_next = array_lines[(index + 1) % array_lines_ln]
            if line[0][1] < coord[1] < line_next[1][1] or line_next[1][1] < coord[1] < line[0][1]:
                array_lines_new.append(line)
    return array_lines_new

# определить положение линии
def determine_line_position(coord, line):
    y1, x1 = line[0]; y2, x2 = line[1]; y3, x3 = coord;
    if y1 == y3 and y2 == y3:
        return 'on the line'
    elif y1 >= y3 and y2 >= y3:
        return 'bottom'
    elif y1 <= y3 and y2 <= y3:
        return 'top'
    else:
        # одна точка выше, другая ниже
        tg1 = abs((y2 - y1) / (x2 - x1))
        tg2 = abs((y3 - y1) / (x3 - x1))
        if tg1 == tg2:
            position = 'on the line'
        elif y1 < y2:
            position = 'bottom' if tg1 > tg2 else 'top'
        elif y1 > y2:
            position = 'top' if tg1 > tg2 else 'bottom'
        return position

# определить для каждой линии её положение
def determine_for_each_line_its_position(coord, array_lines):
    positions = []
    for line in array_lines:
        response = determine_line_position(coord, line)
        if response == 'top':
            positions.append(True) # сверху
        elif response == 'bottom':
            positions.append(False) # снизу
        else:
            return [True] # уже точка внутри, т.к. лежит на линии
    return positions

# определить, в области точка или нет
def does_it_belong_to_the_district(coord, array_coord):
    array_lines = split_coordinates_into_lines_by_2_points(array_coord)
    array_lines_new = discard_unnecessary_lines_coinciding_x(array_lines)
    array_lines_new = discard_unnecessary_lines(coord, array_lines_new)
    positions = determine_for_each_line_its_position(coord, array_lines_new)
    number_of_lines_on_top = positions.count(True)
    if number_of_lines_on_top % 2 == 1:
        return True # точка лежит внутри
    else:
        return False # точка лежит снаружи


# присвоить дому район
def object_in_districts(object, d):
    for rayon in d:
        for array_coord in rayon.coordinates:
            if does_it_belong_to_the_district(object.coordinates, array_coord[0: len(array_coord) - 1]):
                return rayon.title
    return 'Пригород'


# определить районы для всего класса базы данных
def do_some_class(some_db_class, view_speed=False):
    # проходимся по каждому дому и присваиваем ему район
    objects = some_db_class.objects.all()
    for object in objects:
        if view_speed:
            print(object.pk)
        name1 = object_in_districts(object, d1)
        name2 = object_in_districts(object, d2)
        object.district, object.microdistrict = name1, name2
        object.save()




# end.
