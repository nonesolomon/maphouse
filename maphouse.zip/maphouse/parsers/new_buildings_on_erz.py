# -*- coding: utf-8 -*-
# start:

# ======================================================= 1
import os, sys
# change envieron
delimeter = '\\' if os.name == 'nt' else '/'
path_list = os.getcwd().split(delimeter)
new_path = delimeter.join(path_list[:len(path_list) - 1])
sys.path.append(new_path)
# settings django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "maphouse.settings")
from django.core.management import execute_from_command_line
from django.core.files import File
execute_from_command_line(sys.argv)

# ======================================================= 2
# import database classes
from main.models import New_buildings, Microdistricts
# import libraries
import requests, time, os, sys, asyncio, json, datetime, copy
from bs4 import BeautifulSoup as BS
from threading import Thread
from random import random, randint, choice, shuffle
from fp.fp import FreeProxy
# import local library
import district_distributor

# new normal way
os.chdir(new_path)

# ======================================================= 3
# addition parser components
user_agents = []
header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 YaBrowser/20.3.0.1162 (beta) Yowser/2.5 Safari/537.36'}
proxies = {"http"  : '', "https" : ''}
random_sites = ['https://yandex.ru', 'https://google.com', 'https://mail.ru/', 'https://youtube.com/', 'https://useragents.ru/', 'https://youtube.com/', 'https://kmb.cybber.ru', 'https://stackoverflow.com/', 'https://python-scripts.com/', 'http://turfjs.org/', 'https://glyphicons.com/', 'https://html-color-codes.info']

# ======================================================= 4
class Useful_functions:
    def __init__(self):
        pass

    def get_erz_id_from_link(self, link, get_only_id=True):
        if get_only_id:
            return link.split('?')[0].split('-')[-1]
        return link

    def delete_symbols(self, string, args_list):
        for arg in args_list:
            string = ''.join(string.split(arg))
        return string

    def average_price(self, array):
        return sum(array) / len(array)

Usf = Useful_functions()


# objects page parser
def objects_page(region='respublika-bashkortostan', regionKey='170580001'):
    response = requests.get(f'https://erzrf.ru/erz-rest/api/v1/gk/table?region={region}&regionKey={regionKey}', headers=header).json()
    all_ids = list(map(lambda x: x['id'], response['list']))
    return all_ids


# one object page parser
def object_parser(main_id, region='respublika-bashkortostan', regionKey='170580001'):
    # общие данные всеё новостройки
    main_data = requests.get(f'https://erzrf.ru/erz-rest/api/v1/gk/index/{main_id}', headers=header).json()
    # дополнительные общие данные
    additional_data = requests.get(f'https://erzrf.ru/erz-rest/api/v1/gk/additional/{main_id}?gkId={main_id}&region={region}&regionKey={regionKey}', headers=header).json()
    # получаем id литеров
    url_ids = f'https://erzrf.ru/erz-rest/api/v1/gk/tabs?gkId={main_id}&region={region}&regionKey={regionKey}'
    liters_ids = requests.get(url_ids, headers=header).json()
    all_liters = []
    for liter_id in liters_ids:
        # получаем данные по каждому литеру
        data_url = f'https://erzrf.ru/erz-rest/api/v1/buildinfo/{liter_id["id"]}?region={region}&regionKey={regionKey}'
        data_liter = requests.get(data_url, headers=header).json()
        # получаем данные по квартирам
        apart_url = f'https://erzrf.ru/erz-rest/api/v1/apartmentrooms?gkId={main_id}&region={region}&regionKey={regionKey}&buildObjectId={liter_id["id"]}'
        apartments = requests.get(apart_url, headers=header).json()
        apart = {1: list(filter(lambda x: x['vnroom'] == '1', apartments)),
                 2: list(filter(lambda x: x['vnroom'] == '2', apartments)),
                 3: list(filter(lambda x: x['vnroom'] == '3', apartments)),
                 4: list(filter(lambda x: x['vnroom'] == '4', apartments)),
                 5: list(filter(lambda x: int(x['vnroom']) not in [1, 2, 3, 4], apartments))}
        apartments_cost_result = {}
        for key in apart:
            quantity = len(apart[key])
            if quantity > 0:
                apartments_cost_result[key] = {
                   'q': quantity,
                   'min_p': min( list(map(lambda x: x['cost'], apart[key])) ),
                   'ave_p': Usf.average_price( list(map(lambda x: x['cost'], apart[key])) ),
                   'max_p': max( list(map(lambda x: x['cost'], apart[key])) ),
                   'min_a': min( list(map(lambda x: float(x['nallsquare']), apart[key])) ),
                   'ave_a': Usf.average_price( list(map(lambda x: float(x['nallsquare']), apart[key])) ),
                   'max_a': max( list(map(lambda x: float(x['nallsquare']), apart[key])) ),
                   'min_m2': min( list(map(lambda x: x['costm2'], apart[key])) ),
                   'ave_m2': Usf.average_price( list(map(lambda x: x['costm2'], apart[key])) ),
                   'max_m2': max( list(map(lambda x: x['costm2'], apart[key])) )
                }
            else:
                apartments_cost_result[key] = {'q': 0}
        # собираем все данные
        Liter_object_dict_raw = dict(
            name = ["""f'{main_data["name"]} - {liter_id["title"]}'""", 'Не определено'],
            global_name = ["""main_data['name']""", 'Не определено'],
            # местоположение
            adress = ["""data_liter['address']""", 'Не определено'],
            locality = ["""data_liter['place']""", 'Не определено'],
            district = ["""data_liter['placeLocality']""", 'Не определено'],
            microdistrict = 'Не определено',
            coordinates = ["""[round(float(data_liter['lattitude']), 6), round(float(data_liter['longtitude']), 6)]""", [54, 55]],
            # даты
            start_date = ["""main_data['dateBuildStart']""", 'Не определено'],
            sales_start_date = 'Не определено',
            deadline = ["""data_liter['endPlan']""", 'Не определено'],
            object_readiness = ["""liter_id['state']""", 'Не определено'],
            # распространение информации
            phone = ["""'7' + Usf.delete_symbols(data_liter['phoneSales'], [' ', '(', ')']).strip()""", 'Не определено'],
            site = ["""main_data['site'] if 'http' in main_data['site'] else 'http://' + main_data['site']""", 'Не определено'],
            social_network = ["""additional_data['socialNetworks']['official']""", {}],
            # создатели
            developer = ["""data_liter['brandTOP']['shortName']""", """data_liter['brandTOP']['organizationName']""", 'Не определено'],
            builder = ["""data_liter['developerName']""", 'Не определено'],
            # квартиры
            number_apartments_project = ["""int(data_liter['apartmentsCountAll'])""", 0],
            apartments_sale_developer = ["""int(data_liter['apartmentsCountSales'])""", 0],
            apartments_cost = ["""apartments_cost_result""", {}],
            # остальное
            floors = ["""[int(data_liter['floorFrom']), int(data_liter['floorTo'])]""", 'Не определено'],
            conditional_class = ["""data_liter['buildClass']""", 'Не определено'],
            decoration_level = ["""data_liter['trimType']""", 'Не определено'],
            parking_places = ["""data_liter['parkingUnderground']""", 0],
            cost_parking_space = 0,
            number_residential_sections = 1,
            quantity_elevators = 1,
            cadastral_number = 'Не определено',
            land_area = ["""float(data_liter['landSquare'])""", 0],
            all_area = ["""float(data_liter['allSquare'])""", 0],
            living_area = ["""float(data_liter['livingSquare'])""", 0],
            energy_efficiency_class = ["""data_liter['energyClass']""", 'Не определено'],
            seismic_resistance = ["""int(data_liter['seismicResistance'])""", 'Не определено'],
            bearing_wall_material = ["""data_liter['buildMaterial']""", 'Не определено'],
            # база ерз
            erz_id = ["""str(main_id)""", 'Не определено'],
            erz_id_liter = ["""str(liter_id['id'])""", 'Не определено']
        )
        # нормализируем данные для базы данных
        Liter_object_dict = {}
        for arg in Liter_object_dict_raw:
            value = Liter_object_dict_raw[arg]
            if type(value) == list and len(value) >= 2:
                bool = False
                for i in range(len(value) - 1):
                    try:
                        Liter_object_dict[arg] = eval(value[i])
                        bool = True
                        break
                    except:
                        continue
                if not bool:
                    Liter_object_dict[arg] = value[-1]
            else:
                Liter_object_dict[arg] = value
        # определяем риэлторский район
        object = New_buildings(**Liter_object_dict)
        object.microdistrict = district_distributor.object_in_districts(object, D)
        # добавляем литер в список всех литеров данной новостройки
        all_liters.append(object)
    return all_liters


# спарсить всё
def main_parser(region='respublika-bashkortostan', regionKey='170580001', save=True):
    objects_ids = objects_page(region=region, regionKey=regionKey)
    all_data_objects = []
    for object_id in objects_ids:
        all_data_objects += object_parser(object_id, region=region, regionKey=regionKey)
    if save:
        New_buildings.objects.bulk_create(all_data_objects)
    return all_data_objects


# ======================================================= 5
# start parse
# main_parser(region='respublika-bashkortostan', regionKey='170580001')

# define district for every and save
# district_distributor.do_some_class(New_buildings)

images = ['C:/Users/Admin/Desktop/1.png',
          'C:/Users/Admin/Desktop/2.png']


for b in New_buildings.objects.all():
    file = File(open(choice(images), 'rb'))
    b.image.save(f'{b.pk}.png', file)
    b.save()



# end.
